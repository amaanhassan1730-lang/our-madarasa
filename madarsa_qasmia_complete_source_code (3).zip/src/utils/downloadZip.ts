import { PROJECT_ZIP_BASE64 } from './projectZipData';

/**
 * Downloads the complete source code zip directly from memory as a binary Blob.
 * This completely avoids browser iframe navigation issues or static file proxying problems.
 */
export function triggerProjectZipDownload(fileName = 'madarsa_qasmia_complete_source_code.zip'): boolean {
  try {
    const binaryString = window.atob(PROJECT_ZIP_BASE64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    const blob = new Blob([bytes], { type: 'application/zip' });
    const blobUrl = window.URL.createObjectURL(blob);

    const link = document.createElement('a');
    link.href = blobUrl;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();

    setTimeout(() => {
      document.body.removeChild(link);
      window.URL.revokeObjectURL(blobUrl);
    }, 2000);

    return true;
  } catch (error) {
    console.error('Failed to trigger in-memory zip download, falling back to static URL:', error);
    // Fallback
    const a = document.createElement('a');
    a.href = '/madarsa_qasmia_complete_project.zip';
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      document.body.removeChild(a);
    }, 1000);
    return false;
  }
}
