export const downloadStandaloneHtmlApp = (currentDataJson: string) => {
  const htmlContent = `<!DOCTYPE html>
<html lang="ur" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>مدرسہ قاسمیہ - جامع نظامِ انتظام | Madarsa Qasmia</title>
  <!-- Tailwind CSS CDN -->
  <script src="https://cdn.tailwindcss.com"></script>
  <!-- Google Fonts for Urdu & English -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Amiri:ital,wght@0,400;0,700;1,400&family=Noto+Nastaliq+Urdu:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <!-- React & Babel UMD CDNs -->
  <script src="https://unpkg.com/react@18/umd/react.production.min.js" crossorigin></script>
  <script src="https://unpkg.com/react-dom@18/umd/react-dom.production.min.js" crossorigin></script>
  <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
  <style>
    :root {
      --primary-green: #0F5D2F;
      --mint-soft: #E8F5E9;
    }
    .font-urdu { font-family: 'Noto Nastaliq Urdu', 'Amiri', serif; line-height: 2.1; }
    .font-arabic { font-family: 'Amiri', serif; }
    @media print {
      body * { visibility: hidden; }
      #printable-area, #printable-area * { visibility: visible; }
      #printable-area { position: absolute; left: 0; top: 0; width: 100%; margin: 0; padding: 10mm; background: white; }
      .no-print { display: none !important; }
    }
  </style>
</head>
<body class="bg-[#F8FAF8] text-slate-800 antialiased">
  <div id="root"></div>

  <script type="text/babel">
    const { useState, useEffect, useMemo } = React;
    const initialMadarsaData = ${currentDataJson};

    function StandaloneMadarsaApp() {
      const [lang, setLang] = useState('ur');
      const [role, setRole] = useState('admin');
      const [activeTab, setActiveTab] = useState('dashboard');
      const [data, setData] = useState(() => {
        const saved = localStorage.getItem('madarsa_standalone_data');
        return saved ? JSON.parse(saved) : initialMadarsaData;
      });

      useEffect(() => {
        localStorage.setItem('madarsa_standalone_data', JSON.stringify(data));
        document.documentElement.dir = lang === 'ur' ? 'rtl' : 'ltr';
        document.documentElement.lang = lang;
      }, [data, lang]);

      return (
        <div className="min-h-screen bg-[#F8FAF8] flex flex-col font-sans">
          {/* Header */}
          <header className="bg-[#0F5D2F] text-white shadow-md border-b-4 border-amber-500">
            <div className="max-w-7xl mx-auto px-4 py-3 flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center text-3xl shadow-inner border border-white/20">
                  🕌
                </div>
                <div>
                  <h1 className="text-xl sm:text-2xl font-bold tracking-tight font-urdu">
                    {lang === 'ur' ? data.settings.madrasaNameUr : data.settings.madrasaNameEn}
                  </h1>
                  <p className="text-xs text-emerald-100 font-urdu">
                    {lang === 'ur' ? data.settings.taglineUr : data.settings.taglineEn}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={() => setLang(lang === 'ur' ? 'en' : 'ur')}
                  className="px-3 py-1.5 rounded-lg bg-white/20 hover:bg-white/30 text-white font-bold text-sm transition-all flex items-center gap-1 border border-white/30"
                >
                  🌐 {lang === 'ur' ? 'English' : 'اردو'}
                </button>
                <div className="bg-white/10 text-xs px-3 py-1.5 rounded-full border border-white/20">
                  {role === 'admin' ? '👑 مہتمم / ایڈمن' : role === 'ustad' ? '📖 استاد' : role === 'accountant' ? '💰 خزانچی' : '👨‍👩‍👦 سرپرست'}
                </div>
              </div>
            </div>
          </header>

          {/* Body content */}
          <main className="max-w-7xl mx-auto px-4 py-6 flex-1 w-full">
            <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 mb-6 flex items-center justify-between">
              <div className="flex items-center gap-3 text-emerald-900 font-urdu">
                <span className="text-2xl">✅</span>
                <div>
                  <h4 className="font-bold text-base">مدرسہ قاسمیہ آف لائن ایپ کامیابی سے لوڈ ہو گئی ہے</h4>
                  <p className="text-xs text-emerald-700">یہ مکمل ایپلیکیشن بغیر انٹرنیٹ کے آپ کے کمپیوٹر پر محفوظ ہے اور کام کر رہی ہے۔</p>
                </div>
              </div>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              <div className="bg-white p-5 rounded-2xl border border-emerald-100 shadow-sm flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center text-3xl">
                  🎓
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-500 font-urdu">کل زیرِ تعلیم طلبہ</p>
                  <h3 className="text-2xl font-black text-emerald-900">{data.students.length}</h3>
                </div>
              </div>
              <div className="bg-white p-5 rounded-2xl border border-emerald-100 shadow-sm flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl bg-teal-100 text-teal-800 flex items-center justify-center text-3xl">
                  ✅
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-500 font-urdu">آج کی حاضری</p>
                  <h3 className="text-2xl font-black text-teal-900">
                    {data.attendance.filter(a => a.status === 'present').length} / {data.students.length}
                  </h3>
                </div>
              </div>
              <div className="bg-white p-5 rounded-2xl border border-emerald-100 shadow-sm flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl bg-amber-100 text-amber-800 flex items-center justify-center text-3xl">
                  📖
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-500 font-urdu">حفظ اوسط گریڈ</p>
                  <h3 className="text-2xl font-black text-amber-900">A+ (ممتاز)</h3>
                </div>
              </div>
              <div className="bg-white p-5 rounded-2xl border border-emerald-100 shadow-sm flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl bg-blue-100 text-blue-800 flex items-center justify-center text-3xl">
                  💰
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-500 font-urdu">ماہانہ فیس وصولی</p>
                  <h3 className="text-2xl font-black text-blue-900">
                    {data.feePayments.reduce((sum, f) => sum + (f.totalPaid || 0), 0).toLocaleString()} روپے
                  </h3>
                </div>
              </div>
            </div>

            {/* Students Table */}
            <div className="bg-white rounded-2xl border border-emerald-100 shadow-sm p-6">
              <h2 className="text-lg font-bold text-emerald-950 font-urdu mb-4 flex items-center gap-2">
                <span>🎓</span> طلبہ کا رجسٹر (کل: {data.students.length})
              </h2>
              <div className="overflow-x-auto">
                <table className="w-full text-right text-sm">
                  <thead className="bg-[#E8F5E9] text-emerald-900 font-urdu text-xs">
                    <tr>
                      <th className="p-3">رول نمبر</th>
                      <th className="p-3">طالب علم کا نام</th>
                      <th className="p-3">والد کا نام</th>
                      <th className="p-3">درجہ / کلاس</th>
                      <th className="p-3">موبائل نمبر</th>
                      <th className="p-3">ہاسٹل</th>
                      <th className="p-3">ماہانہ فیس</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-emerald-50">
                    {data.students.map(s => (
                      <tr key={s.id} className="hover:bg-emerald-50/50">
                        <td className="p-3 font-mono font-bold text-emerald-800">{s.rollNo}</td>
                        <td className="p-3 font-bold font-urdu">{s.nameUr}</td>
                        <td className="p-3 text-slate-600 font-urdu">{s.fatherNameUr}</td>
                        <td className="p-3">
                          <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800">
                            {s.class}
                          </span>
                        </td>
                        <td className="p-3 font-mono text-slate-600" dir="ltr">{s.parentMobile}</td>
                        <td className="p-3">
                          <span className={"px-2.5 py-1 rounded-full text-xs font-bold " + (s.isHostel ? "bg-amber-100 text-amber-800" : "bg-slate-100 text-slate-700")}>
                            {s.isHostel ? 'مقیم' : 'غیر مقیم'}
                          </span>
                        </td>
                        <td className="p-3 font-bold text-emerald-900">{s.monthlyFee} روپے</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </main>

          <footer className="bg-emerald-950 text-emerald-200 py-4 text-center text-xs border-t border-emerald-900 font-urdu">
            مدرسہ قاسمیہ نظامِ انتظام - جملہ حقوق محفوظ ہیں۔
          </footer>
        </div>
      );
    }

    ReactDOM.createRoot(document.getElementById('root')).render(<StandaloneMadarsaApp />);
  </script>
</body>
</html>`;

  const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `Madarsa_Qasmia_Standalone_Offline_${new Date().toISOString().split('T')[0]}.html`;
  a.click();
  URL.revokeObjectURL(url);
};

export const downloadStandaloneHtml = (data: any) => {
  const jsonStr = typeof data === 'string' ? data : JSON.stringify(data);
  downloadStandaloneHtmlApp(jsonStr);
};

