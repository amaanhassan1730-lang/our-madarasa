import {
  Student,
  AttendanceRecord,
  HifzDiaryEntry,
  FeePayment,
  DonationRecord,
  ExpenseRecord,
  TimetableSchedule,
  SystemSettings,
  ExamRecord,
  NoticeAnnouncement,
  MushafData,
  Donor,
  TeacherProfile,
} from '../types';
import {
  initialSettings,
  initialTeachers,
  initialStudents,
  initialAttendance,
  initialHifzDiary,
  initialFeePayments,
  initialDonations,
  initialExpenses,
  initialTimetable,
  initialExams,
  initialNotices,
  initialMushafData,
  initialDonors,
} from '../data/initialData';

const STORAGE_KEYS = {
  SETTINGS: 'madarsa_qasmia_settings_v1',
  TEACHERS: 'madarsa_qasmia_teachers_v1',
  STUDENTS: 'madarsa_qasmia_students_v1',
  ATTENDANCE: 'madarsa_qasmia_attendance_v1',
  HIFZ: 'madarsa_qasmia_hifz_v1',
  FEES: 'madarsa_qasmia_fees_v1',
  DONATIONS: 'madarsa_qasmia_donations_v1',
  EXPENSES: 'madarsa_qasmia_expenses_v1',
  TIMETABLE: 'madarsa_qasmia_timetable_v1',
  EXAMS: 'madarsa_qasmia_exams_v1',
  NOTICES: 'madarsa_qasmia_notices_v1',
  MUSHAF: 'madarsa_qasmia_mushaf_v1',
  DONORS: 'madarsa_qasmia_donors_v1',
  ACTIVE_ROLE: 'madarsa_qasmia_role_v1',
  ACTIVE_TEACHER: 'madarsa_qasmia_active_teacher_v1',
  PARENT_MOBILE: 'madarsa_qasmia_parent_mobile_v1',
  PARENT_USTAD: 'madarsa_qasmia_parent_ustad_v1',
  LANG: 'madarsa_qasmia_lang_v1',
};

export const loadStoredData = () => {
  try {
    const settings: SystemSettings = JSON.parse(
      localStorage.getItem(STORAGE_KEYS.SETTINGS) || 'null'
    ) || initialSettings;

    const teachers: TeacherProfile[] = JSON.parse(
      localStorage.getItem(STORAGE_KEYS.TEACHERS) || 'null'
    ) || initialTeachers;

    const students: Student[] = JSON.parse(
      localStorage.getItem(STORAGE_KEYS.STUDENTS) || 'null'
    ) || initialStudents;

    const attendance: AttendanceRecord[] = JSON.parse(
      localStorage.getItem(STORAGE_KEYS.ATTENDANCE) || 'null'
    ) || initialAttendance;

    const hifzDiary: HifzDiaryEntry[] = JSON.parse(
      localStorage.getItem(STORAGE_KEYS.HIFZ) || 'null'
    ) || initialHifzDiary;

    const feePayments: FeePayment[] = JSON.parse(
      localStorage.getItem(STORAGE_KEYS.FEES) || 'null'
    ) || initialFeePayments;

    const donations: DonationRecord[] = JSON.parse(
      localStorage.getItem(STORAGE_KEYS.DONATIONS) || 'null'
    ) || initialDonations;

    const expenses: ExpenseRecord[] = JSON.parse(
      localStorage.getItem(STORAGE_KEYS.EXPENSES) || 'null'
    ) || initialExpenses;

    const timetable: TimetableSchedule[] = JSON.parse(
      localStorage.getItem(STORAGE_KEYS.TIMETABLE) || 'null'
    ) || initialTimetable;

    const exams: ExamRecord[] = JSON.parse(
      localStorage.getItem(STORAGE_KEYS.EXAMS) || 'null'
    ) || initialExams;

    const notices: NoticeAnnouncement[] = JSON.parse(
      localStorage.getItem(STORAGE_KEYS.NOTICES) || 'null'
    ) || initialNotices;

    const mushafProgress: MushafData = JSON.parse(
      localStorage.getItem(STORAGE_KEYS.MUSHAF) || 'null'
    ) || initialMushafData;

    const donors: Donor[] = JSON.parse(
      localStorage.getItem(STORAGE_KEYS.DONORS) || 'null'
    ) || initialDonors;

    return {
      settings,
      teachers,
      students,
      attendance,
      hifzDiary,
      feePayments,
      donations,
      expenses,
      timetable,
      exams,
      notices,
      mushafProgress,
      donors,
    };
  } catch (err) {
    console.error('Error loading stored data:', err);
    return {
      settings: initialSettings,
      teachers: initialTeachers,
      students: initialStudents,
      attendance: initialAttendance,
      hifzDiary: initialHifzDiary,
      feePayments: initialFeePayments,
      donations: initialDonations,
      expenses: initialExpenses,
      timetable: initialTimetable,
      exams: initialExams,
      notices: initialNotices,
      mushafProgress: initialMushafData,
      donors: initialDonors,
    };
  }
};

export const saveItem = (key: keyof typeof STORAGE_KEYS, data: any) => {
  try {
    localStorage.setItem(STORAGE_KEYS[key], JSON.stringify(data));
  } catch (err) {
    console.error(`Error saving ${key} to localStorage:`, err);
  }
};

export const saveStoredData = (data: {
  settings: SystemSettings;
  teachers?: TeacherProfile[];
  students: Student[];
  attendance: AttendanceRecord[];
  hifzDiary: HifzDiaryEntry[];
  feePayments: FeePayment[];
  donations: DonationRecord[];
  expenses: ExpenseRecord[];
  timetable: TimetableSchedule[];
  exams?: ExamRecord[];
  notices?: NoticeAnnouncement[];
  mushafProgress?: MushafData;
  donors?: Donor[];
}) => {
  saveItem('SETTINGS', data.settings);
  if (data.teachers) saveItem('TEACHERS', data.teachers);
  saveItem('STUDENTS', data.students);
  saveItem('ATTENDANCE', data.attendance);
  saveItem('HIFZ', data.hifzDiary);
  saveItem('FEES', data.feePayments);
  saveItem('DONATIONS', data.donations);
  saveItem('EXPENSES', data.expenses);
  saveItem('TIMETABLE', data.timetable);
  if (data.exams) saveItem('EXAMS', data.exams);
  if (data.notices) saveItem('NOTICES', data.notices);
  if (data.mushafProgress) saveItem('MUSHAF', data.mushafProgress);
  if (data.donors) saveItem('DONORS', data.donors);
};


export const exportFullBackup = () => {
  const data = loadStoredData();
  const blob = new Blob([JSON.stringify(data, null, 2)], {
    type: 'application/json',
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `Madarsa_Qasmia_Backup_${new Date().toISOString().split('T')[0]}.json`;
  a.click();
  URL.revokeObjectURL(url);
};

export const exportStudentsCSV = (students: Student[]) => {
  const headers = [
    'Roll No',
    'Name (Urdu)',
    'Name (English)',
    'Father Name',
    'Class',
    'Age',
    'Parent Mobile',
    'Hostel',
    'Monthly Fee',
    'Admission Date',
    'Completed Paras',
    'Address',
  ];

  const rows = students.map((s) => [
    `"${s.rollNo}"`,
    `"${s.nameUr}"`,
    `"${s.nameEn}"`,
    `"${s.fatherNameUr}"`,
    `"${s.class}"`,
    s.age,
    `"${s.parentMobile}"`,
    s.isHostel ? 'Hostel' : 'Day Scholar',
    s.monthlyFee,
    `"${s.admissionDate}"`,
    s.completedParas || 0,
    `"${s.address || ''}"`,
  ]);

  const csvContent = '\uFEFF' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `Madarsa_Qasmia_Students_${new Date().toISOString().split('T')[0]}.csv`;
  a.click();
  URL.revokeObjectURL(url);
};

export const exportFinancesCSV = (donations: DonationRecord[], expenses: ExpenseRecord[]) => {
  const headers = ['Type', 'Voucher / ID', 'Date', 'Title / Donor', 'Category', 'Amount (PKR)', 'Payment Mode', 'Remarks'];

  const donRows = donations.map((d) => [
    'Donation (چندہ)',
    `"${d.voucherNo}"`,
    `"${d.date}"`,
    `"${d.donorName}"`,
    `"${d.category}"`,
    d.amount,
    `"${d.paymentMode}"`,
    `"${d.purpose}"`,
  ]);

  const expRows = expenses.map((e) => [
    'Expense (خرچ)',
    `"${e.voucherNo}"`,
    `"${e.date}"`,
    `"${e.title}"`,
    `"${e.category}"`,
    e.amount,
    'Cash/Direct',
    `"Paid to: ${e.paidTo}"`,
  ]);

  const csvContent = '\uFEFF' + [headers.join(','), ...donRows.map((e) => e.join(',')), ...expRows.map((e) => e.join(','))].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `Madarsa_Qasmia_Ledger_${new Date().toISOString().split('T')[0]}.csv`;
  a.click();
  URL.revokeObjectURL(url);
};

export const createWhatsAppLink = (phone: string, message: string) => {
  // Format phone to international format without spaces or symbols
  let cleaned = phone.replace(/[^0-9]/g, '');
  if (cleaned.startsWith('0')) {
    cleaned = '92' + cleaned.substring(1);
  }
  const encoded = encodeURIComponent(message);
  return `https://wa.me/${cleaned}?text=${encoded}`;
};
