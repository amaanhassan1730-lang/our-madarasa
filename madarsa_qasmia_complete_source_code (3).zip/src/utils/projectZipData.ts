// Project source code zip base64 stub for offline/Vercel build
export const PROJECT_ZIP_BASE64 = "";
