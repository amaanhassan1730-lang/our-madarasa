import React, { useState, useEffect, useRef } from 'react';
import {
  Student,
  AttendanceRecord,
  HifzDiaryEntry,
  FeePayment,
  DonationRecord,
  ExpenseRecord,
  TimetableSchedule,
  SystemSettings,
  UserRole,
  ExamRecord,
  NoticeAnnouncement,
  Donor,
  MushafData,
} from './types';
import { Language, translations } from './i18n/translations';
import { initialMadrasaData } from './data/initialData';
import { loadStoredData, saveStoredData } from './utils/storage';
import { downloadStandaloneHtml } from './utils/singleFileGenerator';

// Components
import { Header } from './components/Header';
import { RoleLoginModal } from './components/RoleLoginModal';
import { PrintModal, PrintDocumentType } from './components/PrintModal';
import { Dashboard } from './components/Dashboard';
import { StudentsView } from './components/StudentsView';
import { AttendanceView } from './components/AttendanceView';
import { HifzDiaryView } from './components/HifzDiaryView';
import { MushafView } from './components/MushafView';
import { SmartRevisionSchedulerView } from './components/SmartRevisionSchedulerView';
import { DiniyatSyllabusView } from './components/DiniyatSyllabusView';
import { FeeManagementView } from './components/FeeManagementView';
import { DonationsView } from './components/DonationsView';
import { TimetableView } from './components/TimetableView';
import { ReportsBackupView } from './components/ReportsBackupView';
import { ExamsView } from './components/ExamsView';
import { NoticeBoardView } from './components/NoticeBoardView';
import { WhatsAppCenterModal } from './components/WhatsAppCenterModal';
import { InstallAppModal } from './components/InstallAppModal';
import { SourceCodeDownloadModal } from './components/SourceCodeDownloadModal';
import { ShortcutsModal } from './components/ShortcutsModal';
import {
  subscribeToCloudData,
  syncDataToCloud,
  seedCloudDataIfEmpty,
  onQuotaStateChange,
  AppDataState,
} from './services/cloudSync';

export default function App() {
  // Load initial data from local storage or defaults
  const [data, setData] = useState(() => loadStoredData());

  // Language state (Persists in localStorage)
  const [lang, setLang] = useState<Language>(() => {
    return (localStorage.getItem('madarsa_lang') as Language) || 'ur';
  });

  // Active Role state
  const [currentRole, setCurrentRole] = useState<UserRole>('admin');
  const [parentStudentMobile, setParentStudentMobile] = useState<string>('');
  const [activeTeacherName, setActiveTeacherName] = useState<string>('قاری عبد الوحید');
  const [isRoleModalOpen, setIsRoleModalOpen] = useState(false);

  // Active Navigation Tab
  const [activeTab, setActiveTab] = useState<string>('dashboard');

  // Quick Action Modal Triggers
  const [isQuickLogSabaqOpen, setIsQuickLogSabaqOpen] = useState(false);
  const [isQuickCollectFeeOpen, setIsQuickCollectFeeOpen] = useState(false);
  const [isQuickAddStudentOpen, setIsQuickAddStudentOpen] = useState(false);

  // Keyboard Shortcuts Guide Modal State
  const [isShortcutsModalOpen, setIsShortcutsModalOpen] = useState(false);

  // Central WhatsApp Alerts Hub Modal State
  const [isWhatsAppCenterOpen, setIsWhatsAppCenterOpen] = useState(false);
  const [whatsAppInitialTab, setWhatsAppInitialTab] = useState<'absent' | 'sabaq' | 'fee' | 'donation' | 'notice'>('absent');
  const [whatsAppInitialStudentId, setWhatsAppInitialStudentId] = useState<string | undefined>(undefined);

  // Print Document Modal State
  const [printDoc, setPrintDoc] = useState<PrintDocumentType | null>(null);
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);

  // Mobile App Install Modal State
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);

  // Full Source Code ZIP Modal State
  const [isSourceCodeModalOpen, setIsSourceCodeModalOpen] = useState(false);

  // Global Keyboard Shortcuts Listener (Alt + Key, Shift + ?)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      const isInput = target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || (target as any).isContentEditable);

      if (e.altKey) {
        const key = e.key.toLowerCase();
        switch (key) {
          case '1':
            e.preventDefault();
            setActiveTab('dashboard');
            break;
          case '2':
            e.preventDefault();
            setActiveTab('students');
            break;
          case '3':
            e.preventDefault();
            setActiveTab('attendance');
            break;
          case '4':
            e.preventDefault();
            setActiveTab('hifz');
            break;
          case '5':
            e.preventDefault();
            setActiveTab('mushaf');
            break;
          case '6':
            e.preventDefault();
            setActiveTab('revision');
            break;
          case '7':
            e.preventDefault();
            setActiveTab('fees');
            break;
          case '8':
            e.preventDefault();
            setActiveTab('donations');
            break;
          case '9':
            e.preventDefault();
            setActiveTab('exams');
            break;
          case '0':
            e.preventDefault();
            setActiveTab('notices');
            break;
          case 's':
            e.preventDefault();
            setActiveTab('students');
            setIsQuickAddStudentOpen(true);
            break;
          case 'l':
            e.preventDefault();
            setActiveTab('hifz');
            setIsQuickLogSabaqOpen(true);
            break;
          case 'f':
            e.preventDefault();
            setActiveTab('fees');
            setIsQuickCollectFeeOpen(true);
            break;
          case 'w':
            e.preventDefault();
            setIsWhatsAppCenterOpen(true);
            break;
          case 'r':
            e.preventDefault();
            setIsRoleModalOpen(true);
            break;
          case 'p':
            e.preventDefault();
            setActiveTab('reports');
            break;
          case 'k':
            e.preventDefault();
            setIsShortcutsModalOpen((prev) => !prev);
            break;
        }
      } else if (!isInput && (e.key === '?' || (e.shiftKey && e.key === '/'))) {
        e.preventDefault();
        setIsShortcutsModalOpen(true);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Cloud Sync State
  const [isCloudSynced, setIsCloudSynced] = useState(true);
  const [isQuotaExceeded, setIsQuotaExceeded] = useState(false);
  const isRemoteUpdateRef = useRef(false);

  // 1. Subscribe to Cloud Firestore updates
  useEffect(() => {
    // Listen for Firestore free tier quota status
    const unsubQuota = onQuotaStateChange((exceeded) => {
      setIsQuotaExceeded(exceeded);
      if (exceeded) {
        setIsCloudSynced(false);
      }
    });

    // Seed initial cloud document if not exists
    seedCloudDataIfEmpty(data as AppDataState);

    const unsubscribe = subscribeToCloudData(
      (cloudData) => {
        setIsCloudSynced(true);
        // Flag that this update came from cloud so we don't bounce it back
        isRemoteUpdateRef.current = true;
        setData((prev) => ({
          ...prev,
          settings: cloudData.settings || prev.settings,
          students: cloudData.students || prev.students,
          attendance: cloudData.attendance || prev.attendance,
          hifzDiary: cloudData.hifzDiary || prev.hifzDiary,
          feePayments: cloudData.feePayments || prev.feePayments,
          donations: cloudData.donations || prev.donations,
          expenses: cloudData.expenses || prev.expenses,
          timetable: cloudData.timetable || prev.timetable,
          exams: cloudData.exams || prev.exams,
          notices: cloudData.notices || prev.notices,
          mushafProgress: cloudData.mushafProgress || prev.mushafProgress,
          donors: cloudData.donors || prev.donors,
        }));
      },
      (err) => {
        setIsCloudSynced(false);
      }
    );

    return () => {
      unsubscribe();
      unsubQuota();
    };
  }, []);

  // 2. Save to localStorage and sync to Cloud Firestore whenever data changes
  useEffect(() => {
    // Always persist immediately to LocalStorage so no changes are lost
    saveStoredData(data);

    // If update originated from Firestore snapshot, do NOT push back to Firestore
    if (isRemoteUpdateRef.current) {
      isRemoteUpdateRef.current = false;
      return;
    }

    syncDataToCloud(data as AppDataState);
  }, [data]);

  // Persist language
  const handleToggleLang = () => {
    const nextLang: Language = lang === 'ur' ? 'en' : 'ur';
    setLang(nextLang);
    localStorage.setItem('madarsa_lang', nextLang);
  };

  // Sync HTML document direction & lang
  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ur' ? 'rtl' : 'ltr';
  }, [lang]);

  // Resolve parent's student info if role is parent
  const parentStudent = data.students.find((s) =>
    s.parentMobile.includes(parentStudentMobile.replace(/[^0-9]/g, ''))
  );

  // Handlers for Students
  const handleAddStudent = (newStudent: Omit<Student, 'id' | 'createdAt'>) => {
    const student: Student = {
      ...newStudent,
      id: `std-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setData((prev) => ({
      ...prev,
      students: [student, ...prev.students],
    }));
  };

  const handleUpdateStudent = (updatedStudent: Student) => {
    setData((prev) => ({
      ...prev,
      students: prev.students.map((s) =>
        s.id === updatedStudent.id ? updatedStudent : s
      ),
    }));
  };

  const handleDeleteStudent = (studentId: string) => {
    setData((prev) => ({
      ...prev,
      students: prev.students.filter((s) => s.id !== studentId),
      attendance: prev.attendance.filter((a) => a.studentId !== studentId),
      hifzDiary: prev.hifzDiary.filter((h) => h.studentId !== studentId),
      feePayments: prev.feePayments.filter((f) => f.studentId !== studentId),
    }));
  };

  // Handlers for Attendance
  const handleUpdateAttendance = (newAttendance: AttendanceRecord[]) => {
    setData((prev) => ({
      ...prev,
      attendance: newAttendance,
    }));
  };

  // Handlers for Hifz Diary
  const handleAddDiaryEntry = (entry: Omit<HifzDiaryEntry, 'id'>) => {
    const newEntry: HifzDiaryEntry = {
      ...entry,
      id: `hifz-${Date.now()}`,
    };
    setData((prev) => ({
      ...prev,
      hifzDiary: [newEntry, ...prev.hifzDiary],
    }));
  };

  const handleUpdateParas = (studentId: string, paras: number) => {
    setData((prev) => ({
      ...prev,
      students: prev.students.map((s) =>
        s.id === studentId ? { ...s, completedParas: paras } : s
      ),
    }));
  };

  const handleUpdateMushafProgress = (newProgress: MushafData) => {
    setData((prev) => ({
      ...prev,
      mushafProgress: newProgress,
    }));
  };

  // Handlers for Fees
  const handleAddFeePayment = (payment: Omit<FeePayment, 'id'>) => {
    const newPayment: FeePayment = {
      ...payment,
      id: `fee-${Date.now()}`,
    };
    setData((prev) => ({
      ...prev,
      feePayments: [newPayment, ...prev.feePayments],
    }));
  };

  // Handlers for Donations & Expenses
  const handleAddDonation = (donation: Omit<DonationRecord, 'id'>) => {
    const newDonation: DonationRecord = {
      ...donation,
      id: `don-${Date.now()}`,
    };
    setData((prev) => ({
      ...prev,
      donations: [newDonation, ...prev.donations],
    }));
  };

  const handleAddExpense = (expense: Omit<ExpenseRecord, 'id'>) => {
    const newExpense: ExpenseRecord = {
      ...expense,
      id: `exp-${Date.now()}`,
    };
    setData((prev) => ({
      ...prev,
      expenses: [newExpense, ...prev.expenses],
    }));
  };

  const handleAddDonor = (donor: Omit<Donor, 'id'>) => {
    const newDonor: Donor = {
      ...donor,
      id: `donor-${Date.now()}`,
    };
    setData((prev) => ({
      ...prev,
      donors: [newDonor, ...(prev.donors || [])],
    }));
  };

  // Handlers for Timetable
  const handleUpdateTimetable = (timetable: TimetableSchedule[]) => {
    setData((prev) => ({
      ...prev,
      timetable,
    }));
  };

  // Handlers for Settings & Data Backup
  const handleUpdateSettings = (settings: SystemSettings) => {
    setData((prev) => ({
      ...prev,
      settings,
    }));
  };

  const handleRestoreData = (importedData: any) => {
    if (importedData && importedData.students) {
      setData(importedData);
    }
  };

  const handleResetToDefaults = () => {
    setData(initialMadrasaData);
  };

  // Print Handlers
  const handlePrintStudentIdCard = (student: Student) => {
    setPrintDoc({ type: 'id_card', student });
    setIsPrintModalOpen(true);
  };

  const handlePrintFeeReceipt = (payment: FeePayment, student: Student) => {
    setPrintDoc({ type: 'fee_receipt', payment, student });
    setIsPrintModalOpen(true);
  };

  const handlePrintDonationVoucher = (donation: DonationRecord) => {
    setPrintDoc({ type: 'donation_voucher', donation });
    setIsPrintModalOpen(true);
  };

  const handlePrintResultCard = (exam: ExamRecord, student: Student) => {
    setPrintDoc({ type: 'result_card', exam, student });
    setIsPrintModalOpen(true);
  };

  // Exam Management Handlers
  const handleAddExamRecord = (newExam: Omit<ExamRecord, 'id' | 'createdAt'>) => {
    const exam: ExamRecord = {
      ...newExam,
      id: `exam-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setData((prev) => ({
      ...prev,
      exams: [exam, ...(prev.exams || [])],
    }));
  };

  const handleUpdateExamRecord = (updatedExam: ExamRecord) => {
    setData((prev) => ({
      ...prev,
      exams: (prev.exams || []).map((e) => (e.id === updatedExam.id ? updatedExam : e)),
    }));
  };

  const handleDeleteExamRecord = (examId: string) => {
    setData((prev) => ({
      ...prev,
      exams: (prev.exams || []).filter((e) => e.id !== examId),
    }));
  };

  // Notice Board Handlers
  const handleAddNotice = (newNotice: Omit<NoticeAnnouncement, 'id' | 'createdAt'>) => {
    const notice: NoticeAnnouncement = {
      ...newNotice,
      id: `notif-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setData((prev) => ({
      ...prev,
      notices: [notice, ...(prev.notices || [])],
    }));
  };

  const handleUpdateNotice = (updatedNotice: NoticeAnnouncement) => {
    setData((prev) => ({
      ...prev,
      notices: (prev.notices || []).map((n) => (n.id === updatedNotice.id ? updatedNotice : n)),
    }));
  };

  const handleDeleteNotice = (noticeId: string) => {
    setData((prev) => ({
      ...prev,
      notices: (prev.notices || []).filter((n) => n.id !== noticeId),
    }));
  };

  // Central WhatsApp Hub Trigger
  const handleOpenWhatsApp = (
    tab: 'absent' | 'sabaq' | 'fee' | 'donation' | 'notice' = 'absent',
    studentId?: string
  ) => {
    setWhatsAppInitialTab(tab);
    setWhatsAppInitialStudentId(studentId);
    setIsWhatsAppCenterOpen(true);
  };

  // Role Login Handler
  const handleRoleLogin = (role: UserRole, mobileOrDetails?: string, teacherName?: string) => {
    setCurrentRole(role);
    if (role === 'parent' && mobileOrDetails) {
      setParentStudentMobile(mobileOrDetails);
    }
    if (role === 'ustad' && (teacherName || mobileOrDetails)) {
      setActiveTeacherName(teacherName || mobileOrDetails || 'قاری عبد الوحید');
    }
    // Auto redirect parent or limited role if on an unauthorized tab
    if (role === 'parent') {
      setActiveTab('dashboard');
    }
  };

  // Single File HTML Download
  const handleDownloadSingleFile = () => {
    downloadStandaloneHtml(data);
  };

  const t = translations[lang];

  return (
    <div
      className={`min-h-screen bg-[#F4F9F5] text-slate-900 selection:bg-emerald-200 selection:text-emerald-950 ${
        lang === 'ur' ? 'font-urdu' : 'font-sans'
      }`}
      dir={lang === 'ur' ? 'rtl' : 'ltr'}
    >
      {/* 1. Header Navigation & Role Badge */}
      <Header
        lang={lang}
        onToggleLang={handleToggleLang}
        currentRole={currentRole}
        activeTeacherName={activeTeacherName}
        onOpenRoleModal={() => setIsRoleModalOpen(true)}
        madrasaNameUr={data.settings.madrasaNameUr}
        madrasaNameEn={data.settings.madrasaNameEn}
        taglineUr={data.settings.taglineUr}
        taglineEn={data.settings.taglineEn}
        activeTab={activeTab}
        onSelectTab={(tab) => {
          setActiveTab(tab);
          setIsQuickLogSabaqOpen(false);
          setIsQuickCollectFeeOpen(false);
          setIsQuickAddStudentOpen(false);
        }}
        onDownloadSingleFile={handleDownloadSingleFile}
        onOpenWhatsAppCenter={() => handleOpenWhatsApp('absent')}
        onOpenInstallModal={() => setIsInstallModalOpen(true)}
        onOpenSourceCodeModal={() => setIsSourceCodeModalOpen(true)}
        onOpenShortcutsModal={() => setIsShortcutsModalOpen(true)}
        isCloudSynced={isCloudSynced}
        parentStudentName={parentStudent?.nameUr}
      />

      {/* Informative quota notice banner if Firestore free limit is reached */}
      {isQuotaExceeded && (
        <div className="bg-amber-500/10 border-b border-amber-500/30 px-4 py-2.5 text-xs font-urdu text-amber-900 flex flex-wrap items-center justify-between gap-2 shadow-xs">
          <div className="flex items-center gap-2">
            <span className="text-base">🛡️</span>
            <span>
              <strong>نوٹ:</strong> فائر بیس کا یومیہ مفت کوٹہ (Free Daily Limit) مکمل ہے۔ تمام ریکارڈز آپ کی لوکل اسٹوریج میں ۱۰۰٪ محفوظ ہیں اور ایپ بغیر کسی تعطل کے چل رہی ہے۔ کوٹہ روزانہ ری سیٹ ہو جاتا ہے۔
            </span>
          </div>
          <a
            href="https://console.firebase.google.com/project/gen-lang-client-0820328182/firestore/databases/ai-studio-remixmadarsaqasm-9148390e-b710-4a65-89c5-5ee3a170a062/data?openUpgradeDialog=true"
            target="_blank"
            rel="noopener noreferrer"
            className="text-emerald-800 hover:text-emerald-950 font-bold underline text-[11px] inline-flex items-center gap-1"
          >
            <span>Firebase Console پر تفصیلات دیکھیں</span>
            <span>↗</span>
          </a>
        </div>
      )}

      {/* 2. Main Tab Content Container */}
      <main className="max-w-7xl mx-auto px-3 sm:px-6 py-6 pb-20">
        {/* DASHBOARD TAB */}
        {activeTab === 'dashboard' && (
          <Dashboard
            students={data.students}
            attendance={data.attendance}
            hifzDiary={data.hifzDiary}
            feePayments={data.feePayments}
            donations={data.donations}
            expenses={data.expenses}
            notices={data.notices || []}
            lang={lang}
            currentRole={currentRole}
            onNavigateTab={setActiveTab}
            onOpenQuickAddStudent={() => {
              setActiveTab('students');
              setIsQuickAddStudentOpen(true);
            }}
            onOpenQuickCollectFee={() => {
              setActiveTab('fees');
              setIsQuickCollectFeeOpen(true);
            }}
            onOpenQuickLogHifz={() => {
              setActiveTab('hifz');
              setIsQuickLogSabaqOpen(true);
            }}
            onOpenWhatsAppCenter={() => handleOpenWhatsApp('absent')}
            onOpenShortcutsModal={() => setIsShortcutsModalOpen(true)}
            onUpdateAttendance={handleUpdateAttendance}
            parentStudentMobile={parentStudentMobile}
          />
        )}

        {/* STUDENTS TAB */}
        {activeTab === 'students' && (
          <StudentsView
            students={data.students}
            onAddStudent={handleAddStudent}
            onUpdateStudent={handleUpdateStudent}
            onDeleteStudent={handleDeleteStudent}
            onPrintIdCard={handlePrintStudentIdCard}
            lang={lang}
            currentRole={currentRole}
            activeTeacherName={activeTeacherName}
            teachers={data.teachers}
            isQuickAddOpen={isQuickAddStudentOpen}
            onCloseQuickAdd={() => setIsQuickAddStudentOpen(false)}
            hifzDiary={data.hifzDiary}
            attendance={data.attendance}
            feePayments={data.feePayments}
            mushafData={data.mushafProgress || {}}
          />
        )}

        {/* ATTENDANCE TAB */}
        {activeTab === 'attendance' && (
          <AttendanceView
            students={data.students}
            attendance={data.attendance}
            onUpdateAttendance={handleUpdateAttendance}
            lang={lang}
            currentRole={currentRole}
            activeTeacherName={activeTeacherName}
            teachers={data.teachers}
            parentStudentMobile={parentStudentMobile}
          />
        )}

        {/* HIFZ PROGRESS DIARY TAB */}
        {activeTab === 'hifz' && (
          <HifzDiaryView
            students={data.students}
            hifzDiary={data.hifzDiary}
            onAddDiaryEntry={handleAddDiaryEntry}
            onUpdateParas={handleUpdateParas}
            lang={lang}
            currentRole={currentRole}
            activeTeacherName={activeTeacherName}
            teachers={data.teachers}
            isQuickLogOpen={isQuickLogSabaqOpen}
            onCloseQuickLog={() => setIsQuickLogSabaqOpen(false)}
            parentStudentMobile={parentStudentMobile}
          />
        )}

        {/* MUSHAF 30 PARAS PROGRESS TRACKER TAB */}
        {activeTab === 'mushaf' && (
          <MushafView
            students={data.students}
            mushafProgress={data.mushafProgress || {}}
            onUpdateMushafProgress={handleUpdateMushafProgress}
            hifzDiary={data.hifzDiary}
            lang={lang}
            currentRole={currentRole}
            activeTeacherName={activeTeacherName}
            parentStudentMobile={parentStudentMobile}
          />
        )}

        {/* SMART REVISION SCHEDULER TAB */}
        {activeTab === 'revision' && (
          <SmartRevisionSchedulerView
            students={data.students}
            hifzDiary={data.hifzDiary}
            onAddDiaryEntry={handleAddDiaryEntry}
            onNavigateTab={setActiveTab}
            lang={lang}
            currentRole={currentRole}
            activeTeacherName={activeTeacherName}
            parentStudentMobile={parentStudentMobile}
          />
        )}

        {/* 12-WEEK DINIYAT & ETHICS SYLLABUS TAB */}
        {activeTab === 'diniyat' && (
          <DiniyatSyllabusView
            students={data.students}
            lang={lang}
            currentRole={currentRole}
            activeTeacherName={activeTeacherName}
            parentStudentMobile={parentStudentMobile}
            onNavigateTab={setActiveTab}
          />
        )}

        {/* DONORS DIRECTORY & MANAGEMENT TAB */}
        {activeTab === 'donors' && (
          <DonationsView
            donations={data.donations}
            expenses={data.expenses}
            donors={data.donors || []}
            onAddDonation={handleAddDonation}
            onAddExpense={handleAddExpense}
            onAddDonor={handleAddDonor}
            onPrintDonationVoucher={handlePrintDonationVoucher}
            lang={lang}
            currentRole={currentRole}
            initialTab="donors"
          />
        )}

        {/* FEES & DEFAULTERS TAB */}
        {activeTab === 'fees' && (
          <FeeManagementView
            students={data.students}
            feePayments={data.feePayments}
            onAddFeePayment={handleAddFeePayment}
            onPrintReceipt={handlePrintFeeReceipt}
            lang={lang}
            currentRole={currentRole}
            activeTeacherName={activeTeacherName}
            isQuickCollectOpen={isQuickCollectFeeOpen}
            onCloseQuickCollect={() => setIsQuickCollectFeeOpen(false)}
            parentStudentMobile={parentStudentMobile}
          />
        )}

        {/* DONATIONS & EXPENSES LEDGER TAB */}
        {activeTab === 'donations' && (
          <DonationsView
            donations={data.donations}
            expenses={data.expenses}
            donors={data.donors || []}
            onAddDonation={handleAddDonation}
            onAddExpense={handleAddExpense}
            onAddDonor={handleAddDonor}
            onPrintDonationVoucher={handlePrintDonationVoucher}
            lang={lang}
            currentRole={currentRole}
          />
        )}

        {/* EXAMINATIONS & RESULT CARDS TAB */}
        {activeTab === 'exams' && (
          <ExamsView
            students={data.students}
            exams={data.exams || []}
            onAddExam={handleAddExamRecord}
            onPrintResultCard={handlePrintResultCard}
            lang={lang}
            currentRole={currentRole}
            activeTeacherName={activeTeacherName}
            teachers={data.teachers}
            parentStudentMobile={parentStudentMobile}
          />
        )}

        {/* ANNOUNCEMENTS & NOTICE BOARD TAB */}
        {activeTab === 'notices' && (
          <NoticeBoardView
            notices={data.notices || []}
            students={data.students}
            onAddNotice={handleAddNotice}
            onUpdateNotice={handleUpdateNotice}
            onDeleteNotice={handleDeleteNotice}
            lang={lang}
            currentRole={currentRole}
          />
        )}

        {/* CLASS TIMETABLE TAB */}
        {activeTab === 'timetable' && (
          <TimetableView
            timetable={data.timetable}
            onUpdateTimetable={handleUpdateTimetable}
            lang={lang}
            currentRole={currentRole}
          />
        )}

        {/* REPORTS, EXPORT & BACKUP TAB */}
        {activeTab === 'reports' && (
          <ReportsBackupView
            students={data.students}
            donations={data.donations}
            expenses={data.expenses}
            feePayments={data.feePayments}
            settings={data.settings}
            onUpdateSettings={handleUpdateSettings}
            onRestoreData={handleRestoreData}
            onResetToDefaults={handleResetToDefaults}
            onDownloadSingleFile={handleDownloadSingleFile}
            lang={lang}
            currentRole={currentRole}
            onPrintStudentIdCard={handlePrintStudentIdCard}
          />
        )}
      </main>

      {/* 3. Footer Bar */}
      <footer className="no-print bg-[#0a4221] text-emerald-200 border-t-2 border-amber-500/50 py-6 px-4 text-center text-xs">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="text-xl">🕌</span>
            <span className="font-urdu font-bold text-white text-sm">
              {data.settings.madrasaNameUr} - {data.settings.taglineUr}
            </span>
          </div>

          <div className="text-emerald-300/80 font-urdu text-[11px]">
            {lang === 'ur'
              ? 'مدرسہ قاسمیہ کا آف لائن کمپیوٹرائزڈ پورٹل | 100 فیصد مقامی ڈیٹا کا تحفظ'
              : 'Madarsa Qasmia Offline Management Portal | 100% Local Device Storage'}
          </div>

          <div className="flex items-center gap-2 text-[11px] font-mono">
            <span>v2.5 Full Edition</span>
            <span>•</span>
            <button
              onClick={handleDownloadSingleFile}
              className="text-amber-400 hover:underline cursor-pointer"
            >
              سنگل فائل HTML ڈاؤن لوڈ کریں 📥
            </button>
          </div>
        </div>
      </footer>

      {/* 4. Role Authentication Modal */}
      <RoleLoginModal
        isOpen={isRoleModalOpen}
        onClose={() => setIsRoleModalOpen(false)}
        currentRole={currentRole}
        activeTeacherName={activeTeacherName}
        teachers={data.teachers}
        onLoginSuccess={handleRoleLogin}
        onSelectRole={handleRoleLogin}
        settings={data.settings}
        students={data.students}
        lang={lang}
      />

      {/* 5. Printable Documents Modal */}
      <PrintModal
        isOpen={isPrintModalOpen}
        onClose={() => {
          setIsPrintModalOpen(false);
          setPrintDoc(null);
        }}
        documentData={printDoc}
        settings={data.settings}
        lang={lang}
      />

      {/* 6. WhatsApp Alerts & Messaging Center Modal */}
      <WhatsAppCenterModal
        isOpen={isWhatsAppCenterOpen}
        onClose={() => setIsWhatsAppCenterOpen(false)}
        students={data.students}
        attendance={data.attendance}
        hifzDiary={data.hifzDiary}
        feePayments={data.feePayments}
        donations={data.donations}
        notices={data.notices || []}
        settings={data.settings}
        lang={lang}
        initialTab={whatsAppInitialTab}
        preselectedStudentId={whatsAppInitialStudentId}
      />

      {/* 7. Install Mobile App PWA Modal */}
      <InstallAppModal
        isOpen={isInstallModalOpen}
        onClose={() => setIsInstallModalOpen(false)}
        lang={lang}
      />

      {/* 8. Full Source Code & ZIP Download Modal */}
      <SourceCodeDownloadModal
        isOpen={isSourceCodeModalOpen}
        onClose={() => setIsSourceCodeModalOpen(false)}
      />

      {/* 9. Keyboard Shortcuts & Quick Actions Help Modal */}
      <ShortcutsModal
        isOpen={isShortcutsModalOpen}
        onClose={() => setIsShortcutsModalOpen(false)}
        lang={lang}
        onNavigateTab={setActiveTab}
        onOpenQuickAddStudent={() => {
          setActiveTab('students');
          setIsQuickAddStudentOpen(true);
        }}
        onOpenQuickCollectFee={() => {
          setActiveTab('fees');
          setIsQuickCollectFeeOpen(true);
        }}
        onOpenQuickLogHifz={() => {
          setActiveTab('hifz');
          setIsQuickLogSabaqOpen(true);
        }}
        onOpenWhatsAppCenter={() => handleOpenWhatsApp('absent')}
        onOpenRoleModal={() => setIsRoleModalOpen(true)}
      />
    </div>
  );
}
