import React, { useState } from 'react';
import { Student, AttendanceRecord, AttendanceStatus, StudentClass, UserRole, TeacherProfile } from '../types';
import { initialTeachers } from '../data/initialData';
import { translations, Language } from '../i18n/translations';
import { createWhatsAppLink } from '../utils/storage';
import {
  CheckCircle2,
  XCircle,
  Clock,
  Send,
  Calendar,
  Filter,
  CheckCheck,
  Search,
} from 'lucide-react';

interface AttendanceViewProps {
  students: Student[];
  attendance: AttendanceRecord[];
  onUpdateAttendance: (records: AttendanceRecord[]) => void;
  lang: Language;
  currentRole: UserRole;
  activeTeacherName?: string;
  teachers?: TeacherProfile[];
  parentStudentMobile?: string;
}

export const AttendanceView: React.FC<AttendanceViewProps> = ({
  students,
  attendance,
  onUpdateAttendance,
  lang,
  currentRole,
  activeTeacherName = 'قاری عبد الوحید',
  teachers = initialTeachers,
  parentStudentMobile,
}) => {
  const t = translations[lang];
  const [selectedDate, setSelectedDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [selectedClass, setSelectedClass] = useState<string>('all');
  const [teacherFilter, setTeacherFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Filter students
  let visibleStudents = students;
  if (currentRole === 'parent' && parentStudentMobile) {
    const cleanDigits = parentStudentMobile.replace(/[^0-9]/g, '');
    visibleStudents = students.filter((s) => {
      const sDigits = s.parentMobile.replace(/[^0-9]/g, '');
      return sDigits.includes(cleanDigits) || cleanDigits.includes(sDigits);
    });
  } else if (currentRole === 'ustad') {
    // Strict Teacher Isolation: Ustaad ONLY sees their assigned students!
    visibleStudents = students.filter((s) => s.ustadName === activeTeacherName);
  } else {
    // Admin filter
    if (teacherFilter !== 'all') {
      visibleStudents = visibleStudents.filter((s) => s.ustadName === teacherFilter);
    }
    if (selectedClass !== 'all') {
      visibleStudents = visibleStudents.filter((s) => s.class === selectedClass);
    }
  }

  if (searchQuery) {
    const q = searchQuery.toLowerCase();
    visibleStudents = visibleStudents.filter(
      (s) => s.nameUr.includes(q) || s.rollNo.toLowerCase().includes(q)
    );
  }

  // Get status for student on selectedDate
  const getStatus = (studentId: string): AttendanceStatus => {
    const rec = attendance.find(
      (a) => a.studentId === studentId && a.date === selectedDate
    );
    return rec ? rec.status : 'present'; // default present
  };

  const setStatus = (studentId: string, status: AttendanceStatus) => {
    const existingIndex = attendance.findIndex(
      (a) => a.studentId === studentId && a.date === selectedDate
    );

    let updated = [...attendance];
    if (existingIndex >= 0) {
      updated[existingIndex] = {
        ...updated[existingIndex],
        status,
      };
    } else {
      updated.push({
        id: `att-${Date.now()}-${studentId}`,
        studentId,
        date: selectedDate,
        status,
      });
    }

    onUpdateAttendance(updated);
  };

  const handleMarkAllPresent = () => {
    let updated = [...attendance];
    visibleStudents.forEach((s) => {
      const idx = updated.findIndex(
        (a) => a.studentId === s.id && a.date === selectedDate
      );
      if (idx >= 0) {
        updated[idx] = { ...updated[idx], status: 'present' };
      } else {
        updated.push({
          id: `att-${Date.now()}-${s.id}`,
          studentId: s.id,
          date: selectedDate,
          status: 'present',
        });
      }
    });
    onUpdateAttendance(updated);
  };

  // WhatsApp Absent Alert
  const handleSendWhatsAppAbsent = (student: Student) => {
    const message =
      lang === 'ur'
        ? `محترم سرپرست! السلام علیکم، آپ کا فرزند "${student.nameUr}" (رول نمبر: ${student.rollNo}) آج بتاریخ ${selectedDate} مدرسہ قاسمیہ سے غیر حاضر ہے۔ برائے مہربانی غیر حاضری کی وجہ سے مطلع فرمائیں۔ شکریہ - انتظامیہ مدرسہ قاسمیہ`
        : `Respected Guardian! Assalamu Alaikum, your child ${student.nameEn || student.nameUr} (Roll: ${student.rollNo}) is absent today (${selectedDate}) from Madarsa Qasmia. Kindly inform us of the reason. JazakAllah - Madarsa Qasmia Administration`;

    const url = createWhatsAppLink(student.parentMobile, message);
    window.open(url, '_blank');
  };

  // Stats for the selected day
  const dayRecords = attendance.filter((a) => a.date === selectedDate);
  const presentCount = visibleStudents.filter(
    (s) => getStatus(s.id) === 'present'
  ).length;
  const absentCount = visibleStudents.filter(
    (s) => getStatus(s.id) === 'absent'
  ).length;
  const leaveCount = visibleStudents.filter(
    (s) => getStatus(s.id) === 'leave'
  ).length;

  return (
    <div className="space-y-6 animate-in fade-in duration-300 font-urdu">
      {/* Top Controls Header */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-teal-100 text-teal-800 flex items-center justify-center text-3xl shadow-inner">
            ✅
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-emerald-950 font-urdu">
              {t.attendanceRegister}
            </h2>
            <p className="text-xs text-slate-500 font-urdu">
              {lang === 'ur'
                ? 'ایک کلک میں حاضری، غیر حاضری اور واٹس ایپ اطلاع'
                : '1-click attendance marking and instant WhatsApp parent alerts'}
            </p>
          </div>
        </div>

        {/* Date Selector & Mark All Present */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 bg-slate-100 px-3 py-2 rounded-2xl border border-slate-200">
            <Calendar className="w-4 h-4 text-emerald-700" />
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="bg-transparent font-mono font-bold text-sm text-slate-800 focus:outline-none"
            />
          </div>

          {currentRole !== 'parent' && (
            <button
              onClick={handleMarkAllPresent}
              className="flex items-center gap-2 bg-[#0F5D2F] hover:bg-emerald-800 text-white font-bold px-4 py-2 rounded-2xl shadow-sm transition-all active:scale-95 cursor-pointer text-xs sm:text-sm"
            >
              <CheckCheck className="w-4 h-4 text-amber-400" />
              <span>{t.markAllPresent}</span>
            </button>
          )}
        </div>
      </div>

      {/* Summary KPI Banner for Selected Day */}
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-emerald-50 border-2 border-emerald-200 p-4 rounded-2xl text-center">
          <span className="text-2xl block mb-1">✅</span>
          <span className="text-xs font-bold text-emerald-800 block">
            {t.present} (حاضر)
          </span>
          <span className="text-2xl sm:text-3xl font-black text-emerald-950 font-mono">
            {presentCount}
          </span>
        </div>

        <div className="bg-rose-50 border-2 border-rose-200 p-4 rounded-2xl text-center">
          <span className="text-2xl block mb-1">❌</span>
          <span className="text-xs font-bold text-rose-800 block">
            {t.absent} (غیر حاضر)
          </span>
          <span className="text-2xl sm:text-3xl font-black text-rose-950 font-mono">
            {absentCount}
          </span>
        </div>

        <div className="bg-amber-50 border-2 border-amber-200 p-4 rounded-2xl text-center">
          <span className="text-2xl block mb-1">⏸️</span>
          <span className="text-xs font-bold text-amber-800 block">
            {t.leave} (رخصت)
          </span>
          <span className="text-2xl sm:text-3xl font-black text-amber-950 font-mono">
            {leaveCount}
          </span>
        </div>
      </div>

      {/* Class Filter Chips & Search */}
      {currentRole !== 'parent' && (
        <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2">
              {[
                { id: 'all', label: t.allClasses },
                { id: 'Hifz', label: t.classHifz },
                { id: 'Nazra', label: t.classNazra },
                { id: 'Qaida', label: t.classQaida },
                { id: 'Alim', label: t.classAlim },
                { id: 'Deeniat', label: t.classDeeniat },
              ].map((c) => (
                <button
                  key={c.id}
                  onClick={() => setSelectedClass(c.id)}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    selectedClass === c.id
                      ? 'bg-[#0F5D2F] text-white shadow-sm'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                  }`}
                >
                  {c.label}
                </button>
              ))}
            </div>

            <div className="w-full sm:w-64 relative">
              <Search className="w-4 h-4 absolute right-3 top-2.5 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="نام یا رول نمبر سے تلاش کریں..."
                className="w-full pl-3 pr-9 py-2 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white text-xs font-urdu"
              />
            </div>
          </div>

          {currentRole === 'admin' && (
            <div className="flex items-center gap-2 flex-wrap pt-2 border-t border-slate-100 text-xs font-urdu">
              <span className="font-bold text-slate-700 flex items-center gap-1">
                <span>📖</span>
                <span>اساتذہ فلٹر:</span>
              </span>
              <button
                onClick={() => setTeacherFilter('all')}
                className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                  teacherFilter === 'all'
                    ? 'bg-emerald-800 text-white shadow-xs'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                تمام اساتذہ
              </button>
              {teachers.map((tch) => (
                <button
                  key={tch.id}
                  onClick={() => setTeacherFilter(tch.nameUr)}
                  className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                    teacherFilter === tch.nameUr
                      ? 'bg-amber-500 text-slate-900 shadow-xs ring-2 ring-amber-600/30'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                  }`}
                >
                  {tch.nameUr}
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Attendance Cards List (Engineered for Illiterate / Touchscreen Accessibility) */}
      <div className="space-y-3">
        {visibleStudents.map((student) => {
          const status = getStatus(student.id);

          return (
            <div
              key={student.id}
              className={`bg-white rounded-2xl p-4 border-2 transition-all shadow-xs flex flex-wrap items-center justify-between gap-4 ${
                status === 'present'
                  ? 'border-emerald-200 hover:border-emerald-400'
                  : status === 'absent'
                  ? 'border-rose-300 bg-rose-50/30 hover:border-rose-400'
                  : 'border-amber-200 bg-amber-50/20 hover:border-amber-400'
              }`}
            >
              {/* Student Identity */}
              <div className="flex items-center gap-3.5 min-w-[200px]">
                <div
                  className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl font-bold border shrink-0 ${
                    status === 'present'
                      ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                      : status === 'absent'
                      ? 'bg-rose-100 text-rose-800 border-rose-300'
                      : 'bg-amber-100 text-amber-800 border-amber-300'
                  }`}
                >
                  {status === 'present' ? '✅' : status === 'absent' ? '❌' : '⏸️'}
                </div>

                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-base text-slate-900 font-urdu">
                      {student.nameUr}
                    </h3>
                    <span className="font-mono text-xs text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded">
                      {student.rollNo}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 font-urdu mt-0.5">
                    والد: {student.fatherNameUr} | درجہ: {student.class} |{' '}
                    {student.isHostel ? 'مقیم' : 'غیر مقیم'}
                  </p>
                </div>
              </div>

              {/* Attendance Buttons or Status Display */}
              <div className="flex flex-wrap items-center gap-2 sm:gap-3">
                {currentRole !== 'parent' ? (
                  <>
                    {/* Present Button */}
                    <button
                      onClick={() => setStatus(student.id, 'present')}
                      className={`flex items-center gap-1.5 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-black transition-all cursor-pointer active:scale-95 border-2 ${
                        status === 'present'
                          ? 'bg-emerald-700 text-white border-emerald-800 shadow-md ring-2 ring-emerald-600/30'
                          : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border-emerald-200'
                      }`}
                    >
                      <span className="text-lg">✅</span>
                      <span>حاضر</span>
                    </button>

                    {/* Absent Button */}
                    <button
                      onClick={() => setStatus(student.id, 'absent')}
                      className={`flex items-center gap-1.5 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-black transition-all cursor-pointer active:scale-95 border-2 ${
                        status === 'absent'
                          ? 'bg-rose-700 text-white border-rose-800 shadow-md ring-2 ring-rose-600/30'
                          : 'bg-rose-50 hover:bg-rose-100 text-rose-900 border-rose-200'
                      }`}
                    >
                      <span className="text-lg">❌</span>
                      <span>غیر حاضر</span>
                    </button>

                    {/* Leave Button */}
                    <button
                      onClick={() => setStatus(student.id, 'leave')}
                      className={`flex items-center gap-1.5 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-black transition-all cursor-pointer active:scale-95 border-2 ${
                        status === 'leave'
                          ? 'bg-amber-600 text-white border-amber-700 shadow-md ring-2 ring-amber-600/30'
                          : 'bg-amber-50 hover:bg-amber-100 text-amber-900 border-amber-200'
                      }`}
                    >
                      <span className="text-lg">⏸️</span>
                      <span>رخصت</span>
                    </button>

                    {/* Direct WhatsApp Absent Alert Button */}
                    {status === 'absent' && (
                      <button
                        onClick={() => handleSendWhatsAppAbsent(student)}
                        title="والد کو واٹس ایپ اطلاع بھیجیں"
                        className="flex items-center gap-1.5 px-3 py-2.5 rounded-2xl bg-[#25D366] hover:bg-[#20ba5a] text-white font-bold text-xs transition-all shadow-md cursor-pointer active:scale-95"
                      >
                        <Send className="w-4 h-4" />
                        <span className="hidden sm:inline">واٹس ایپ اطلاع 💬</span>
                        <span className="sm:hidden">💬</span>
                      </button>
                    )}
                  </>
                ) : (
                  /* Parent Read-Only View */
                  <div className="flex items-center gap-2">
                    <span
                      className={`px-4 py-2 rounded-xl font-bold text-sm font-urdu ${
                        status === 'present'
                          ? 'bg-emerald-100 text-emerald-900'
                          : status === 'absent'
                          ? 'bg-rose-100 text-rose-900'
                          : 'bg-amber-100 text-amber-900'
                      }`}
                    >
                      {status === 'present' && 'آج حاضر ہیں ✅'}
                      {status === 'absent' && 'آج غیر حاضر ہیں ❌'}
                      {status === 'leave' && 'رخصت پر ہیں ⏸️'}
                    </span>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
