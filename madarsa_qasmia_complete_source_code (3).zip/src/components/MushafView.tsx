import React, { useState } from 'react';
import { Student, MushafData, UserRole, HifzDiaryEntry } from '../types';
import { Language } from '../i18n/translations';
import {
  BookMarked,
  CheckCircle2,
  RotateCcw,
  Sparkles,
  ChevronRight,
  ChevronLeft,
  Award,
  Check,
  Flame,
  Layers,
  ListChecks,
} from 'lucide-react';
import { createDefaultMushafStudent } from '../data/initialData';
import { quran30ParasMeta, ParaMeta } from '../data/quranParasMeta';

interface MushafViewProps {
  students: Student[];
  mushafProgress: MushafData;
  onUpdateMushafProgress: (newProgress: MushafData) => void;
  hifzDiary: HifzDiaryEntry[];
  lang: Language;
  currentRole: UserRole;
  activeTeacherName?: string;
  parentStudentMobile?: string;
}

export const MushafView: React.FC<MushafViewProps> = ({
  students,
  mushafProgress,
  onUpdateMushafProgress,
  hifzDiary,
  lang,
  currentRole,
  activeTeacherName = 'قاری عبد الوحید',
  parentStudentMobile,
}) => {
  const visibleStudents =
    currentRole === 'parent' && parentStudentMobile
      ? students.filter((s) => {
          const cleanDigits = parentStudentMobile.replace(/[^0-9]/g, '');
          const sDigits = s.parentMobile.replace(/[^0-9]/g, '');
          return sDigits.includes(cleanDigits) || cleanDigits.includes(sDigits);
        })
      : currentRole === 'ustad'
      ? students.filter((s) => s.ustadName === activeTeacherName)
      : students;

  const [selectedStudentId, setSelectedStudentId] = useState<string>(
    visibleStudents[0]?.id || ''
  );
  const [activePara, setActivePara] = useState<number>(1);

  const selectedStudent = students.find((s) => s.id === selectedStudentId);

  // Active Para metadata
  const currentParaMeta: ParaMeta =
    quran30ParasMeta.find((p) => p.paraNumber === activePara) || quran30ParasMeta[0];
  const totalRukuInActivePara = currentParaMeta.rukuCount;

  // Ensure current student's progress is initialized with the correct ruku length
  const studentMushaf =
    mushafProgress[selectedStudentId] || createDefaultMushafStudent();
  
  // Safe extraction of ruku array, matching total rukus in this para
  const rawRukus = studentMushaf[activePara] || [];
  const currentParaRukus =
    rawRukus.length === totalRukuInActivePara
      ? rawRukus
      : Array.from({ length: totalRukuInActivePara }, (_, i) => rawRukus[i] ?? 0);

  // Get last recorded diary entry for selected student
  const lastEntry = hifzDiary
    .filter((d) => d.studentId === selectedStudentId)
    .sort((a, b) => b.date.localeCompare(a.date))[0];

  // Helper to calculate percentage of a para based on rukus
  const getParaPercentage = (studentId: string, para: number) => {
    const meta = quran30ParasMeta.find((p) => p.paraNumber === para);
    const expectedLength = meta ? meta.rukuCount : 20;
    const rukus = (mushafProgress[studentId] || {})[para] || [];
    if (rukus.length === 0 || rukus.every((l) => l === 0)) return 0;
    
    const totalPoints = rukus.slice(0, expectedLength).reduce(
      (sum, val) => sum + (val === 1 ? 100 : val === 2 ? 60 : val === 3 ? 20 : 0),
      0
    );
    return Math.round(totalPoints / expectedLength);
  };

  // Color mapper for para percentage badges
  const getBadgeColor = (pct: number) => {
    if (pct === 0) return 'bg-slate-200 text-slate-700 hover:bg-slate-300';
    if (pct >= 85) return 'bg-emerald-600 text-white hover:bg-emerald-700';
    if (pct >= 60) return 'bg-amber-500 text-white hover:bg-amber-600';
    return 'bg-rose-500 text-white hover:bg-rose-600';
  };

  // Toggle ruku state: 0 (غیر شروع) -> 1 (پکا 100%) -> 2 (مناسب 60%) -> 3 (کمزور 20%) -> 0
  const handleToggleRuku = (rukuIndex: number) => {
    if (currentRole === 'parent') return; // Read-only for parents
    const updatedRukus = [...currentParaRukus];
    updatedRukus[rukuIndex] = (updatedRukus[rukuIndex] + 1) % 4;

    const updatedStudentMushaf = {
      ...studentMushaf,
      [activePara]: updatedRukus,
    };

    onUpdateMushafProgress({
      ...mushafProgress,
      [selectedStudentId]: updatedStudentMushaf,
    });
  };

  // Set all rukus in active para to specific status
  const handleSetAllRukus = (status: number) => {
    if (currentRole === 'parent') return;
    const updatedRukus = Array(totalRukuInActivePara).fill(status);
    const updatedStudentMushaf = {
      ...studentMushaf,
      [activePara]: updatedRukus,
    };
    onUpdateMushafProgress({
      ...mushafProgress,
      [selectedStudentId]: updatedStudentMushaf,
    });
  };

  // Total Quran Completed Paras calculation (80%+ threshold)
  const totalCompletedParasCount = Array.from({ length: 30 }, (_, i) => i + 1).filter(
    (p) => getParaPercentage(selectedStudentId, p) >= 80
  ).length;

  const activeParaPct = getParaPercentage(selectedStudentId, activePara);

  // For Para 30, map each Ruku to its respective Surah
  // Para 30 has 37 surahs: An-Naba (2 rukus), An-Nazi'at (2 rukus), and 35 surahs (1 ruku each) = 39 rukus
  const getPara30SurahForRuku = (rukuIdx: number) => {
    if (activePara !== 30 || !currentParaMeta.surahsInPara) return null;
    let accumulated = 0;
    for (const surah of currentParaMeta.surahsInPara) {
      if (rukuIdx < accumulated + surah.rukuCount) {
        const surahRukuNumber = rukuIdx - accumulated + 1;
        return {
          ...surah,
          surahRukuNumber,
        };
      }
      accumulated += surah.rukuCount;
    }
    return null;
  };

  return (
    <div className="space-y-6 font-urdu animate-in fade-in duration-300">
      {/* Top Banner Header */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-13 h-13 rounded-2xl bg-emerald-100 text-emerald-900 flex items-center justify-center text-3xl shadow-inner border border-emerald-200">
            📖
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl sm:text-2xl font-black text-emerald-950 font-urdu">
                مصحف شریف - ۳۰ پارہ بمطابق رکوعات و سورۃ ٹریکر
              </h2>
              <span className="bg-amber-400 text-emerald-950 text-[11px] font-black px-2.5 py-0.5 rounded-full font-urdu">
                مستند رکوعات پر مبنی
              </span>
            </div>
            <p className="text-xs text-slate-500 font-urdu mt-0.5">
              سطروں کی بجائے اصل قرآن مجید کے تمام پارے رکوع کی بنیاد پر اور ۳۰ واں پارہ تمام ۳۷ سورتوں کے رکوعات کے ساتھ
            </p>
          </div>
        </div>

        {/* Global Progress Pill */}
        <div className="flex items-center gap-3 bg-emerald-50 px-4 py-2 rounded-2xl border border-emerald-200">
          <Award className="w-5 h-5 text-amber-500" />
          <div className="text-right">
            <span className="text-[11px] text-emerald-900 block font-bold">پختہ پارے (80%+):</span>
            <span className="font-mono text-base font-black text-[#0F5D2F]">
              {totalCompletedParasCount} / 30 پارے
            </span>
          </div>
        </div>
      </div>

      {/* Student Carousel / Selection Tabs */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs">
        <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
          طالب علم کا انتخاب فرمائیں:
        </label>
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          {visibleStudents.map((s) => {
            const isSelected = selectedStudentId === s.id;
            const completedCount = Array.from({ length: 30 }, (_, i) => i + 1).filter(
              (p) => getParaPercentage(s.id, p) >= 80
            ).length;

            return (
              <button
                key={s.id}
                onClick={() => setSelectedStudentId(s.id)}
                className={`flex items-center gap-2.5 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition-all cursor-pointer shrink-0 border-2 ${
                  isSelected
                    ? 'bg-[#0F5D2F] text-white border-emerald-800 shadow-md ring-2 ring-emerald-600/30'
                    : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                }`}
              >
                <span className="text-base">🎓</span>
                <div className="text-right">
                  <span className="block font-bold">{s.nameUr}</span>
                  <span
                    className={`block text-[10px] font-mono ${
                      isSelected ? 'text-emerald-200' : 'text-slate-400'
                    }`}
                  >
                    {s.class} • {completedCount} پارے پختہ
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Current Student & Active Para Status Strip */}
      {selectedStudent && (
        <div className="bg-gradient-to-r from-emerald-900 to-[#0F5D2F] text-white rounded-3xl p-5 shadow-md flex flex-wrap items-center justify-between gap-4 border-b-4 border-amber-400">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-white/15 flex items-center justify-center text-2xl border border-white/20">
              🌟
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg sm:text-xl font-black">{selectedStudent.nameUr}</h3>
                <span className="bg-amber-400 text-emerald-950 text-xs font-mono font-bold px-2 py-0.5 rounded">
                  {selectedStudent.rollNo}
                </span>
              </div>
              <p className="text-xs text-emerald-100 mt-0.5">
                والد: {selectedStudent.fatherNameUr} | درجہ: {selectedStudent.class}
                {lastEntry && (
                  <span className="mr-2 text-amber-200">
                    (آخری ڈائری: پارہ {lastEntry.sabaqPara} - {lastEntry.sabaqLinesOrPages})
                  </span>
                )}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="bg-emerald-950/70 px-4 py-2 rounded-xl border border-emerald-700/50 text-center">
              <span className="text-[11px] text-emerald-200 block">پارہ {activePara} ({currentParaMeta.nameUr})</span>
              <span className="font-mono text-base font-bold text-emerald-300">
                کل {totalRukuInActivePara} رکوع
              </span>
            </div>
            <div className="bg-emerald-950/70 px-4 py-2 rounded-xl border border-emerald-700/50 text-center">
              <span className="text-[11px] text-emerald-200 block">پیش رفت</span>
              <span className="font-mono text-xl font-black text-amber-300">
                {activeParaPct}%
              </span>
            </div>
          </div>
        </div>
      )}

      {/* 30-Para Visual Grid Selector */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2 font-bold text-slate-800 text-sm">
            <BookMarked className="w-4 h-4 text-emerald-700" />
            <span>۳۰ پارے انتخاب گرڈ (ہر پارے کے اپنے اصل رکوعات):</span>
          </div>
          {/* Legend */}
          <div className="flex items-center gap-2 text-[11px] flex-wrap">
            <span className="flex items-center gap-1">
              <span className="w-3 h-3 rounded-full bg-emerald-600 inline-block"></span>
              <span>85%+ پکا</span>
            </span>
            <span className="flex items-center gap-1">
              <span className="w-3 h-3 rounded-full bg-amber-500 inline-block"></span>
              <span>60-84% مناسب</span>
            </span>
            <span className="flex items-center gap-1">
              <span className="w-3 h-3 rounded-full bg-rose-500 inline-block"></span>
              <span>کمزور</span>
            </span>
            <span className="flex items-center gap-1">
              <span className="w-3 h-3 rounded-full bg-slate-200 inline-block"></span>
              <span>غیر شروع</span>
            </span>
          </div>
        </div>

        <div className="grid grid-cols-5 sm:grid-cols-6 md:grid-cols-10 gap-2">
          {quran30ParasMeta.map((pMeta) => {
            const p = pMeta.paraNumber;
            const pct = getParaPercentage(selectedStudentId, p);
            const isActive = activePara === p;

            return (
              <button
                key={p}
                onClick={() => setActivePara(p)}
                className={`py-2 px-1 rounded-xl text-center transition-all cursor-pointer font-bold relative shadow-xs ${getBadgeColor(
                  pct
                )} ${
                  isActive
                    ? 'ring-4 ring-emerald-800 ring-offset-2 scale-105 z-10'
                    : 'hover:scale-102'
                }`}
              >
                <span className="block text-xs sm:text-sm">پارہ {p}</span>
                <span className="block text-[10px] font-urdu opacity-90 truncate px-0.5">{pMeta.nameUr}</span>
                <span className="block text-[9px] font-mono opacity-85 mt-0.5">{pMeta.rukuCount} رکوع</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Ruku-by-Ruku Interactive Mushaf Page View */}
      <div className="bg-[#FCFBF7] rounded-3xl p-5 sm:p-7 border-2 border-amber-200/80 shadow-md space-y-4">
        {/* Page Top Header */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b-2 border-amber-200 pb-3">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActivePara(Math.max(1, activePara - 1))}
              disabled={activePara === 1}
              className="p-2 rounded-xl bg-white border border-amber-200 text-slate-700 hover:bg-amber-50 disabled:opacity-30 cursor-pointer"
              title="پچھلا پارہ"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
            <div>
              <h4 className="text-lg sm:text-xl font-black text-emerald-950 font-urdu flex items-center gap-2">
                <span>پارہ نمبر {activePara}: {currentParaMeta.nameUr} ({currentParaMeta.nameEn})</span>
                <span className="bg-amber-400 text-emerald-950 text-xs px-2.5 py-0.5 rounded-full font-mono">
                  {totalRukuInActivePara} رکوع
                </span>
              </h4>
              <p className="text-xs text-amber-900/80">
                {activePara === 30
                  ? '۳۰ واں پارہ (عم یتساءلون): تمام ۳۷ سورتیں بمطابق مستند رکوعات'
                  : `آغاز: سورۃ ${currentParaMeta.startSurah} (آیت ${currentParaMeta.startAyat}) • کل رکوعات: ${totalRukuInActivePara}`}
              </p>
            </div>
            <button
              onClick={() => setActivePara(Math.min(30, activePara + 1))}
              disabled={activePara === 30}
              className="p-2 rounded-xl bg-white border border-amber-200 text-slate-700 hover:bg-amber-50 disabled:opacity-30 cursor-pointer"
              title="اگلا پارہ"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
          </div>

          {currentRole !== 'parent' && (
            <div className="flex items-center gap-2">
              <button
                onClick={() => handleSetAllRukus(1)}
                className="flex items-center gap-1 text-xs bg-emerald-700 hover:bg-emerald-800 text-white font-bold px-3 py-1.5 rounded-xl cursor-pointer shadow-xs transition"
              >
                <Check className="w-3.5 h-3.5" />
                <span>تمام رکوع پکا کریں (سبز)</span>
              </button>
              <button
                onClick={() => handleSetAllRukus(0)}
                className="flex items-center gap-1 text-xs bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold px-3 py-1.5 rounded-xl cursor-pointer transition"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>ری سیٹ</span>
              </button>
            </div>
          )}
        </div>

        {/* Instructions banner */}
        <div className="bg-amber-50/80 border border-amber-300/80 p-3 rounded-2xl flex items-center justify-between text-xs text-amber-950">
          <div className="flex items-center gap-2">
            <span className="text-base">💡</span>
            <span>
              <strong>طریقہ کار:</strong> رکوع پر کلک کر کے پختگی تبدیل کریں: 
              <span className="text-slate-600 mr-1 font-bold">غیر شروع (سرمئی)</span> ⬅️
              <span className="text-emerald-700 mx-1 font-bold">پکا (سبز 100%)</span> ⬅️
              <span className="text-amber-700 mx-1 font-bold">مناسب (پیلا 60%)</span> ⬅️
              <span className="text-rose-700 mx-1 font-bold">کمزور (سرخ 20%)</span>
            </span>
          </div>
          <span className="text-slate-500 font-mono text-[11px] hidden sm:inline">
            کامیاب تکمیل: 85%+
          </span>
        </div>

        {/* Ruku List Rendering */}
        <div className="space-y-2.5 max-w-4xl mx-auto">
          {currentParaRukus.map((rukuVal, idx) => {
            let cardBg = 'bg-white border-slate-200 text-slate-800 hover:border-slate-300';
            let statusText = 'غیر شروع';
            let badgeBg = 'bg-slate-100 text-slate-600 border border-slate-300';

            if (rukuVal === 1) {
              cardBg = 'bg-emerald-50/90 border-emerald-400 text-emerald-950 font-bold shadow-xs';
              statusText = 'پکا یاد (100%)';
              badgeBg = 'bg-emerald-600 text-white';
            } else if (rukuVal === 2) {
              cardBg = 'bg-amber-50/90 border-amber-400 text-amber-950 font-bold shadow-xs';
              statusText = 'مناسب (60%)';
              badgeBg = 'bg-amber-500 text-white';
            } else if (rukuVal === 3) {
              cardBg = 'bg-rose-50/90 border-rose-300 text-rose-950 font-bold shadow-xs';
              statusText = 'کمزور / اعادہ (20%)';
              badgeBg = 'bg-rose-500 text-white';
            }

            // Para 30 special surah resolution
            const surahInfo = getPara30SurahForRuku(idx);

            return (
              <div
                key={idx}
                onClick={() => handleToggleRuku(idx)}
                className={`p-3.5 sm:px-5 sm:py-3.5 rounded-2xl border-2 transition-all flex flex-wrap items-center justify-between gap-3 ${
                  currentRole !== 'parent' ? 'cursor-pointer hover:scale-[1.008]' : ''
                } ${cardBg}`}
              >
                <div className="flex items-center gap-3">
                  <span className="w-8 h-8 rounded-full bg-amber-100 text-amber-950 border border-amber-300 font-mono text-xs font-black flex items-center justify-center shrink-0 shadow-2xs">
                    {idx + 1}
                  </span>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-base font-black text-emerald-950">
                        {surahInfo
                          ? `سورۃ ${surahInfo.nameUr} (${surahInfo.nameEn})`
                          : `رکوع نمبر ${idx + 1} - پارہ ${activePara}`}
                      </span>
                      {surahInfo && (
                        <span className="bg-emerald-100 text-emerald-900 text-[10px] px-2 py-0.5 rounded-full font-urdu font-bold">
                          {surahInfo.totalAyat} آیات {surahInfo.rukuCount > 1 ? `(رکوع ${surahInfo.surahRukuNumber}/${surahInfo.rukuCount})` : 'مکمل سورۃ'}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-500 font-urdu mt-0.5">
                      {surahInfo
                        ? `پارہ ۳۰ • رکوع ${idx + 1} از ۳۹ • سورۃ ${surahInfo.nameUr}`
                        : `پارہ ${activePara}: ${currentParaMeta.nameUr} • کل رکوعات میں سے رکوع نمبر ${idx + 1}`}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <span className={`text-[11px] px-3 py-1 rounded-full font-bold shadow-2xs ${badgeBg}`}>
                    {statusText}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom Page Footer Indicator */}
        <div className="text-center pt-3 border-t border-amber-200 text-xs text-amber-950/70 flex items-center justify-between">
          <span>مدرسہ قاسمیہ جامع نظامِ تعلیم - مصحف شریف ٹریکر (بمطابق رکوعات)</span>
          <span className="font-mono font-bold">
            پارہ {activePara} / 30 • کل {totalRukuInActivePara} رکوع
          </span>
        </div>
      </div>
    </div>
  );
};
