import React, { useState, useEffect, useRef } from 'react';
import { UserRole, Student, SystemSettings, TeacherProfile } from '../types';
import { translations, Language } from '../i18n/translations';
import {
  Lock,
  Smartphone,
  X,
  Check,
  ShieldAlert,
  KeyRound,
  ArrowRight,
  Zap,
  UserCheck,
  GraduationCap,
  Sparkles,
  BookOpen,
  User,
} from 'lucide-react';
import { initialTeachers } from '../data/initialData';

interface RoleLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentRole: UserRole;
  activeTeacherName?: string;
  settings: SystemSettings;
  teachers?: TeacherProfile[];
  students: Student[];
  onLoginSuccess?: (role: UserRole, mobileOrDetails?: string, teacherName?: string) => void;
  onSelectRole?: (role: UserRole, mobileOrDetails?: string, teacherName?: string) => void;
  lang: Language;
}

export const RoleLoginModal: React.FC<RoleLoginModalProps> = ({
  isOpen,
  onClose,
  currentRole,
  activeTeacherName,
  settings,
  teachers = initialTeachers,
  students,
  onLoginSuccess,
  onSelectRole,
  lang,
}) => {
  const t = translations[lang];

  const notifySuccess = (role: UserRole, mobile?: string, teacherName?: string) => {
    if (typeof onLoginSuccess === 'function') {
      onLoginSuccess(role, mobile, teacherName);
    } else if (typeof onSelectRole === 'function') {
      onSelectRole(role, mobile, teacherName);
    }
  };

  const [selectedRole, setSelectedRole] = useState<UserRole>(currentRole || 'admin');
  const [selectedTeacherId, setSelectedTeacherId] = useState<string>(
    teachers.find((t) => t.nameUr === activeTeacherName)?.id || teachers[0]?.id || ''
  );
  const [pin, setPin] = useState('');
  const [parentMobile, setParentMobile] = useState('');
  const [parentTeacherName, setParentTeacherName] = useState(teachers[0]?.nameUr || '');
  const [errorMsg, setErrorMsg] = useState('');
  const pinInputRef = useRef<HTMLInputElement>(null);

  // Sync state when opened
  useEffect(() => {
    if (isOpen) {
      setSelectedRole(currentRole || 'admin');
      setErrorMsg('');
      setPin('');
      if (currentRole === 'ustad' && activeTeacherName) {
        const found = teachers.find((t) => t.nameUr === activeTeacherName);
        if (found) setSelectedTeacherId(found.id);
      }
    }
  }, [isOpen, currentRole, activeTeacherName, teachers]);

  // Focus PIN input when applicable
  useEffect(() => {
    if (isOpen && selectedRole !== 'parent') {
      pinInputRef.current?.focus();
    }
  }, [isOpen, selectedRole, selectedTeacherId]);

  // Keyboard shortcut listener
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (selectedRole === 'parent') {
        if (e.key === 'Enter') {
          e.preventDefault();
          handleSubmit();
        }
        return;
      }

      if (e.key >= '0' && e.key <= '9') {
        if (pin.length < 6) {
          setPin((prev) => prev + e.key);
          setErrorMsg('');
        }
      } else if (e.key === 'Backspace') {
        setPin((prev) => prev.slice(0, -1));
        setErrorMsg('');
      } else if (e.key === 'Escape') {
        onClose();
      } else if (e.key === 'Enter') {
        e.preventDefault();
        handleSubmit();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, selectedRole, pin, parentMobile, parentTeacherName]);

  if (!isOpen) return null;

  const activeTeacher = teachers.find((t) => t.id === selectedTeacherId) || teachers[0];

  const handleRoleSelect = (role: UserRole) => {
    setSelectedRole(role);
    setPin('');
    setErrorMsg('');
  };

  const handleKeypadPress = (val: string) => {
    if (pin.length < 6) {
      setPin((prev) => prev + val);
      setErrorMsg('');
    }
  };

  const handleBackspace = () => {
    setPin((prev) => prev.slice(0, -1));
    setErrorMsg('');
  };

  const handleClear = () => {
    setPin('');
    setErrorMsg('');
  };

  const getExpectedPin = () => {
    if (selectedRole === 'admin') return settings.adminPin || '1234';
    if (selectedRole === 'ustad') return activeTeacher?.pin || settings.ustadPin || '2222';
    if (selectedRole === 'accountant') return settings.accountantPin || '3333';
    return '';
  };

  // Instant 1-Click Login bypass
  const handleQuickInstantLogin = (role: UserRole) => {
    if (role === 'parent') {
      const firstStudent = students[0];
      if (firstStudent) {
        notifySuccess('parent', firstStudent.parentMobile, firstStudent.ustadName || teachers[0]?.nameUr);
      } else {
        notifySuccess('parent', '03001234567', teachers[0]?.nameUr);
      }
    } else if (role === 'ustad') {
      notifySuccess('ustad', undefined, activeTeacher?.nameUr);
    } else {
      notifySuccess(role);
    }
    onClose();
  };

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();

    // 1. PARENT LOGIN VALIDATION
    if (selectedRole === 'parent') {
      const trimmedMobile = parentMobile.trim();
      const cleanDigits = trimmedMobile.replace(/[^0-9]/g, '');

      if (!cleanDigits || cleanDigits.length < 5) {
        setErrorMsg(
          lang === 'ur'
            ? 'برائے مہربانی اپنا درست رجسٹرڈ موبائل نمبر درج کریں۔'
            : 'Please enter your registered mobile number.'
        );
        return;
      }

      // Match student by parent mobile number
      const matched = students.find((s) => {
        const studentCleanMobile = s.parentMobile.replace(/[^0-9]/g, '');
        return studentCleanMobile.includes(cleanDigits) || cleanDigits.includes(studentCleanMobile);
      });

      if (!matched) {
        // Fallback: If not found in sample, notify with typed mobile so they can enter
        if (cleanDigits.length >= 7) {
          notifySuccess('parent', trimmedMobile, parentTeacherName);
          onClose();
          return;
        }

        setErrorMsg(
          lang === 'ur'
            ? 'اس موبائل نمبر پر کوئی طالب علم نہیں ملا! نیچے دیے گئے کسی بھی بچے کے نام پر کلک کریں:'
            : 'No student found for this mobile number! Click any student below to sign in:'
        );
        return;
      }

      notifySuccess('parent', matched.parentMobile, matched.ustadName || parentTeacherName);
      onClose();
      return;
    }

    // 2. ROLE PIN VERIFICATION
    const expected = getExpectedPin();
    if (pin === expected) {
      if (selectedRole === 'ustad') {
        notifySuccess('ustad', undefined, activeTeacher?.nameUr);
      } else {
        notifySuccess(selectedRole);
      }
      onClose();
    } else {
      setErrorMsg(
        lang === 'ur'
          ? `غلط پن کوڈ! اس رول کا پن کوڈ "${expected}" ہے۔`
          : `Incorrect PIN! The PIN for this role is "${expected}".`
      );
      setPin('');
    }
  };

  const rolesList: { role: UserRole; title: string; icon: string; desc: string }[] = [
    {
      role: 'admin',
      title: lang === 'ur' ? 'ناظم / مہتمم صاحب' : 'Admin / Principal',
      icon: '👑',
      desc: lang === 'ur' ? 'مکمل رسائی: تمام اساتذہ، طلبہ و مالیات' : 'Full access to all data & finance',
    },
    {
      role: 'ustad',
      title: lang === 'ur' ? 'اساتذہ کرام (انفرادی پروفائل)' : 'Ustaad (Teacher Profile)',
      icon: '📖',
      desc: lang === 'ur' ? 'صرف اپنے حلقے/کلاس کے طلبہ اور ڈائری' : 'Own assigned class & diary only',
    },
    {
      role: 'parent',
      title: lang === 'ur' ? 'والدین پورٹل (محترم سرپرست)' : 'Parent Portal',
      icon: '👨‍👩‍👦',
      desc: lang === 'ur' ? 'صرف اپنے بچے کا رزلٹ، ڈائری و حاضری' : 'Child progress only (No PIN)',
    },
    {
      role: 'accountant',
      title: lang === 'ur' ? 'ناظم مالیات / خزانچی' : 'Accountant',
      icon: '💰',
      desc: lang === 'ur' ? 'فیس وصولی، چندہ اور اخراجات کھاتہ' : 'Fees collection & accounts',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/65 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl shadow-2xl border-2 border-emerald-600/30 w-full max-w-xl overflow-hidden animate-in fade-in duration-200 my-auto">
        {/* Modal Header */}
        <div className="bg-[#0F5D2F] text-white p-4 sm:p-5 flex items-center justify-between border-b-4 border-amber-500">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-white/20 flex items-center justify-center text-2xl shadow-inner border border-white/20">
              🕌
            </div>
            <div>
              <h3 className="font-bold text-lg font-urdu leading-tight">
                {lang === 'ur' ? 'مدرسہ پورٹل میں لاگ اِن کیجیے' : 'Sign In to Madrasa Portal'}
              </h3>
              <p className="text-xs text-emerald-200 font-urdu">
                {lang === 'ur' ? 'اپنا کردار منتخب کر کے محفوظ طریقے سے داخل ہوں' : 'Select your role and enter safely'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 sm:p-6 space-y-5">
          {/* Role Selection Tabs */}
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 font-urdu">
              {lang === 'ur' ? '1. داخلے کے لیے اپنا کردار منتخب فرمائیں:' : '1. Select Your Role to Sign In:'}
            </label>
            <div className="grid grid-cols-2 gap-2 sm:gap-2.5">
              {rolesList.map((item) => {
                const isSelected = selectedRole === item.role;
                return (
                  <button
                    key={item.role}
                    type="button"
                    onClick={() => handleRoleSelect(item.role)}
                    className={`p-3 rounded-2xl text-right transition-all flex flex-col items-start gap-1 cursor-pointer border-2 ${
                      isSelected
                        ? 'bg-emerald-50 border-emerald-600 text-emerald-950 shadow-sm ring-2 ring-emerald-600/20'
                        : 'bg-slate-50 border-slate-200 hover:border-emerald-300 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between w-full">
                      <span className="text-2xl">{item.icon}</span>
                      {isSelected && (
                        <span className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs">
                          <Check className="w-3 h-3" />
                        </span>
                      )}
                    </div>
                    <span className="font-bold font-urdu text-sm mt-0.5">{item.title}</span>
                    <span className="text-[11px] text-slate-500 font-urdu line-clamp-1 leading-tight">
                      {item.desc}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 1. USTAAD PROFILE SELECTION (If Ustaad Role Selected) */}
          {selectedRole === 'ustad' && (
            <div className="space-y-3 bg-amber-50/70 p-4 rounded-2xl border-2 border-amber-300">
              <div className="flex items-center justify-between">
                <span className="font-bold text-sm text-amber-950 font-urdu flex items-center gap-1.5">
                  <span>📖</span>
                  <span>{lang === 'ur' ? 'اپنا نام اور حلقہ منتخب فرمائیں:' : 'Select Your Teacher Profile:'}</span>
                </span>
                <span className="text-[10px] bg-amber-200 text-amber-900 px-2 py-0.5 rounded-full font-bold font-urdu">
                  انفرادی سیشن
                </span>
              </div>
              <p className="text-xs text-amber-900/90 font-urdu leading-relaxed">
                {lang === 'ur'
                  ? 'ہر استاد کو صرف اپنے حلقے/کلاس کے طلبہ نظر آئیں گے۔ دوسرے استاد کے طلبہ یا مسجد کے اخراجات آپ کے پاس نہیں آئیں گے۔'
                  : 'You will only see your own assigned students and sabaq diary.'}
              </p>

              {/* Grid of Teachers */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto pr-1">
                {teachers.map((tch) => {
                  const isCurTch = selectedTeacherId === tch.id;
                  const studentCount = students.filter((s) => s.ustadName === tch.nameUr).length;

                  return (
                    <button
                      key={tch.id}
                      type="button"
                      onClick={() => {
                        setSelectedTeacherId(tch.id);
                        setPin('');
                        setErrorMsg('');
                      }}
                      className={`p-2.5 rounded-xl border-2 text-right transition-all cursor-pointer flex items-center justify-between gap-2 ${
                        isCurTch
                          ? 'bg-amber-100 border-amber-600 text-amber-950 shadow-xs'
                          : 'bg-white border-slate-200 hover:border-amber-300 text-slate-800'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-xl">{tch.avatarIcon || '📖'}</span>
                        <div>
                          <div className="font-bold text-xs sm:text-sm font-urdu leading-tight">
                            {tch.nameUr}
                          </div>
                          <div className="text-[10px] text-slate-500 font-urdu mt-0.5">
                            {tch.halqaNameUr}
                          </div>
                        </div>
                      </div>
                      <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.5 rounded font-mono shrink-0">
                        {studentCount} طلبہ
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* 2. PARENT LOGIN FORM (Strictly: Mobile Number + Teacher Name) */}
          {selectedRole === 'parent' ? (
            <div className="space-y-4 bg-emerald-50/80 p-4 rounded-2xl border-2 border-emerald-400">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-emerald-950 font-bold text-sm font-urdu">
                  <Smartphone className="w-4 h-4 text-emerald-700 shrink-0" />
                  <span>{lang === 'ur' ? 'والدین لاگ اِن (محترم سرپرست)' : 'Parent Login Portal'}</span>
                </div>
                <span className="text-[10px] bg-emerald-200 text-emerald-900 px-2 py-0.5 rounded-full font-bold font-urdu">
                  صرف آپ کا بچہ
                </span>
              </div>

              <div className="p-2.5 rounded-xl bg-emerald-100/60 border border-emerald-300 text-xs text-emerald-900 font-urdu leading-relaxed">
                {lang === 'ur'
                  ? '🔒 اس پورٹل میں صرف آپ کے بچے کا سبق، ڈائری، حاضری اور فیس دکھائی دے گی۔ مسجد کا خرچ، چندہ، معاونین یا دیگر بچوں کی تفصیلات بالکل نہیں آئیں گی۔'
                  : 'You will only see your child\'s diary, attendance, and fee status.'}
              </div>

              <div className="space-y-3">
                {/* 1. Parent Mobile Input */}
                <div>
                  <label className="block text-xs font-bold text-emerald-950 font-urdu mb-1">
                    {lang === 'ur' ? '1. والد / سرپرست کا رجسٹرڈ موبائل نمبر:' : '1. Registered Mobile Number:'}
                  </label>
                  <input
                    type="tel"
                    id="parent-mobile-input"
                    value={parentMobile}
                    onChange={(e) => {
                      setParentMobile(e.target.value);
                      setErrorMsg('');
                    }}
                    placeholder={lang === 'ur' ? 'مثال: 03001234567' : 'e.g. 03001234567'}
                    className="w-full px-4 py-2.5 rounded-xl border-2 border-emerald-500 bg-white text-emerald-950 text-center text-base font-bold font-mono focus:outline-none focus:ring-2 focus:ring-emerald-600 shadow-inner"
                  />
                </div>

                {/* 2. Ustaad Name Dropdown Selector */}
                <div>
                  <label className="block text-xs font-bold text-emerald-950 font-urdu mb-1">
                    {lang === 'ur' ? '2. استاد محترم کا نام منتخب فرمائیں:' : '2. Select Teacher Name:'}
                  </label>
                  <select
                    value={parentTeacherName}
                    onChange={(e) => setParentTeacherName(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl border-2 border-emerald-500 bg-white text-emerald-950 text-sm font-bold font-urdu focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  >
                    {teachers.map((tch) => (
                      <option key={tch.id} value={tch.nameUr}>
                        {tch.nameUr} — ({tch.halqaNameUr})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Instant 1-Click Children Login for Convenience */}
              <div className="pt-1">
                <span className="text-[11px] text-emerald-900 font-bold font-urdu block mb-1.5">
                  {lang === 'ur' ? 'یا فوراً داخل ہونے کے لیے اپنے بچے کا نام منتخب کریں:' : 'Or tap your child for instant entry:'}
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 max-h-36 overflow-y-auto pr-1">
                  {students.map((s) => (
                    <button
                      key={s.id}
                      type="button"
                      onClick={() => {
                        notifySuccess('parent', s.parentMobile, s.ustadName || parentTeacherName);
                        onClose();
                      }}
                      className="px-2.5 py-1.5 text-xs bg-white hover:bg-emerald-100 text-emerald-950 rounded-xl border border-emerald-300 transition-colors flex items-center justify-between gap-1 text-right cursor-pointer shadow-2xs font-urdu"
                    >
                      <span className="font-bold flex items-center gap-1">
                        <UserCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span>{s.nameUr}</span>
                      </span>
                      <span className="text-[10px] text-slate-500 font-mono">
                        {s.ustadName ? s.ustadName.split(' ')[0] : 'استاد'}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            /* PIN ENTRY FOR ADMIN, USTAAD, ACCOUNTANT */
            <div className="space-y-3.5 bg-slate-50 p-4 rounded-2xl border-2 border-slate-200">
              <div className="flex items-center justify-between text-xs text-slate-700">
                <span className="font-bold flex items-center gap-1.5 font-urdu">
                  <Lock className="w-3.5 h-3.5 text-emerald-700" />
                  {lang === 'ur' ? 'سیکیورٹی پن کوڈ درج فرمائیں:' : 'Enter Security PIN:'}
                </span>
                <button
                  type="button"
                  onClick={() => setPin(getExpectedPin())}
                  className="text-emerald-700 hover:text-emerald-800 font-bold text-[11px] bg-emerald-100 hover:bg-emerald-200 px-2.5 py-1 rounded-lg transition-colors cursor-pointer flex items-center gap-1 font-urdu"
                  title="خودکار پن درج کریں"
                >
                  <Zap className="w-3 h-3 text-amber-600" />
                  <span>خود درج کریں ({getExpectedPin()})</span>
                </button>
              </div>

              {/* Password dots input */}
              <div className="relative">
                <input
                  ref={pinInputRef}
                  type="password"
                  maxLength={6}
                  value={pin}
                  onChange={(e) => {
                    setPin(e.target.value.replace(/[^0-9]/g, ''));
                    setErrorMsg('');
                  }}
                  placeholder="••••"
                  className="w-full px-4 py-2.5 text-center tracking-[0.6em] text-2xl font-black rounded-xl border-2 border-emerald-500 bg-white text-emerald-950 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
              </div>

              {/* Numeric Keypad */}
              <div className="grid grid-cols-3 gap-1.5 pt-1">
                {['1', '2', '3', '4', '5', '6', '7', '8', '9', 'C', '0', '⌫'].map((k) => (
                  <button
                    key={k}
                    type="button"
                    onClick={() => {
                      if (k === 'C') handleClear();
                      else if (k === '⌫') handleBackspace();
                      else handleKeypadPress(k);
                    }}
                    className={`h-10 rounded-xl font-bold transition-all flex items-center justify-center cursor-pointer active:scale-95 ${
                      k === 'C'
                        ? 'bg-rose-100 text-rose-800 hover:bg-rose-200 text-xs'
                        : k === '⌫'
                        ? 'bg-slate-200 text-slate-800 hover:bg-slate-300 text-base'
                        : 'bg-white hover:bg-emerald-50 text-slate-800 border border-slate-200 shadow-2xs text-base font-mono'
                    }`}
                  >
                    {k}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Error Message */}
          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-300 text-rose-900 text-xs font-bold font-urdu flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Submit Action */}
          <div className="space-y-2 pt-1">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleSubmit}
                id="role-login-submit"
                className="flex-1 bg-emerald-700 hover:bg-emerald-800 text-white font-black py-3 px-5 rounded-2xl shadow-md transition-all font-urdu text-base cursor-pointer flex items-center justify-center gap-2 active:scale-98"
              >
                <KeyRound className="w-5 h-5 text-amber-300" />
                <span>
                  {selectedRole === 'parent'
                    ? lang === 'ur'
                      ? 'بچے کا پورٹل کھولیں 🚀'
                      : 'Open Child Portal 🚀'
                    : lang === 'ur'
                    ? 'لاگ اِن کریں'
                    : 'Sign In'}
                </span>
              </button>
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-3 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-sm font-urdu cursor-pointer"
              >
                {t.cancel}
              </button>
            </div>

            {/* Quick 1-Click Instant Login (No PIN needed) */}
            <button
              type="button"
              onClick={() => handleQuickInstantLogin(selectedRole)}
              className="w-full py-2 px-3 rounded-xl bg-amber-100 hover:bg-amber-200 text-amber-950 font-bold text-xs font-urdu transition-colors flex items-center justify-center gap-1.5 cursor-pointer border border-amber-300"
            >
              <Zap className="w-3.5 h-3.5 text-amber-700" />
              <span>
                {selectedRole === 'ustad'
                  ? `فوری داخلہ: بطور "${activeTeacher?.nameUr}" داخل ہوں`
                  : `فوری داخلہ: بطور "${rolesList.find((r) => r.role === selectedRole)?.title}" داخل ہوں`}
              </span>
              <ArrowRight className="w-3.5 h-3.5 text-amber-700 rotate-180" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
