import React, { useState, useMemo } from 'react';
import {
  Student,
  AttendanceRecord,
  HifzDiaryEntry,
  FeePayment,
  DonationRecord,
  ExpenseRecord,
  UserRole,
  ExamRecord,
  NoticeAnnouncement,
  TeacherProfile,
} from '../types';
import { translations, Language } from '../i18n/translations';
import { createWhatsAppLink } from '../utils/storage';
import { initialTeachers } from '../data/initialData';
import {
  Users,
  CheckCircle2,
  BookOpen,
  DollarSign,
  TrendingUp,
  AlertTriangle,
  ArrowRight,
  Sparkles,
  Flame,
  Calendar,
  ChevronLeft,
  ChevronRight,
  Check,
  X as XIcon,
  Clock,
  BookMarked,
  Award,
  Bell,
  Smartphone,
  CheckCircle,
  FileText,
  UserCheck,
  Filter,
  GraduationCap,
} from 'lucide-react';

interface DashboardProps {
  students: Student[];
  attendance: AttendanceRecord[];
  hifzDiary: HifzDiaryEntry[];
  feePayments: FeePayment[];
  donations: DonationRecord[];
  expenses: ExpenseRecord[];
  exams?: ExamRecord[];
  notices?: NoticeAnnouncement[];
  teachers?: TeacherProfile[];
  lang: Language;
  currentRole: UserRole;
  activeTeacherName?: string;
  onNavigateTab: (tab: string) => void;
  onOpenQuickAddStudent: () => void;
  onOpenQuickCollectFee: () => void;
  onOpenQuickLogHifz: () => void;
  onOpenWhatsAppCenter?: () => void;
  onOpenShortcutsModal?: () => void;
  onUpdateAttendance?: (records: AttendanceRecord[]) => void;
  parentStudentMobile?: string;
}

export const Dashboard: React.FC<DashboardProps> = ({
  students,
  attendance,
  hifzDiary,
  feePayments,
  donations,
  expenses,
  exams = [],
  notices = [],
  teachers = initialTeachers,
  lang,
  currentRole,
  activeTeacherName = 'قاری عبد الوحید',
  onNavigateTab,
  onOpenQuickAddStudent,
  onOpenQuickCollectFee,
  onOpenQuickLogHifz,
  onOpenWhatsAppCenter,
  onOpenShortcutsModal,
  onUpdateAttendance,
  parentStudentMobile,
}) => {
  const t = translations[lang];
  const today = new Date().toISOString().split('T')[0];
  const [selectedAttendDate, setSelectedAttendDate] = useState<string>(today);

  // Admin filter by teacher
  const [adminTeacherFilter, setAdminTeacherFilter] = useState<string>('all');

  // Heatmap range
  const [heatmapRange, setHeatmapRange] = useState<'30' | '84'>('30');

  // ==========================================
  // 1. STRICT PARENT VIEW (Dedicated Child Portal)
  // ==========================================
  if (currentRole === 'parent') {
    const cleanParentMobile = (parentStudentMobile || '').replace(/[^0-9]/g, '');
    const parentStudents = cleanParentMobile
      ? students.filter((s) => {
          const sMobile = s.parentMobile.replace(/[^0-9]/g, '');
          return sMobile.includes(cleanParentMobile) || cleanParentMobile.includes(sMobile);
        })
      : [];

    return (
      <div className="space-y-6 animate-in fade-in duration-300 font-urdu">
        {parentStudents.length === 0 ? (
          <div className="bg-white rounded-3xl p-8 border-2 border-emerald-500/30 text-center space-y-4 shadow-sm">
            <div className="w-16 h-16 rounded-2xl bg-amber-100 text-amber-900 mx-auto flex items-center justify-center text-3xl">
              👨‍👩‍👦
            </div>
            <h3 className="text-xl font-black text-emerald-950">
              {lang === 'ur' ? 'والدین پورٹل میں خوش آمدید' : 'Welcome to Parent Portal'}
            </h3>
            <p className="text-sm text-slate-600 max-w-md mx-auto">
              {lang === 'ur'
                ? 'اپنے بچے کا سبق اور حاضری دیکھنے کے لیے اوپر "رول تبدیل کریں" پر کلک کر کے اپنا موبائل نمبر درج فرمائیں۔'
                : 'Please enter your registered mobile number to access your child\'s records.'}
            </p>
            <div className="pt-2 flex flex-wrap justify-center gap-2">
              {students.slice(0, 4).map((s) => (
                <button
                  key={s.id}
                  onClick={() => {
                    const url = new URL(window.location.href);
                    // trigger switch
                    onNavigateTab('dashboard');
                  }}
                  className="px-3 py-1.5 rounded-xl bg-emerald-50 border border-emerald-300 text-emerald-950 font-bold text-xs"
                >
                  {s.nameUr} (والد: {s.fatherNameUr})
                </button>
              ))}
            </div>
          </div>
        ) : (
          parentStudents.map((child) => {
            // Child's attendance
            const childAttendance = attendance.filter((a) => a.studentId === child.id);
            const totalDays = childAttendance.length || 1;
            const presentDays = childAttendance.filter((a) => a.status === 'present').length;
            const absentDays = childAttendance.filter((a) => a.status === 'absent').length;
            const leaveDays = childAttendance.filter((a) => a.status === 'leave').length;
            const attendRate = Math.round((presentDays / totalDays) * 100);

            const todayAttRecord = childAttendance.find((a) => a.date === today);
            const todayStatus = todayAttRecord ? todayAttRecord.status : 'present';

            // Child's Hifz Diary
            const childDiary = hifzDiary
              .filter((d) => d.studentId === child.id)
              .sort((a, b) => b.date.localeCompare(a.date));
            const latestSabaq = childDiary[0];

            // Child's Fee Payments
            const childPayments = feePayments.filter((f) => f.studentId === child.id);
            const hasPaidThisMonth = childPayments.length > 0;
            const latestPayment = childPayments[childPayments.length - 1];

            // Child's Exams
            const childExams = exams.filter((e) => e.studentId === child.id);
            const latestExam = childExams[0];

            // Assigned Teacher
            const assignedTeacher = teachers.find((t) => t.nameUr === child.ustadName) || {
              nameUr: child.ustadName || 'قاری عبد الوحید',
              halqaNameUr: child.halqa || 'حلقہ اول (شعبہ حفظ و تجوید)',
              phone: '03001112233',
            };

            const completedParas = child.completedParas || 0;
            const parasProgress = Math.min(100, Math.round((completedParas / 30) * 100));

            return (
              <div key={child.id} className="space-y-6">
                {/* 1. Child Profile Header Banner */}
                <div className="bg-gradient-to-r from-emerald-800 to-[#0F5D2F] text-white rounded-3xl p-6 shadow-md border-b-4 border-amber-400">
                  <div className="flex flex-wrap items-center justify-between gap-4">
                    <div className="flex items-center gap-4">
                      <div className="w-16 h-16 rounded-2xl bg-white/20 backdrop-blur-xs flex items-center justify-center text-3xl shadow-inner border border-white/30 shrink-0">
                        🎓
                      </div>
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <h2 className="text-2xl sm:text-3xl font-black">{child.nameUr}</h2>
                          <span className="font-mono text-xs font-bold bg-amber-400 text-emerald-950 px-2 py-0.5 rounded-md">
                            {child.rollNo}
                          </span>
                          <span className="text-xs bg-emerald-950/80 px-2.5 py-0.5 rounded-full border border-emerald-400 text-emerald-100 font-bold">
                            درجہ: {child.class}
                          </span>
                        </div>
                        <p className="text-xs sm:text-sm text-emerald-100 mt-1">
                          والد محترم: <strong className="text-white">{child.fatherNameUr}</strong> ({child.fatherNameEn}) • تاریخ داخلہ: {child.admissionDate}
                        </p>
                      </div>
                    </div>

                    {/* Teacher Card & Direct Contact */}
                    <div className="bg-white/10 backdrop-blur-xs p-3.5 rounded-2xl border border-white/25 flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-amber-400 text-emerald-950 font-bold flex items-center justify-center text-lg">
                        📖
                      </div>
                      <div>
                        <span className="text-[11px] text-amber-300 font-bold block">استاد محترم:</span>
                        <h4 className="font-bold text-sm text-white">{assignedTeacher.nameUr}</h4>
                        <span className="text-[10px] text-emerald-200 block">{assignedTeacher.halqaNameUr}</span>
                      </div>
                      {assignedTeacher.phone && (
                        <a
                          href={createWhatsAppLink(
                            assignedTeacher.phone,
                            `محترم استاد صاحب! السلام علیکم، میں ${child.nameUr} کا والد بات کر رہا ہوں۔ براہ کرم بچے کی پیشرفت سے آگاہ فرمائیں۔`
                          )}
                          target="_blank"
                          rel="noreferrer"
                          className="p-2 rounded-xl bg-[#25D366] hover:bg-[#1EBE5D] text-slate-950 font-bold transition-all ml-1 shadow-xs"
                          title="استاد محترم سے واٹس ایپ پر رابطہ کریں"
                        >
                          💬
                        </a>
                      )}
                    </div>
                  </div>
                </div>

                {/* 2. Key Metrics Cards for this Child */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  {/* Today's Attendance Card */}
                  <div className="bg-white rounded-3xl p-5 border-2 border-slate-200 shadow-xs flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="text-2xl">✅</span>
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-xs font-bold ${
                            todayStatus === 'present'
                              ? 'bg-emerald-100 text-emerald-800'
                              : todayStatus === 'leave'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          آج: {todayStatus === 'present' ? 'حاضر' : todayStatus === 'leave' ? 'رخصت' : 'غائب'}
                        </span>
                      </div>
                      <h4 className="text-xs font-bold text-slate-500 mt-3">مجموعی حاضری کا تناسب</h4>
                      <div className="flex items-baseline gap-2 mt-1">
                        <h3 className="text-3xl font-black text-emerald-950 font-mono">{attendRate}%</h3>
                        <span className="text-xs text-slate-500">حاضر دن</span>
                      </div>
                      <p className="text-xs text-slate-600 mt-2">
                        حاضر: <strong className="text-emerald-700">{presentDays}</strong> | رخصت:{' '}
                        <strong className="text-amber-600">{leaveDays}</strong> | غیر حاضر:{' '}
                        <strong className="text-rose-600">{absentDays}</strong>
                      </p>
                    </div>
                    <button
                      onClick={() => onNavigateTab('attendance')}
                      className="mt-4 text-xs font-bold text-emerald-700 hover:text-emerald-900 flex items-center justify-between pt-2 border-t border-slate-100 cursor-pointer"
                    >
                      <span>مکمل حاضری شیٹ دیکھیں</span>
                      <ArrowRight className="w-3.5 h-3.5 rotate-180" />
                    </button>
                  </div>

                  {/* 30 Paras Hifz Completion Card */}
                  <div className="bg-white rounded-3xl p-5 border-2 border-slate-200 shadow-xs flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="text-2xl">📖</span>
                        <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-900 font-mono">
                          {parasProgress}%
                        </span>
                      </div>
                      <h4 className="text-xs font-bold text-slate-500 mt-3">تکمیل شدہ پارے</h4>
                      <div className="flex items-baseline gap-2 mt-1">
                        <h3 className="text-3xl font-black text-amber-950 font-mono">
                          {completedParas} <span className="text-base font-normal text-slate-500">/ 30 پارے</span>
                        </h3>
                      </div>
                      {/* Progress Bar */}
                      <div className="w-full bg-slate-100 h-2 rounded-full mt-3 overflow-hidden">
                        <div
                          className="bg-amber-500 h-full rounded-full transition-all duration-500"
                          style={{ width: `${parasProgress}%` }}
                        />
                      </div>
                    </div>
                    <button
                      onClick={() => onNavigateTab('mushaf')}
                      className="mt-4 text-xs font-bold text-amber-700 hover:text-amber-900 flex items-center justify-between pt-2 border-t border-slate-100 cursor-pointer"
                    >
                      <span>۳۰ پارہ مصحف شریف دیکھیں</span>
                      <ArrowRight className="w-3.5 h-3.5 rotate-180" />
                    </button>
                  </div>

                  {/* Monthly Fee Status Card */}
                  <div className="bg-white rounded-3xl p-5 border-2 border-slate-200 shadow-xs flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="text-2xl">💰</span>
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-xs font-bold ${
                            hasPaidThisMonth
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {hasPaidThisMonth ? 'فیس ادا شدہ ✅' : 'واجب الادا ⚠️'}
                        </span>
                      </div>
                      <h4 className="text-xs font-bold text-slate-500 mt-3">ماہانہ فیس کی رقم</h4>
                      <div className="flex items-baseline gap-2 mt-1">
                        <h3 className="text-2xl sm:text-3xl font-black text-slate-900 font-mono">
                          {child.monthlyFee.toLocaleString()}{' '}
                          <span className="text-xs font-normal text-slate-500">روپے</span>
                        </h3>
                      </div>
                      <p className="text-xs text-slate-600 mt-2">
                        {latestPayment
                          ? `رسید نمبر: ${latestPayment.receiptNo} (${latestPayment.month})`
                          : 'اس ماہ کی فیس ابھی جمع نہیں ہوئی'}
                      </p>
                    </div>
                    <button
                      onClick={() => onNavigateTab('fees')}
                      className="mt-4 text-xs font-bold text-blue-700 hover:text-blue-900 flex items-center justify-between pt-2 border-t border-slate-100 cursor-pointer"
                    >
                      <span>فیس و رسیدات دیکھیں</span>
                      <ArrowRight className="w-3.5 h-3.5 rotate-180" />
                    </button>
                  </div>

                  {/* Latest Exam Card */}
                  <div className="bg-white rounded-3xl p-5 border-2 border-slate-200 shadow-xs flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="text-2xl">🏆</span>
                        <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-purple-100 text-purple-900">
                          {latestExam ? `گریڈ ${latestExam.grade}` : 'عمدہ'}
                        </span>
                      </div>
                      <h4 className="text-xs font-bold text-slate-500 mt-3">امتحانی کارکردگی</h4>
                      <div className="flex items-baseline gap-2 mt-1">
                        <h3 className="text-2xl font-black text-purple-950 font-mono">
                          {latestExam ? `${latestExam.percentage}%` : 'A+ (ممتاز)'}
                        </h3>
                      </div>
                      <p className="text-xs text-slate-600 mt-2 line-clamp-1">
                        {latestExam ? latestExam.examNameUr : 'امتحان ششماہی حفظ و تجوید'}
                      </p>
                    </div>
                    <button
                      onClick={() => onNavigateTab('exams')}
                      className="mt-4 text-xs font-bold text-purple-700 hover:text-purple-900 flex items-center justify-between pt-2 border-t border-slate-100 cursor-pointer"
                    >
                      <span>رزلٹ کارڈ دیکھیں</span>
                      <ArrowRight className="w-3.5 h-3.5 rotate-180" />
                    </button>
                  </div>
                </div>

                {/* 3. Detailed Recent Sabaq & Teacher Diary Card */}
                <div className="bg-white rounded-3xl p-6 border-2 border-emerald-600/30 shadow-xs space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                    <div className="flex items-center gap-2">
                      <span className="text-2xl">📖</span>
                      <div>
                        <h3 className="text-lg font-bold text-emerald-950">
                          {lang === 'ur' ? 'حالیہ سبق و ڈائری کی کارکردگی' : 'Recent Sabaq & Performance'}
                        </h3>
                        <p className="text-xs text-slate-500">
                          استاد محترم کی جانب سے روزانہ درج کیے جانے والے اسباق اور کیفیت
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={() => onNavigateTab('hifz')}
                      className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold px-4 py-2 rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
                    >
                      <span>مکمل ڈائری دیکھیں</span>
                      <ArrowRight className="w-3.5 h-3.5 rotate-180" />
                    </button>
                  </div>

                  {latestSabaq ? (
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {/* Sabaq */}
                      <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200">
                        <span className="text-xs font-bold text-emerald-800 block">سبق (نیا سبق):</span>
                        <div className="text-xl font-black text-emerald-950 mt-1">
                          پارہ {latestSabaq.sabaqPara}
                        </div>
                        <p className="text-xs text-emerald-900 mt-0.5">{latestSabaq.sabaqLinesOrPages}</p>
                      </div>

                      {/* Sabqi & Manzil */}
                      <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200">
                        <span className="text-xs font-bold text-amber-800 block">سبقی و منزل:</span>
                        <div className="text-sm font-bold text-amber-950 mt-1">
                          سبقی: <strong>{latestSabaq.sabqi}</strong>
                        </div>
                        <p className="text-xs text-amber-900 mt-0.5">
                          منزل: <strong>{latestSabaq.manzil}</strong>
                        </p>
                      </div>

                      {/* Grade & Remarks */}
                      <div className="p-4 rounded-2xl bg-blue-50/70 border border-blue-200">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-blue-800">کیفیت و ریمارکس:</span>
                          <span className="px-2 py-0.5 rounded text-xs font-bold bg-blue-200 text-blue-900 font-mono">
                            {latestSabaq.grade}
                          </span>
                        </div>
                        <p className="text-xs font-bold text-slate-800 mt-1.5 leading-relaxed">
                          {latestSabaq.teacherRemarks || 'ماشاءاللہ بہت عمدہ یاد کیا، تلفظ درست ہے۔'}
                        </p>
                        <span className="text-[10px] text-slate-400 font-mono block mt-1">
                          تاریخ: {latestSabaq.date}
                        </span>
                      </div>
                    </div>
                  ) : (
                    <div className="p-6 text-center text-slate-400 text-sm">
                      فی الحال کوئی ڈائری درج نہیں ہے
                    </div>
                  )}
                </div>
              </div>
            );
          })
        )}

        {/* Madrasa Notices / Elanat for Parents */}
        {notices && notices.length > 0 && (
          <div className="bg-white rounded-3xl p-6 border-2 border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center text-xl shadow-inner">
                  📢
                </div>
                <div>
                  <h3 className="text-base font-black text-emerald-950 font-urdu">
                    مدرسہ کے تازہ ترین اعلانات و ہدایات
                  </h3>
                  <p className="text-xs text-slate-500 font-urdu">
                    تعطیلات، امتحانات اور دیگر ضروری پیغامات برائے والدین
                  </p>
                </div>
              </div>
              <button
                onClick={() => onNavigateTab('notices')}
                className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold px-3.5 py-1.5 rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
              >
                <span>تمام اعلانات دیکھیں</span>
                <ArrowRight className="w-3 h-3 rotate-180" />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {notices.slice(0, 4).map((notice) => (
                <div
                  key={notice.id}
                  className={`p-4 rounded-2xl border transition-all ${
                    notice.priority === 'high'
                      ? 'bg-rose-50/70 border-rose-200'
                      : 'bg-emerald-50/40 border-emerald-200'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 mb-1.5">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        notice.priority === 'high'
                          ? 'bg-rose-200 text-rose-900'
                          : 'bg-emerald-200 text-emerald-900'
                      }`}
                    >
                      {notice.category === 'holiday'
                        ? '🏖️ چھٹیاں'
                        : notice.category === 'event'
                        ? '🕌 تقریب'
                        : notice.category === 'admission'
                        ? '🎓 داخلہ'
                        : '📌 عام اطلاع'}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">{notice.date}</span>
                  </div>
                  <h4 className="font-bold text-sm text-emerald-950 mb-1">{notice.titleUr}</h4>
                  <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">{notice.contentUr}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  }

  // ==========================================
  // 2. TEACHER OR ADMIN FILTERED DATA PREPARATION
  // ==========================================
  const isTeacher = currentRole === 'ustad';
  const currentTeacherName = isTeacher ? activeTeacherName : adminTeacherFilter;

  // Filter students based on role
  const displayStudents = isTeacher
    ? students.filter((s) => s.ustadName === activeTeacherName)
    : adminTeacherFilter !== 'all'
    ? students.filter((s) => s.ustadName === adminTeacherFilter)
    : students;

  const displayStudentIds = new Set(displayStudents.map((s) => s.id));

  // Filter attendance, diary, exams for this halqa
  const displayAttendance = attendance.filter((a) => displayStudentIds.has(a.studentId));
  const displayDiary = hifzDiary.filter((d) => displayStudentIds.has(d.studentId));
  const displayExams = exams.filter((e) => displayStudentIds.has(e.studentId));

  // Calculations for current scope
  const totalStudentsCount = displayStudents.length;
  const todayAttendanceRecords = displayAttendance.filter((a) => a.date === selectedAttendDate);
  const presentTodayCount = todayAttendanceRecords.filter((a) => a.status === 'present').length;
  const attendancePercentage =
    totalStudentsCount > 0 ? Math.round((presentTodayCount / totalStudentsCount) * 100) : 0;

  // Finances (Only for Admin / Accountant)
  const monthlyFeesCollected = feePayments.reduce((sum, f) => sum + (f.totalPaid || 0), 0);
  const totalDonationsAmount = donations.reduce((sum, d) => sum + (d.amount || 0), 0);
  const totalExpensesAmount = expenses.reduce((sum, e) => sum + (e.amount || 0), 0);
  const netBalance = totalDonationsAmount + monthlyFeesCollected - totalExpensesAmount;

  // Hifz stats
  const recentHifzEntries = [...displayDiary]
    .sort((a, b) => b.date.localeCompare(a.date))
    .slice(0, 5);
  const gradeCounts = displayDiary.reduce(
    (acc, curr) => {
      acc[curr.grade] = (acc[curr.grade] || 0) + 1;
      return acc;
    },
    {} as Record<string, number>
  );

  // Defaulters (only relevant for admin)
  const paidStudentIds = new Set(feePayments.map((f) => f.studentId));
  const defaulterStudents = displayStudents.filter((s) => !paidStudentIds.has(s.id));

  // Stepper for attendance
  const stepAttendDate = (offset: number) => {
    const current = new Date(selectedAttendDate);
    current.setDate(current.getDate() + offset);
    setSelectedAttendDate(current.toISOString().split('T')[0]);
  };

  const handleQuickMarkAttendance = (studentId: string, status: 'present' | 'absent' | 'leave') => {
    if (!onUpdateAttendance) return;
    const existingIndex = attendance.findIndex(
      (a) => a.studentId === studentId && a.date === selectedAttendDate
    );
    let updated: AttendanceRecord[];
    if (existingIndex >= 0) {
      updated = [...attendance];
      updated[existingIndex] = { ...updated[existingIndex], status };
    } else {
      updated = [
        ...attendance,
        {
          id: `att-${Date.now()}-${studentId}`,
          studentId,
          date: selectedAttendDate,
          status,
          recordedBy: currentRole === 'admin' ? 'مہتمم' : activeTeacherName,
        },
      ];
    }
    onUpdateAttendance(updated);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300 font-urdu">
      {/* 1. Admin Announcement Marquee (Hidden for Ustaad to keep focus on class) */}
      {!isTeacher && notices.length > 0 && (
        <div className="bg-emerald-950 text-white py-2.5 px-4 rounded-2xl shadow-sm border border-emerald-800 flex items-center gap-3 overflow-hidden">
          <div className="flex items-center gap-1.5 shrink-0 bg-amber-400 text-emerald-950 px-2.5 py-0.5 rounded-lg text-xs font-black">
            <Bell className="w-3.5 h-3.5 animate-pulse" />
            <span>اہم اعلانات:</span>
          </div>
          <div className="overflow-hidden whitespace-nowrap w-full flex items-center">
            <div className="inline-flex items-center gap-8 animate-marquee text-xs text-amber-200">
              {notices.map((n, idx) => (
                <span key={n.id || idx} className="inline-flex items-center gap-2">
                  <span className="font-bold text-white">[{n.date}] {n.titleUr}:</span>
                  <span className="text-emerald-200">{n.contentUr}</span>
                  <span className="text-amber-400 font-mono">• • •</span>
                </span>
              ))}
            </div>
          </div>
          <button
            onClick={() => onNavigateTab('notices')}
            className="shrink-0 text-xs bg-emerald-800 hover:bg-emerald-700 text-amber-300 font-bold px-3 py-1 rounded-lg cursor-pointer"
          >
            دیکھیں 📋
          </button>
        </div>
      )}

      {/* 2. Ustaad Individual Profile Banner */}
      {isTeacher && (
        <div className="bg-gradient-to-r from-emerald-900 to-[#0F5D2F] text-white rounded-3xl p-5 shadow-md border-b-4 border-amber-400">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3.5">
              <div className="w-13 h-13 rounded-2xl bg-amber-400 text-emerald-950 flex items-center justify-center text-3xl font-bold shadow-inner">
                📖
              </div>
              <div>
                <span className="text-[11px] uppercase tracking-wider text-amber-300 font-bold font-sans">
                  TEACHER HALQA DASHBOARD • انفرادی پروفائل
                </span>
                <h2 className="text-xl sm:text-2xl font-black">
                  استاد محترم: {activeTeacherName}
                </h2>
                <p className="text-xs text-emerald-100 mt-0.5">
                  حلقہ کے کل طلبہ: <strong>{totalStudentsCount}</strong> | آج حاضر: <strong>{presentTodayCount}</strong> | اس سیشن میں صرف آپ کے حلقے کے طلبہ شامل ہیں
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => onNavigateTab('hifz')}
                className="bg-amber-400 hover:bg-amber-500 text-emerald-950 font-bold px-4 py-2 rounded-xl text-xs cursor-pointer flex items-center gap-1.5"
              >
                <span>➕ روزانہ سبق ڈائری درج کریں</span>
              </button>
              <button
                onClick={() => onNavigateTab('attendance')}
                className="bg-emerald-950 hover:bg-black text-amber-300 font-bold px-4 py-2 rounded-xl text-xs cursor-pointer border border-emerald-700"
              >
                <span>حاضری شیٹ</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 3. Admin Teacher Selector Filter Bar */}
      {!isTeacher && (
        <div className="bg-white rounded-2xl p-3 sm:p-4 border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-emerald-700" />
            <span className="font-bold text-xs sm:text-sm text-emerald-950">
              اساتذہ کے لحاظ سے جائزہ (ناظم اعلیٰ فلٹر):
            </span>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => setAdminTeacherFilter('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                adminTeacherFilter === 'all'
                  ? 'bg-emerald-800 text-white shadow-xs'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
            >
              تمام اساتذہ ({students.length} طلبہ)
            </button>
            {teachers.map((tch) => {
              const count = students.filter((s) => s.ustadName === tch.nameUr).length;
              return (
                <button
                  key={tch.id}
                  onClick={() => setAdminTeacherFilter(tch.nameUr)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    adminTeacherFilter === tch.nameUr
                      ? 'bg-amber-500 text-emerald-950 shadow-xs ring-2 ring-amber-600/30'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                  }`}
                >
                  {tch.nameUr} ({count})
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* 4. KPI Cards Grid */}
      <div className={`grid grid-cols-1 sm:grid-cols-2 ${isTeacher ? 'lg:grid-cols-3' : 'lg:grid-cols-5'} gap-4`}>
        {/* Total Students Card */}
        <div className="bg-white rounded-2xl p-4.5 border-2 border-emerald-100/80 shadow-xs hover:shadow-md transition-shadow relative overflow-hidden group">
          <div className="flex items-center justify-between">
            <span className="text-3xl">🎓</span>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800">
              {displayStudents.filter((s) => s.isHostel).length} مقیم
            </span>
          </div>
          <div className="mt-3">
            <p className="text-xs font-bold text-slate-500">{isTeacher ? 'حلقہ کے طلبہ' : t.totalStudents}</p>
            <h3 className="text-2xl sm:text-3xl font-black text-emerald-950 font-mono mt-0.5">
              {totalStudentsCount}
            </h3>
            <p className="text-[11px] text-slate-500 mt-1 flex items-center gap-1">
              <span>{displayStudents.filter((s) => s.class === 'Hifz').length} حفظ</span> •
              <span>{displayStudents.filter((s) => s.class === 'Nazra').length} ناظرہ</span> •
              <span>{displayStudents.filter((s) => s.class === 'Qaida').length} قاعدہ</span>
            </p>
          </div>
        </div>

        {/* Present Today Card */}
        <div className="bg-white rounded-2xl p-4.5 border-2 border-teal-100/80 shadow-xs hover:shadow-md transition-shadow relative overflow-hidden group">
          <div className="flex items-center justify-between">
            <span className="text-3xl">✅</span>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-teal-100 text-teal-800 font-mono">
              {attendancePercentage}%
            </span>
          </div>
          <div className="mt-3">
            <p className="text-xs font-bold text-slate-500">{t.presentToday}</p>
            <h3 className="text-2xl sm:text-3xl font-black text-teal-950 font-mono mt-0.5">
              {presentTodayCount} <span className="text-sm font-normal text-slate-500">/ {totalStudentsCount}</span>
            </h3>
            <div className="w-full bg-slate-100 h-1.5 rounded-full mt-2 overflow-hidden">
              <div
                className="bg-teal-600 h-full rounded-full transition-all duration-500"
                style={{ width: `${attendancePercentage}%` }}
              />
            </div>
          </div>
        </div>

        {/* Avg Hifz Grade Card */}
        <div className="bg-white rounded-2xl p-4.5 border-2 border-amber-100/80 shadow-xs hover:shadow-md transition-shadow relative overflow-hidden group">
          <div className="flex items-center justify-between">
            <span className="text-3xl">📖</span>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-900">
              {gradeCounts['A+'] || 0} ممتاز
            </span>
          </div>
          <div className="mt-3">
            <p className="text-xs font-bold text-slate-500">{t.avgHifzGrade}</p>
            <h3 className="text-2xl sm:text-3xl font-black text-amber-950 mt-0.5">
              A+ (ممتاز)
            </h3>
            <p className="text-[11px] text-slate-500 mt-1">
              آج ریکارڈ شدہ اسباق: {recentHifzEntries.length}
            </p>
          </div>
        </div>

        {/* Financial Cards: ONLY FOR ADMIN */}
        {!isTeacher && (
          <>
            {/* Monthly Fee Card */}
            <div className="bg-white rounded-2xl p-4.5 border-2 border-blue-100/80 shadow-xs hover:shadow-md transition-shadow relative overflow-hidden group">
              <div className="flex items-center justify-between">
                <span className="text-3xl">💰</span>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-100 text-blue-800">
                  {paidStudentIds.size} وصول
                </span>
              </div>
              <div className="mt-3">
                <p className="text-xs font-bold text-slate-500">{t.feeCollectedThisMonth}</p>
                <h3 className="text-xl sm:text-2xl font-black text-blue-950 font-mono mt-0.5">
                  {monthlyFeesCollected.toLocaleString()} <span className="text-xs font-normal text-slate-500">روپے</span>
                </h3>
                <p className="text-[11px] text-slate-500 mt-1">
                  بقایا طلبہ: <strong className="text-rose-600">{defaulterStudents.length}</strong> طلبہ
                </p>
              </div>
            </div>

            {/* Net Balance Card */}
            <div className="bg-white rounded-2xl p-4.5 border-2 border-emerald-200 shadow-xs hover:shadow-md transition-shadow relative overflow-hidden group">
              <div className="flex items-center justify-between">
                <span className="text-3xl">🪙</span>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800">
                  خالص بیلنس
                </span>
              </div>
              <div className="mt-3">
                <p className="text-xs font-bold text-slate-500">{t.balanceNet}</p>
                <h3
                  className={`text-xl sm:text-2xl font-black font-mono mt-0.5 ${
                    netBalance >= 0 ? 'text-emerald-900' : 'text-rose-700'
                  }`}
                >
                  {netBalance.toLocaleString()} <span className="text-xs font-normal text-slate-500">روپے</span>
                </h3>
                <p className="text-[11px] text-slate-500 mt-1 flex items-center justify-between">
                  <span>عطیات: {totalDonationsAmount.toLocaleString()}</span>
                  <span>خرچ: {totalExpensesAmount.toLocaleString()}</span>
                </p>
              </div>
            </div>
          </>
        )}
      </div>

      {/* 5. Quick Shortcuts & Actions Bar (فوری شارٹ کٹس و اقدامات) */}
      <div className="bg-gradient-to-br from-emerald-900 via-emerald-950 to-slate-950 text-white rounded-3xl p-5 shadow-lg border-2 border-emerald-600/40 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-amber-400/5 rounded-full blur-3xl pointer-events-none" />
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4 relative z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-400 text-emerald-950 flex items-center justify-center font-bold text-xl shadow-md">
              ⚡
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono uppercase tracking-wider bg-amber-400/20 text-amber-300 px-2 py-0.5 rounded-full font-bold">
                  QUICK SHORTCUTS
                </span>
                <span className="text-xs text-emerald-300 font-urdu">
                  تیز رفتار بٹن
                </span>
              </div>
              <h3 className="font-black text-lg text-white font-urdu">
                {lang === 'ur' ? 'فوری شارٹ کٹس و اہم اقدامات' : 'Quick Shortcuts & Direct Actions'}
              </h3>
            </div>
          </div>

          {onOpenShortcutsModal && (
            <button
              onClick={onOpenShortcutsModal}
              title="تمام کی بورڈ شارٹ کٹس گائیڈ کھولیں (Alt + K)"
              className="flex items-center gap-1.5 bg-white/10 hover:bg-white/20 active:scale-95 text-amber-300 border border-white/20 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer shadow-xs"
            >
              <span>⌨️</span>
              <span className="font-urdu">تمام شارٹ کٹس لسٹ (Alt+K)</span>
            </button>
          )}
        </div>

        {/* Shortcuts Buttons Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2.5 relative z-10">
          {/* Quick Sabaq Log */}
          <button
            onClick={onOpenQuickLogHifz}
            title="روزانہ سبق، سبقی و منزل درج کریں (Alt + L)"
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white/10 hover:bg-amber-400 hover:text-emerald-950 text-white transition-all group border border-white/10 shadow-sm cursor-pointer active:scale-95 text-center"
          >
            <span className="text-2xl mb-1 group-hover:scale-110 transition-transform">📖</span>
            <span className="font-bold text-xs font-urdu leading-tight">سبق ڈائری</span>
            <span className="text-[10px] font-mono opacity-70 mt-0.5">Alt + L</span>
          </button>

          {/* Quick Add Student */}
          <button
            onClick={onOpenQuickAddStudent}
            title="نیا طالب علم داخلہ فارم (Alt + S)"
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white/10 hover:bg-emerald-500 hover:text-white text-white transition-all group border border-white/10 shadow-sm cursor-pointer active:scale-95 text-center"
          >
            <span className="text-2xl mb-1 group-hover:scale-110 transition-transform">🎓</span>
            <span className="font-bold text-xs font-urdu leading-tight">نیا داخلہ</span>
            <span className="text-[10px] font-mono opacity-70 mt-0.5">Alt + S</span>
          </button>

          {/* Quick Collect Fee (Admin/Accountant) */}
          {!isTeacher && (
            <button
              onClick={onOpenQuickCollectFee}
              title="ماہانہ فیس وصولی اور رسید (Alt + F)"
              className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white/10 hover:bg-blue-500 hover:text-white text-white transition-all group border border-white/10 shadow-sm cursor-pointer active:scale-95 text-center"
            >
              <span className="text-2xl mb-1 group-hover:scale-110 transition-transform">💰</span>
              <span className="font-bold text-xs font-urdu leading-tight">فیس وصولی</span>
              <span className="text-[10px] font-mono opacity-70 mt-0.5">Alt + F</span>
            </button>
          )}

          {/* Mark Attendance */}
          <button
            onClick={() => onNavigateTab('attendance')}
            title="حاضری رجسٹر و شیٹ (Alt + 3)"
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white/10 hover:bg-teal-500 hover:text-white text-white transition-all group border border-white/10 shadow-sm cursor-pointer active:scale-95 text-center"
          >
            <span className="text-2xl mb-1 group-hover:scale-110 transition-transform">✅</span>
            <span className="font-bold text-xs font-urdu leading-tight">حاضری شیٹ</span>
            <span className="text-[10px] font-mono opacity-70 mt-0.5">Alt + 3</span>
          </button>

          {/* WhatsApp Alerts Center */}
          {onOpenWhatsAppCenter && (
            <button
              onClick={onOpenWhatsAppCenter}
              title="واٹس ایپ الرٹس سینٹر (Alt + W)"
              className="flex flex-col items-center justify-center p-3 rounded-2xl bg-[#25D366]/20 hover:bg-[#25D366] hover:text-slate-950 text-emerald-200 transition-all group border border-[#25D366]/40 shadow-sm cursor-pointer active:scale-95 text-center"
            >
              <span className="text-2xl mb-1 group-hover:scale-110 transition-transform">💬</span>
              <span className="font-bold text-xs font-urdu leading-tight">واٹس ایپ الرٹس</span>
              <span className="text-[10px] font-mono opacity-70 mt-0.5">Alt + W</span>
            </button>
          )}

          {/* Mushaf 30 Paras */}
          <button
            onClick={() => onNavigateTab('mushaf')}
            title="مصحف شریف ۳۰ پارہ ٹریکر (Alt + 5)"
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white/10 hover:bg-emerald-600 hover:text-white text-white transition-all group border border-white/10 shadow-sm cursor-pointer active:scale-95 text-center"
          >
            <span className="text-2xl mb-1 group-hover:scale-110 transition-transform">📜</span>
            <span className="font-bold text-xs font-urdu leading-tight">مصحف (۳۰ پارے)</span>
            <span className="text-[10px] font-mono opacity-70 mt-0.5">Alt + 5</span>
          </button>

          {/* Smart Revision */}
          <button
            onClick={() => onNavigateTab('revision')}
            title="اسمارٹ ریویژن شیڈولر (Alt + 6)"
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white/10 hover:bg-amber-500 hover:text-emerald-950 text-white transition-all group border border-white/10 shadow-sm cursor-pointer active:scale-95 text-center"
          >
            <span className="text-2xl mb-1 group-hover:scale-110 transition-transform">⚡</span>
            <span className="font-bold text-xs font-urdu leading-tight">ریویژن شیڈولر</span>
            <span className="text-[10px] font-mono opacity-70 mt-0.5">Alt + 6</span>
          </button>

          {/* Exams */}
          <button
            onClick={() => onNavigateTab('exams')}
            title="امتحانات و رزلٹ کارڈز (Alt + 9)"
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white/10 hover:bg-orange-500 hover:text-white text-white transition-all group border border-white/10 shadow-sm cursor-pointer active:scale-95 text-center"
          >
            <span className="text-2xl mb-1 group-hover:scale-110 transition-transform">🏆</span>
            <span className="font-bold text-xs font-urdu leading-tight">امتحانات و رزلٹ</span>
            <span className="text-[10px] font-mono opacity-70 mt-0.5">Alt + 9</span>
          </button>

          {/* Record Donation (Admin/Accountant) */}
          {!isTeacher && (
            <button
              onClick={() => onNavigateTab('donations')}
              title="چندہ و عطیات کھاتہ (Alt + 8)"
              className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white/10 hover:bg-emerald-500 hover:text-white text-white transition-all group border border-white/10 shadow-sm cursor-pointer active:scale-95 text-center"
            >
              <span className="text-2xl mb-1 group-hover:scale-110 transition-transform">🪙</span>
              <span className="font-bold text-xs font-urdu leading-tight">چندہ کھاتہ</span>
              <span className="text-[10px] font-mono opacity-70 mt-0.5">Alt + 8</span>
            </button>
          )}

          {/* Reports & Print */}
          <button
            onClick={() => onNavigateTab('reports')}
            title="رپورٹس، پرنٹ و بیک اپ (Alt + P)"
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white/10 hover:bg-slate-700 hover:text-white text-white transition-all group border border-white/10 shadow-sm cursor-pointer active:scale-95 text-center"
          >
            <span className="text-2xl mb-1 group-hover:scale-110 transition-transform">🖨️</span>
            <span className="font-bold text-xs font-urdu leading-tight">پرنٹ و بیک اپ</span>
            <span className="text-[10px] font-mono opacity-70 mt-0.5">Alt + P</span>
          </button>
        </div>
      </div>

      {/* 6. Daily Attendance Tracker with Instant Buttons */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-teal-100 text-teal-900 flex items-center justify-center font-bold text-lg">
              ✅
            </div>
            <div>
              <h3 className="font-bold text-base text-emerald-950">
                {isTeacher ? `حاضری برائے حلقہ ${activeTeacherName}` : 'روزانہ حاضری ٹریکر'}
              </h3>
              <p className="text-xs text-slate-500">
                طلبہ کی حاضری، غیر حاضری یا رخصت ایک کلک سے درج کریں
              </p>
            </div>
          </div>

          {/* Date Navigator */}
          <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-2xl">
            <button
              onClick={() => stepAttendDate(-1)}
              className="p-1.5 rounded-xl bg-white hover:bg-slate-200 text-slate-700 transition cursor-pointer"
              title="پچھلا دن"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
            <div className="px-3 py-1 text-xs font-bold font-mono text-emerald-950">
              {selectedAttendDate}
            </div>
            <button
              onClick={() => stepAttendDate(1)}
              className="p-1.5 rounded-xl bg-white hover:bg-slate-200 text-slate-700 transition cursor-pointer"
              title="اگلا دن"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Student Attendance List with Quick Status Buttons */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 max-h-72 overflow-y-auto pr-1">
          {displayStudents.map((s) => {
            const record = displayAttendance.find(
              (a) => a.studentId === s.id && a.date === selectedAttendDate
            );
            const status = record ? record.status : 'unmarked';

            return (
              <div
                key={s.id}
                className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-2 hover:bg-white transition"
              >
                <div>
                  <h4 className="font-bold text-xs sm:text-sm text-slate-900">{s.nameUr}</h4>
                  <span className="text-[10px] text-slate-400 font-mono">
                    {s.rollNo} • {s.class}
                  </span>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleQuickMarkAttendance(s.id, 'present')}
                    className={`px-2 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                      status === 'present'
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'bg-slate-200 text-slate-600 hover:bg-emerald-100'
                    }`}
                    title="حاضر"
                  >
                    حاضر
                  </button>
                  <button
                    onClick={() => handleQuickMarkAttendance(s.id, 'absent')}
                    className={`px-2 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                      status === 'absent'
                        ? 'bg-rose-600 text-white shadow-xs'
                        : 'bg-slate-200 text-slate-600 hover:bg-rose-100'
                    }`}
                    title="غیر حاضر"
                  >
                    غائب
                  </button>
                  <button
                    onClick={() => handleQuickMarkAttendance(s.id, 'leave')}
                    className={`px-2 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                      status === 'leave'
                        ? 'bg-amber-500 text-white shadow-xs'
                        : 'bg-slate-200 text-slate-600 hover:bg-amber-100'
                    }`}
                    title="رخصت"
                  >
                    رخصت
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        <div className="text-center pt-2">
          <button
            onClick={() => onNavigateTab('attendance')}
            className="text-xs font-bold text-emerald-700 hover:underline cursor-pointer"
          >
            تمام طلبہ کی تفصیلی حاضری شیٹ دیکھیں ⬅️
          </button>
        </div>
      </div>

      {/* 6. Recent Hifz Progress */}
      <div className={`grid grid-cols-1 ${!isTeacher ? 'lg:grid-cols-2' : ''} gap-6`}>
        {/* Recent Hifz Lessons */}
        <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-bold text-emerald-950 flex items-center gap-2">
                <span>📖</span>
                <span>{isTeacher ? 'حلقہ کے حالیہ اسباق' : t.recentHifzUpdates}</span>
              </h3>
              <button
                onClick={() => onNavigateTab('hifz')}
                className="text-xs font-bold text-emerald-700 hover:text-emerald-900 flex items-center gap-1 cursor-pointer"
              >
                <span>مکمل ڈائری</span>
                <ArrowRight className="w-3.5 h-3.5 rotate-180" />
              </button>
            </div>

            <div className="space-y-3">
              {recentHifzEntries.length === 0 ? (
                <p className="text-xs text-slate-400 py-4 text-center">
                  آج کا کوئی سبق درج نہیں ہے
                </p>
              ) : (
                recentHifzEntries.map((entry) => {
                  const student = displayStudents.find((s) => s.id === entry.studentId);
                  return (
                    <div
                      key={entry.id}
                      className="p-3 rounded-2xl bg-slate-50 hover:bg-emerald-50/60 transition-colors border border-slate-200/80 flex items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-900 font-bold flex items-center justify-center font-mono text-sm">
                          پارہ {entry.sabaqPara}
                        </div>
                        <div>
                          <h4 className="font-bold text-sm text-slate-900">
                            {student?.nameUr || 'طالب علم'}
                          </h4>
                          <p className="text-xs text-slate-500">
                            {entry.sabaqLinesOrPages} | سبقی: {entry.sabqi}
                          </p>
                        </div>
                      </div>

                      <div className="text-left shrink-0">
                        <span
                          className={`inline-block px-2.5 py-1 rounded-full text-xs font-bold ${
                            entry.grade === 'A+'
                              ? 'bg-emerald-100 text-emerald-900'
                              : entry.grade === 'A'
                              ? 'bg-blue-100 text-blue-900'
                              : entry.grade === 'B'
                              ? 'bg-amber-100 text-amber-900'
                              : 'bg-rose-100 text-rose-900'
                          }`}
                        >
                          {entry.grade === 'A+' && 'ممتاز'}
                          {entry.grade === 'A' && 'جید جداً'}
                          {entry.grade === 'B' && 'جید'}
                          {entry.grade === 'C' && 'مقبول'}
                        </span>
                        <span className="block text-[10px] text-slate-400 font-mono mt-0.5">
                          {entry.date}
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>

        {/* Fee Defaulters: ONLY FOR ADMIN */}
        {!isTeacher && (
          <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-base font-bold text-rose-950 flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5 text-rose-600" />
                  <span>{t.defaulterAlerts}</span>
                  <span className="px-2 py-0.5 rounded-full text-xs bg-rose-100 text-rose-800 font-mono font-bold">
                    {defaulterStudents.length}
                  </span>
                </h3>
                <button
                  onClick={() => onNavigateTab('fees')}
                  className="text-xs font-bold text-rose-700 hover:text-rose-900 flex items-center gap-1 cursor-pointer"
                >
                  <span>فیس کا نظام</span>
                  <ArrowRight className="w-3.5 h-3.5 rotate-180" />
                </button>
              </div>

              <div className="space-y-3">
                {defaulterStudents.length === 0 ? (
                  <div className="p-6 rounded-2xl bg-emerald-50 border border-emerald-200 text-center text-emerald-900 text-sm">
                    {t.noDefaulters}
                  </div>
                ) : (
                  defaulterStudents.slice(0, 4).map((student) => (
                    <div
                      key={student.id}
                      className="p-3 rounded-2xl bg-rose-50/50 hover:bg-rose-50 transition-colors border border-rose-200 flex items-center justify-between gap-3"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-sm text-rose-950">{student.nameUr}</span>
                          <span className="text-[11px] font-mono text-slate-500 bg-white px-1.5 py-0.2 rounded border border-slate-200">
                            {student.rollNo}
                          </span>
                        </div>
                        <p className="text-xs text-slate-600 mt-0.5">
                          والد: {student.fatherNameUr} | کلاس: {student.class}
                        </p>
                      </div>

                      <div className="text-left shrink-0">
                        <span className="font-mono font-bold text-sm text-rose-700 block">
                          {student.monthlyFee} روپے
                        </span>
                        <button
                          onClick={() => onNavigateTab('fees')}
                          className="mt-1 px-2.5 py-1 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-[11px] font-bold transition-colors cursor-pointer"
                        >
                          فیس وصول کریں
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
