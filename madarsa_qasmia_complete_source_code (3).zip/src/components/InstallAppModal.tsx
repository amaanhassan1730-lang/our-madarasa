import React, { useState, useEffect } from 'react';
import { Smartphone, Download, CheckCircle2, Share2, X, PlusSquare } from 'lucide-react';
import { Language } from '../i18n/translations';

interface InstallAppModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

export const InstallAppModal: React.FC<InstallAppModalProps> = ({
  isOpen,
  onClose,
  lang,
}) => {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isStandalone, setIsStandalone] = useState(false);

  useEffect(() => {
    // Check if already installed
    if (window.matchMedia('(display-mode: standalone)').matches) {
      setIsStandalone(true);
    }

    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  if (!isOpen) return null;

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setDeferredPrompt(null);
        onClose();
      }
    }
  };

  const isUrdu = lang === 'ur';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl shadow-2xl border-2 border-emerald-600/40 w-full max-w-md overflow-hidden animate-in fade-in duration-200">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#0F5D2F] to-[#0a4221] text-white p-5 flex items-center justify-between border-b-4 border-amber-500">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-white/15 flex items-center justify-center p-1.5 shadow-inner border border-white/20">
              <img src="/app-icon.svg" alt="App Icon" className="w-full h-full object-contain" />
            </div>
            <div>
              <h3 className="font-bold text-lg font-urdu leading-tight">
                {isUrdu ? 'موبائل ایپ انسٹال کریں' : 'Install Mobile App'}
              </h3>
              <p className="text-xs text-emerald-200 font-urdu">
                {isUrdu ? 'بغیر براؤزر اصل ایپ کی طرح چلائیں' : 'Run like a native app on home screen'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4 font-urdu text-slate-800">
          {/* App Preview Card */}
          <div className="flex items-center gap-3.5 p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200">
            <div className="w-14 h-14 rounded-2xl overflow-hidden shadow-md shrink-0 bg-[#0F5D2F] p-2 border-2 border-amber-400">
              <img src="/app-icon.svg" alt="Madarsa App" className="w-full h-full object-contain" />
            </div>
            <div>
              <div className="font-black text-base text-emerald-950">مدرسہ قاسمیہ</div>
              <p className="text-xs text-slate-600">نظامِ تعلیم، حفظ ڈائری، حاضری و مالیات</p>
              <span className="inline-block mt-1 text-[11px] bg-emerald-200 text-emerald-900 font-bold px-2 py-0.5 rounded-md">
                Cloud Synced ☁️ Real-time
              </span>
            </div>
          </div>

          {/* If Native PWA Install Button is available */}
          {deferredPrompt && (
            <button
              onClick={handleInstallClick}
              className="w-full py-3 px-4 bg-emerald-700 hover:bg-emerald-800 text-white rounded-2xl font-bold flex items-center justify-center gap-2 shadow-lg transition-all active:scale-95 cursor-pointer text-base"
            >
              <Download className="w-5 h-5 text-amber-300" />
              <span>{isUrdu ? 'ابھی موبائل میں انسٹال کریں' : 'Install to Home Screen Now'}</span>
            </button>
          )}

          {/* Easy Instructions for Android & iPhone */}
          <div className="space-y-3 pt-2">
            <h4 className="font-bold text-sm text-slate-900 flex items-center gap-1.5 border-b border-slate-200 pb-1.5">
              <Smartphone className="w-4 h-4 text-emerald-700" />
              <span>{isUrdu ? 'موبائل پر انسٹال کرنے کا آسان طریقہ:' : 'Simple Installation Guide:'}</span>
            </h4>

            {/* Android instructions */}
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-1.5 leading-relaxed">
              <div className="font-bold text-emerald-900 flex items-center gap-1">
                <span>🤖</span>
                <span>Android موبائل (Chrome / Edge):</span>
              </div>
              <p className="text-slate-600">
                1. اوپر دائیں کونے میں تین نقطوں (<strong className="text-slate-900">⋮</strong>) والے مینو پر ٹیپ کریں۔
              </p>
              <p className="text-slate-600">
                2. مینو سے <strong className="text-emerald-800 font-bold">"Install app"</strong> یا <strong className="text-emerald-800 font-bold">"Add to Home screen"</strong> منتخب کریں۔
              </p>
              <p className="text-slate-600">
                3. آپ کے موبائل کی ہوم اسکرین پر مدرسہ کا باقاعدہ ایپ آئیکون بن جائے گا!
              </p>
            </div>

            {/* iPhone / Safari instructions */}
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-1.5 leading-relaxed">
              <div className="font-bold text-slate-900 flex items-center gap-1">
                <span>🍎</span>
                <span>iPhone / iPad (Safari):</span>
              </div>
              <p className="text-slate-600">
                1. نیچے سینٹر میں <strong className="text-blue-600">Share</strong> بٹن (مربع مع اوپر کا تیر ⬆️) پر ٹیپ کریں۔
              </p>
              <p className="text-slate-600">
                2. لسٹ کو نیچے سکرول کر کے <strong className="text-blue-700 font-bold flex-inline items-center gap-1"><PlusSquare className="w-3.5 h-3.5 inline text-slate-700" /> "Add to Home Screen"</strong> پر کلک کریں۔
              </p>
              <p className="text-slate-600">
                3. اوپر دائیں کونے میں <strong>"Add"</strong> پر کلک کریں، ایپ فوراً شامل ہو جائے گی۔
              </p>
            </div>
          </div>

          <div className="pt-2 flex justify-end">
            <button
              onClick={onClose}
              className="px-5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold text-xs transition-colors cursor-pointer"
            >
              {isUrdu ? 'ٹھیک ہے، سمجھ گیا' : 'Got it, Close'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
