import React, { useState } from 'react';
import { NoticeAnnouncement, UserRole } from '../types';
import { Language, translations } from '../i18n/translations';
import { Bell, Plus, Share2, Calendar, Tag, AlertCircle, Sparkles } from 'lucide-react';

interface NoticeBoardViewProps {
  notices: NoticeAnnouncement[];
  onAddNotice: (notice: Omit<NoticeAnnouncement, 'id'>) => void;
  lang: Language;
  currentRole: UserRole;
}

export const NoticeBoardView: React.FC<NoticeBoardViewProps> = ({
  notices,
  onAddNotice,
  lang,
  currentRole,
}) => {
  const t = translations[lang];
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // Form State
  const [titleUr, setTitleUr] = useState('');
  const [contentUr, setContentUr] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [category, setCategory] = useState<'holiday' | 'event' | 'admission' | 'general'>('general');
  const [priority, setPriority] = useState<'high' | 'normal'>('normal');

  const canManage = currentRole === 'admin' || currentRole === 'ustad';

  const handleCreateNotice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!titleUr.trim() || !contentUr.trim()) return;

    onAddNotice({
      titleUr: titleUr.trim(),
      titleEn: titleUr.trim(),
      contentUr: contentUr.trim(),
      contentEn: contentUr.trim(),
      date,
      category,
      priority,
      author: currentRole === 'admin' ? 'مہتمم صاحب' : 'دفتر اساتذہ',
    });

    setTitleUr('');
    setContentUr('');
    setIsAddModalOpen(false);
  };

  const handleShareToWhatsApp = (notice: NoticeAnnouncement) => {
    const text = `📢 *اطلاع عام - مدرسہ قاسمیہ*
━━━━━━━━━━━━━━━━━
📌 *${notice.titleUr}*
بتاریخ: ${notice.date}
منجانب: ${notice.author}
━━━━━━━━━━━━━━━━━
${notice.contentUr}
━━━━━━━━━━━━━━━━━
انتظامیہ مدرسہ قاسمیہ للبنین والبنات
رابطہ: 0300-1234567`;

    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  };

  const getCategoryBadge = (cat: NoticeAnnouncement['category']) => {
    switch (cat) {
      case 'holiday':
        return { label: 'تعطیل / چھٹیاں 🏖️', bg: 'bg-rose-100 text-rose-800 border-rose-200' };
      case 'event':
        return { label: 'جلسہ و تقریب 🕌', bg: 'bg-amber-100 text-amber-900 border-amber-200' };
      case 'admission':
        return { label: 'داخلہ اعلان 🎓', bg: 'bg-emerald-100 text-emerald-900 border-emerald-200' };
      default:
        return { label: 'عمومی نوٹس 📌', bg: 'bg-slate-100 text-slate-800 border-slate-200' };
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-linear-to-r from-[#0a4221] via-[#0F5D2F] to-[#167039] text-white p-6 rounded-3xl shadow-lg flex flex-wrap items-center justify-between gap-4 border border-emerald-500/30">
        <div>
          <div className="flex items-center gap-2 text-amber-300 font-bold text-sm">
            <Bell className="w-5 h-5" />
            <span className="font-urdu">مرکزی اطلاعات و اعلانات</span>
          </div>
          <h1 className="text-2xl font-black font-urdu mt-1">
            {lang === 'ur' ? 'اعلانات و نوٹس بورڈ' : 'Notice Board & Announcements'}
          </h1>
          <p className="text-emerald-100 text-xs font-urdu max-w-xl mt-1">
            {lang === 'ur'
              ? 'مدرسہ کی تعطیلات، جلسہ دستار بندی، داخلہ امتحانات اور اہم ہدایات کی باضابطہ اطلاعات۔'
              : 'Official circulars, holiday schedules, graduation ceremonies, and parent announcements.'}
          </p>
        </div>

        {canManage && (
          <button
            onClick={() => setIsAddModalOpen(true)}
            className="flex items-center gap-2 bg-amber-400 hover:bg-amber-500 text-emerald-950 font-black px-5 py-3 rounded-2xl shadow-md transition-all active:scale-95 cursor-pointer text-sm font-urdu"
          >
            <Plus className="w-5 h-5" />
            <span>{lang === 'ur' ? 'نیا اعلان جاری کریں' : 'Post Announcement'}</span>
          </button>
        )}
      </div>

      {/* Notice List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {notices.map((notice) => {
          const badge = getCategoryBadge(notice.category);
          const isHigh = notice.priority === 'high';

          return (
            <div
              key={notice.id}
              className={`bg-white rounded-3xl border-2 p-5 shadow-sm hover:shadow-md transition-all flex flex-col justify-between gap-4 relative overflow-hidden ${
                isHigh ? 'border-amber-400/80 ring-2 ring-amber-400/20' : 'border-slate-200'
              }`}
            >
              {isHigh && (
                <div className="absolute top-0 left-0 bg-amber-500 text-emerald-950 px-3 py-0.5 rounded-br-2xl text-[10px] font-black font-urdu flex items-center gap-1">
                  <Sparkles className="w-3 h-3" />
                  <span>اہم ترین اطلاع</span>
                </div>
              )}

              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full border font-urdu ${badge.bg}`}>
                    {badge.label}
                  </span>
                  <div className="flex items-center gap-1 text-slate-500 text-xs font-mono">
                    <Calendar className="w-3.5 h-3.5" />
                    <span>{notice.date}</span>
                  </div>
                </div>

                <h3 className="text-lg font-black text-emerald-950 font-urdu leading-snug">
                  {notice.titleUr}
                </h3>

                <p className="mt-2 text-slate-700 font-urdu text-sm leading-relaxed whitespace-pre-line bg-slate-50 p-3 rounded-2xl border border-slate-100">
                  {notice.contentUr}
                </p>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-xs font-urdu">
                <span className="text-slate-500">
                  منجانب: <strong className="text-slate-800">{notice.author}</strong>
                </span>

                <button
                  onClick={() => handleShareToWhatsApp(notice)}
                  className="flex items-center gap-1.5 bg-emerald-100 hover:bg-emerald-200 text-emerald-900 font-bold px-3 py-1.5 rounded-xl transition-colors cursor-pointer"
                >
                  <Share2 className="w-3.5 h-3.5 text-emerald-700" />
                  <span>واٹس ایپ پر بھیجیں 💬</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Notice Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl shadow-2xl border-2 border-emerald-600/30 w-full max-w-lg overflow-hidden animate-in fade-in duration-200 my-auto font-urdu">
            <div className="bg-[#0F5D2F] text-white p-4 flex items-center justify-between border-b-4 border-amber-500">
              <div className="flex items-center gap-2">
                <Bell className="w-5 h-5 text-amber-300" />
                <h3 className="font-bold text-lg">نیا اعلان / نوٹس جاری کریں</h3>
              </div>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="text-white/80 hover:text-white text-xl font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateNotice} className="p-5 space-y-4 text-sm">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">اعلان کا عنوان:</label>
                <input
                  type="text"
                  value={titleUr}
                  onChange={(e) => setTitleUr(e.target.value)}
                  placeholder="مثال: عید الفطر کی تعطیلات کا شیڈول"
                  className="w-full p-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">تاریخ:</label>
                  <input
                    type="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full p-2 rounded-xl border border-slate-300 font-mono text-xs"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">قسم:</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as any)}
                    className="w-full p-2 rounded-xl border border-slate-300 text-xs"
                  >
                    <option value="general">عمومی اطلاع</option>
                    <option value="holiday">تعطیلات / چھٹیاں</option>
                    <option value="event">جلسہ / تقریب</option>
                    <option value="admission">داخلہ اعلان</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">ترجیح:</label>
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value as any)}
                    className="w-full p-2 rounded-xl border border-slate-300 text-xs"
                  >
                    <option value="normal">عام</option>
                    <option value="high">اہم ترین (Highlight)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">اعلان کی مکمل تفصیل:</label>
                <textarea
                  rows={4}
                  value={contentUr}
                  onChange={(e) => setContentUr(e.target.value)}
                  placeholder="یہاں اعلان کا مکمل متن لکھیں..."
                  className="w-full p-3 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-600 leading-relaxed"
                  required
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 bg-emerald-700 hover:bg-emerald-800 text-white font-black py-3 rounded-2xl shadow-md cursor-pointer transition-all"
                >
                  اعلان جاری کریں 📢
                </button>
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-2xl cursor-pointer"
                >
                  منسوخ
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
