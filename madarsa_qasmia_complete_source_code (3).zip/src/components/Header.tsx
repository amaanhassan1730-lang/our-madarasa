import React from 'react';
import { UserRole } from '../types';
import { translations, Language } from '../i18n/translations';
import { Download, Globe, LogOut, ShieldCheck, Cloud, Smartphone, Package } from 'lucide-react';
import { triggerProjectZipDownload } from '../utils/downloadZip';

interface HeaderProps {
  lang: Language;
  onToggleLang: () => void;
  currentRole: UserRole;
  activeTeacherName?: string;
  onOpenRoleModal: () => void;
  madrasaNameUr: string;
  madrasaNameEn: string;
  taglineUr: string;
  taglineEn: string;
  activeTab: string;
  onSelectTab: (tab: string) => void;
  onDownloadSingleFile: () => void;
  onOpenWhatsAppCenter?: () => void;
  onOpenInstallModal?: () => void;
  onOpenSourceCodeModal?: () => void;
  onOpenShortcutsModal?: () => void;
  parentStudentName?: string;
  isCloudSynced?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  lang,
  onToggleLang,
  currentRole,
  activeTeacherName,
  onOpenRoleModal,
  madrasaNameUr,
  madrasaNameEn,
  taglineUr,
  taglineEn,
  activeTab,
  onSelectTab,
  onDownloadSingleFile,
  onOpenWhatsAppCenter,
  onOpenInstallModal,
  onOpenSourceCodeModal,
  onOpenShortcutsModal,
  parentStudentName,
  isCloudSynced = true,
}) => {
  const t = translations[lang];

  const navItems = [
    { id: 'dashboard', label: currentRole === 'parent' ? (lang === 'ur' ? 'بچے کا پورٹل' : 'Child Portal') : t.navDashboard, iconLabel: t.iconHome, icon: '🕌' },
    { id: 'students', label: t.navStudents, iconLabel: t.iconStudents, icon: '🎓' },
    { id: 'attendance', label: currentRole === 'parent' ? (lang === 'ur' ? 'حاضری ریکارڈ' : 'Attendance') : t.navAttendance, iconLabel: t.iconAttendance, icon: '✅' },
    { id: 'hifz', label: currentRole === 'parent' ? (lang === 'ur' ? 'روزانہ ڈائری و سبق' : 'Daily Sabaq & Diary') : (lang === 'ur' ? 'جامع ڈائری (حفظ و ناظرہ)' : 'Advanced Hifz & Nazra Diary'), iconLabel: 'ڈائری', icon: '📖' },
    { id: 'mushaf', label: lang === 'ur' ? 'مصحف شریف (۳۰ پارہ)' : 'Mushaf (30 Paras)', iconLabel: 'مصحف', icon: '📜' },
    { id: 'revision', label: lang === 'ur' ? 'اسمارٹ ریویژن شیڈولر' : 'Smart Revision Scheduler', iconLabel: 'ریویژن', icon: '⚡' },
    { id: 'diniyat', label: lang === 'ur' ? 'دینیات نصاب (۱۲ ہفتے)' : '12-Week Diniyat Syllabus', iconLabel: 'دینیات', icon: '📿' },
    { id: 'donors', label: lang === 'ur' ? 'معاونین و مخلصین (Donors)' : 'Donors Management', iconLabel: 'مخلصین', icon: '🤝' },
    { id: 'fees', label: currentRole === 'parent' ? (lang === 'ur' ? 'فیس و واجبات' : 'Fees Status') : t.navFees, iconLabel: t.iconMoney, icon: '💰' },
    { id: 'donations', label: t.navDonations, iconLabel: t.iconDonations, icon: '🪙' },
    { id: 'exams', label: currentRole === 'parent' ? (lang === 'ur' ? 'رزلٹ کارڈ' : 'Result Card') : (lang === 'ur' ? 'امتحانات و رزلٹ' : 'Exams & Results'), iconLabel: 'امتحانات', icon: '🏆' },
    { id: 'notices', label: lang === 'ur' ? 'اعلانات بورڈ' : 'Notice Board', iconLabel: 'اعلانات', icon: '📢' },
    { id: 'timetable', label: t.navTimetable, iconLabel: t.iconTime, icon: '🗓️' },
    { id: 'reports', label: t.navReports, iconLabel: t.iconBackup, icon: '🖨️' },
  ];

  // Role permissions filter for tabs
  const filteredNavItems = navItems.filter((item) => {
    // Parent strictly sees their child's portal, sabaq diary, attendance, fees, exams, mushaf, and school notices (اعلانات)!
    // No masjid expenses, no donations (chanda), no donors (moaween), no other students!
    if (currentRole === 'parent') {
      return ['dashboard', 'hifz', 'attendance', 'fees', 'exams', 'mushaf', 'notices'].includes(item.id);
    }
    // Teacher sees their assigned students, attendance, hifz diary, mushaf, revision, diniyat, exams, timetable, notices
    // Teacher DOES NOT see masjid kharch, chanda, or moaween!
    if (currentRole === 'ustad') {
      return ['dashboard', 'students', 'attendance', 'hifz', 'mushaf', 'revision', 'diniyat', 'exams', 'timetable', 'notices'].includes(item.id);
    }
    if (currentRole === 'accountant') {
      return ['dashboard', 'students', 'donors', 'fees', 'donations', 'notices', 'reports'].includes(item.id);
    }
    return true; // Admin has all tabs
  });

  const getRoleLabel = () => {
    switch (currentRole) {
      case 'admin':
        return t.roleAdmin;
      case 'ustad':
        return activeTeacherName ? `استاد: ${activeTeacherName}` : t.roleUstad;
      case 'accountant':
        return t.roleAccountant;
      case 'parent':
        return parentStudentName ? `سرپرست (${parentStudentName})` : t.roleParent;
      default:
        return currentRole;
    }
  };

  return (
    <header className="bg-[#0F5D2F] text-white shadow-lg border-b-4 border-amber-500 sticky top-0 z-40">
      {/* Top Bismillah & Utility Bar */}
      <div className="bg-[#0a4221] px-4 py-1.5 border-b border-emerald-800/60 text-xs">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-emerald-200/90 font-arabic text-sm">
            <span>✨</span>
            <span className="tracking-wide">{t.islamicGreeting}</span>
          </div>

          <div className="flex items-center gap-3">
            {/* Real-time Cloud Sync Status */}
            <div className="flex items-center gap-1.5 text-xs bg-emerald-900/80 px-2.5 py-0.5 rounded-full border border-emerald-600/60 font-urdu shadow-2xs">
              <span className={`w-2 h-2 rounded-full ${isCloudSynced ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
              <Cloud className="w-3.5 h-3.5 text-emerald-300" />
              <span className="text-emerald-100 font-bold font-sans text-[11px]">
                {isCloudSynced ? 'Cloud Synced ☁️' : 'Local Mode'}
              </span>
            </div>

            {/* Install Mobile App Button */}
            {onOpenInstallModal && (
              <button
                onClick={onOpenInstallModal}
                title="موبائل ایپ کی طرح انسٹال کریں"
                className="flex items-center gap-1.5 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-emerald-950 font-black px-3 py-1 rounded-lg text-xs transition-all shadow-md cursor-pointer active:scale-95 border border-amber-300"
              >
                <Smartphone className="w-3.5 h-3.5 text-emerald-950" />
                <span className="font-urdu font-black">موبائل ایپ انسٹال کریں 📲</span>
              </button>
            )}

            {/* Direct 100% Guaranteed Source Code ZIP Download Button */}
            <button
              onClick={() => {
                triggerProjectZipDownload('madarsa_qasmia_complete_source_code.zip');
                if (onOpenSourceCodeModal) onOpenSourceCodeModal();
              }}
              title="مکمل سورس کوڈ ZIP فائل ڈاؤن لوڈ کریں (برائے Vercel و لوکل سسٹم)"
              className="flex items-center gap-1.5 bg-linear-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-emerald-950 font-black px-3 py-1 rounded-md text-xs transition-all shadow-md cursor-pointer border border-amber-300 active:scale-95"
            >
              <Package className="w-3.5 h-3.5 text-emerald-950" />
              <span className="font-urdu">مکمل سورس کوڈ ZIP 📦</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Branding & Actions Bar */}
      <div className="max-w-7xl mx-auto px-4 py-3 flex flex-wrap items-center justify-between gap-4">
        {/* Madrasa Logo & Title */}
        <div className="flex items-center gap-3.5">
          <div className="w-13 h-13 rounded-2xl bg-white/10 p-2 flex items-center justify-center text-3xl shadow-inner border border-white/20 hover:scale-105 transition-transform">
            🕌
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl lg:text-3xl font-black tracking-tight text-white font-urdu">
                {lang === 'ur' ? madrasaNameUr : madrasaNameEn}
              </h1>
              <span className="hidden md:inline-block px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-amber-400 text-emerald-950 rounded font-sans">
                OFFLINE
              </span>
            </div>
            <p className="text-xs sm:text-sm text-emerald-100 font-urdu opacity-90 mt-0.5">
              {lang === 'ur' ? taglineUr : taglineEn}
            </p>
          </div>
        </div>

        {/* User Role Badge & Language Switcher */}
        <div className="flex items-center gap-2.5 sm:gap-3">
          {/* Language Toggle Button */}
          <button
            onClick={onToggleLang}
            id="lang-toggle-btn"
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/15 hover:bg-white/25 active:scale-95 text-white font-bold text-sm transition-all border border-white/30 shadow-sm cursor-pointer"
          >
            <Globe className="w-4 h-4 text-emerald-200" />
            <span className="font-sans">{lang === 'ur' ? 'English' : 'اردو'}</span>
          </button>

          {/* Keyboard Shortcuts Trigger Button */}
          {onOpenShortcutsModal && (
            <button
              type="button"
              onClick={onOpenShortcutsModal}
              title={lang === 'ur' ? 'کی بورڈ شارٹ کٹس گائیڈ (Alt + K)' : 'Keyboard Shortcuts Guide (Alt + K)'}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/15 hover:bg-amber-400 hover:text-emerald-950 active:scale-95 text-amber-300 font-bold text-xs sm:text-sm transition-all border border-amber-300/40 shadow-sm cursor-pointer"
            >
              <span className="text-base">⌨️</span>
              <span className="hidden sm:inline font-urdu font-black">
                {lang === 'ur' ? 'شارٹ کٹس' : 'Shortcuts'}
              </span>
            </button>
          )}

          {/* WhatsApp Messaging Hub Trigger Button */}
          <button
            type="button"
            onClick={onOpenWhatsAppCenter}
            title="مرکزی واٹس ایپ میسجنگ سینٹر کھولیں"
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#25D366] hover:bg-[#1EBE5D] text-slate-950 font-black text-xs sm:text-sm transition-all shadow-md active:scale-95 cursor-pointer"
          >
            <span className="text-base">💬</span>
            <span className="hidden sm:inline font-urdu font-black">واٹس ایپ الرٹس</span>
          </button>

          {/* Role Status & Switch Modal Button */}
          <button
            onClick={onOpenRoleModal}
            id="role-switch-btn"
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 active:scale-95 text-emerald-950 font-black text-xs sm:text-sm transition-all shadow-md border border-amber-300 cursor-pointer"
          >
            <span className="text-base">
              {currentRole === 'admin' ? '👑' : currentRole === 'ustad' ? '📖' : currentRole === 'accountant' ? '💰' : '👨‍👩‍👦'}
            </span>
            <span className="font-urdu font-bold">{getRoleLabel()}</span>
            <LogOut className="w-3.5 h-3.5 opacity-70 ml-1" />
          </button>
        </div>
      </div>

      {/* Accessible Navigation Bar with High Contrast & Visual Icons for Illiterate/Semi-illiterate Accessibility */}
      <nav className="bg-[#0b4e27] border-t border-emerald-700/80 px-2 sm:px-4 overflow-x-auto scrollbar-none">
        <div className="max-w-7xl mx-auto flex items-center gap-1.5 sm:gap-2 py-1.5 min-w-max">
          {filteredNavItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectTab(item.id)}
                id={`nav-${item.id}`}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-sm sm:text-base font-bold transition-all cursor-pointer select-none ${
                  isActive
                    ? 'bg-amber-400 text-emerald-950 shadow-md transform scale-[1.02] border-b-2 border-amber-600'
                    : 'text-emerald-100 hover:bg-emerald-800/80 hover:text-white'
                }`}
              >
                <span className="text-xl sm:text-2xl leading-none">{item.icon}</span>
                <span className="font-urdu tracking-wide">{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </header>
  );
};
