import React, { useState } from 'react';
import { X, Download, CheckCircle, FileCode, Copy, Check, Server, Terminal, ExternalLink } from 'lucide-react';
import { triggerProjectZipDownload } from '../utils/downloadZip';

interface SourceCodeDownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SourceCodeDownloadModal: React.FC<SourceCodeDownloadModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleDownload = () => {
    triggerProjectZipDownload('madarsa_qasmia_complete_source_code.zip');
    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 6000);
  };

  const handleCopyText = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2500);
  };

  const vercelJsonContent = `{
  "buildCommand": "npm run build",
  "outputDirectory": "dist",
  "framework": "vite",
  "rewrites": [
    {
      "source": "/(.*)",
      "destination": "/index.html"
    }
  ]
}`;

  const filesList = [
    { name: 'vercel.json', desc: 'Vercel پر لائیو کرنے کے لیے سنگل پیج روٹنگ کنفگریشن' },
    { name: 'package.json', desc: 'تمام لائبریریز اور رن اسکرپٹس (React 19 + Vite + Tailwind)' },
    { name: 'src/App.tsx', desc: 'مرکزی ایپلی کیشن مع رول بیسڈ لاگ ان و سیکیورٹی فلٹرز' },
    { name: 'src/components/Header.tsx', desc: 'نیویگیشن بار مع رول بیسڈ مینو' },
    { name: 'src/components/Dashboard.tsx', desc: 'والدین، اساتذہ اور ناظم کا تفصیلی ڈیش بورڈ' },
    { name: 'src/components/NoticeBoardView.tsx', desc: 'اعلانات و نوٹس بورڈ مع واٹس ایپ شیئرنگ' },
    { name: 'src/components/HifzDiaryView.tsx', desc: 'روزانہ قرآنی ڈائری، سبق، سبقی، منزل' },
    { name: 'src/components/AttendanceView.tsx', desc: 'استاد وار اور طالب علم وار حاضری ریکارڈ' },
    { name: 'src/components/FeeManagementView.tsx', desc: 'فیس اور کمپیوٹرائزڈ رسیدیں' },
    { name: 'src/components/ExamsView.tsx', desc: 'امتحانی رزلٹ کارڈ سسٹم' },
    { name: 'src/components/MushafView.tsx', desc: '۳۰ پارے مصحف شریف اور ڈیجیٹل تلاوت' },
    { name: 'index.html & vite.config.ts', desc: 'ویب انٹری پوائنٹ اور بیوٹی فل اردو فونٹس' },
    { name: 'README.md', desc: 'مکمل گائیڈ برائے Vercel ڈپلائمنٹ' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl border-2 border-emerald-700/30 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-linear-to-r from-[#0a4221] via-[#0F5D2F] to-[#146c37] p-5 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-400 text-emerald-950 flex items-center justify-center text-2xl font-black shadow-md">
              📦
            </div>
            <div>
              <h2 className="text-xl font-black font-urdu text-white">
                مکمل سورس کوڈ و پروجیکٹ ZIP ڈاؤن لوڈ
              </h2>
              <p className="text-xs text-emerald-200 font-urdu mt-0.5">
                Vercel یا ذاتی کمپیوٹر پر بغیر کسی خرابی کے چلانے کے لیے تیار
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-5 text-slate-800 font-urdu" dir="rtl">
          {/* Main Download Button */}
          <div className="bg-emerald-50 rounded-3xl p-5 border-2 border-emerald-300 text-center space-y-3">
            <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-emerald-600 text-white shadow-lg">
              <Download className="w-7 h-7 animate-bounce" />
            </div>
            <div>
              <h3 className="text-lg font-black text-emerald-950">
                مکمل سورس کوڈ ZIP فائل (100% گارنٹیڈ)
              </h3>
              <p className="text-xs text-slate-600 mt-1 max-w-md mx-auto">
                اس ZIP فائل میں تمام React / TypeScript فائلز، ماڈلز، Vercel کنفگریشن اور تمام نئے فیچرز شامل ہیں۔
              </p>
            </div>

            <button
              onClick={handleDownload}
              className="w-full sm:w-auto px-8 py-3.5 bg-linear-to-r from-emerald-700 via-emerald-800 to-emerald-900 hover:from-emerald-600 hover:to-emerald-800 text-white font-black text-base rounded-2xl shadow-xl hover:shadow-2xl transition-all cursor-pointer flex items-center justify-center gap-3 mx-auto border-2 border-amber-400 active:scale-95"
            >
              <Download className="w-5 h-5 text-amber-300" />
              <span>ڈاؤن لوڈ کریں (madarsa_qasmia_complete_source_code.zip)</span>
            </button>

            {downloadSuccess && (
              <div className="p-3 bg-emerald-100 border border-emerald-400 text-emerald-900 rounded-xl text-xs font-bold flex items-center justify-center gap-2 animate-fadeIn">
                <CheckCircle className="w-4 h-4 text-emerald-700" />
                <span>ZIP فائل کا ڈاؤن لوڈ کامیابی سے شروع ہو چکا ہے! اپنے ڈاؤن لوڈز فولڈر میں دیکھیں۔</span>
              </div>
            )}
          </div>

          {/* Vercel Deployment Guide */}
          <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 space-y-3">
            <div className="flex items-center gap-2 text-slate-900 font-black text-sm">
              <Server className="w-4 h-4 text-emerald-700" />
              <span>Vercel پر لائیو کرنے کے ۳ آسان مراحل:</span>
            </div>
            <ol className="text-xs text-slate-700 space-y-1.5 list-decimal list-inside pr-1 leading-relaxed">
              <li>ڈاؤن لوڈ کردہ ZIP فائل کو ان زپ (Extract) کریں۔</li>
              <li>اپنے <strong>GitHub</strong> اکاؤنٹ پر نیا ریپوزٹری بنا کر یہ تمام فائلز پش کریں۔</li>
              <li>
                <strong>Vercel.com</strong> پر جا کر <strong>"Add New Project"</strong> دبائیں اور ریپوزٹری منتخب کر کے Deploy پر کلک کریں۔
              </li>
            </ol>
          </div>

          {/* Included Files Overview */}
          <div className="space-y-2.5">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-black text-slate-700 flex items-center gap-1.5">
                <FileCode className="w-4 h-4 text-amber-600" />
                <span>ZIP فائل میں شامل اہم فائلز کی تفصیل:</span>
              </h4>
              <span className="text-[10px] text-slate-400">کل 13+ اہم ماڈیولز</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              {filesList.map((file, idx) => (
                <div key={idx} className="p-2.5 bg-white rounded-xl border border-slate-200">
                  <strong className="text-emerald-900 block font-mono text-[11px]" dir="ltr">
                    {file.name}
                  </strong>
                  <span className="text-slate-500 text-[11px] block mt-0.5">{file.desc}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Copy vercel.json if needed */}
          <div className="bg-slate-900 text-slate-100 rounded-2xl p-4 space-y-2" dir="ltr">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span className="font-mono text-emerald-400 font-bold">vercel.json</span>
              <button
                onClick={() => handleCopyText(vercelJsonContent, 'vercelJson')}
                className="flex items-center gap-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-[11px] font-sans transition-colors cursor-pointer"
              >
                {copiedKey === 'vercelJson' ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy vercel.json</span>
                  </>
                )}
              </button>
            </div>
            <pre className="text-[11px] font-mono text-emerald-300 bg-slate-950 p-2.5 rounded-lg overflow-x-auto">
              {vercelJsonContent}
            </pre>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="bg-slate-100 p-4 border-t border-slate-200 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2 bg-slate-300 hover:bg-slate-400 text-slate-900 font-bold text-xs rounded-xl transition-colors cursor-pointer font-urdu"
          >
            بند کریں
          </button>
        </div>
      </div>
    </div>
  );
};
