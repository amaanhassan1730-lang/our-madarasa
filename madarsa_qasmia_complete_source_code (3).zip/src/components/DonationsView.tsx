import React, { useState } from 'react';
import {
  DonationRecord,
  ExpenseRecord,
  DonationCategory,
  ExpenseCategory,
  UserRole,
  Donor,
} from '../types';
import { translations, Language } from '../i18n/translations';
import { createWhatsAppLink } from '../utils/storage';
import {
  Coins,
  PlusCircle,
  Printer,
  ArrowDownRight,
  ArrowUpRight,
  Receipt,
  X,
  Wallet,
  Building2,
  HeartHandshake,
  Send,
  Users,
  Search,
  Filter,
  CheckCircle,
  Phone,
  MapPin,
  Calendar,
} from 'lucide-react';

interface DonationsViewProps {
  donations: DonationRecord[];
  expenses: ExpenseRecord[];
  donors?: Donor[];
  onAddDonation: (donation: Omit<DonationRecord, 'id'>) => void;
  onAddExpense: (expense: Omit<ExpenseRecord, 'id'>) => void;
  onAddDonor?: (donor: Omit<Donor, 'id'>) => void;
  onPrintDonationVoucher: (donation: DonationRecord) => void;
  lang: Language;
  currentRole: UserRole;
  initialTab?: 'donations' | 'expenses' | 'donors';
}

export const DonationsView: React.FC<DonationsViewProps> = ({
  donations,
  expenses,
  donors = [],
  onAddDonation,
  onAddExpense,
  onAddDonor,
  onPrintDonationVoucher,
  lang,
  currentRole,
  initialTab = 'donations',
}) => {
  const t = translations[lang];
  const [activeTab, setActiveTab] = useState<'donations' | 'expenses' | 'donors'>(initialTab);

  React.useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab]);
  const [isDonationModalOpen, setIsDonationModalOpen] = useState(false);
  const [isExpenseModalOpen, setIsExpenseModalOpen] = useState(false);
  const [isDonorModalOpen, setIsDonorModalOpen] = useState(false);

  // Donors filter and search state
  const [donorSearch, setDonorSearch] = useState('');
  const [donorCategoryFilter, setDonorCategoryFilter] = useState<string>('all');

  // Donation Form State
  const [donationForm, setDonationForm] = useState({
    voucherNo: `DON-2026-${String(donations.length + 104).padStart(3, '0')}`,
    date: new Date().toISOString().split('T')[0],
    donorName: '',
    donorPhone: '',
    category: 'Lillah' as DonationCategory,
    amount: 5000,
    paymentMode: 'Cash' as 'Cash' | 'Online' | 'Cheque',
    purpose: '',
    collectorName: 'مولانا عمران (خزانچی)',
  });

  // Expense Form State
  const [expenseForm, setExpenseForm] = useState({
    voucherNo: `EXP-2026-${String(expenses.length + 44).padStart(3, '0')}`,
    date: new Date().toISOString().split('T')[0],
    title: '',
    category: 'Kitchen' as ExpenseCategory,
    amount: 3000,
    paidTo: '',
    approvedBy: 'مہتمم صاحب',
    notes: '',
  });

  // Donor Form State
  const [donorForm, setDonorForm] = useState({
    name: '',
    fatherName: '',
    phone: '',
    category: 'ماہانہ' as 'ماہانہ' | 'سالانہ' | 'زکوٰۃ' | 'صدقہ' | 'لِلّٰہ' | 'تعمیر',
    frequency: 'ماہانہ' as 'ماہانہ' | 'سالانہ' | 'یکمشتی',
    promisedAmount: 5000,
    address: '',
    notes: 'مخلص و معاون مدرسہ',
  });

  // Financial Stats
  const totalDonations = donations.reduce((sum, d) => sum + (d.amount || 0), 0);
  const totalExpenses = expenses.reduce((sum, e) => sum + (e.amount || 0), 0);
  const netBalance = totalDonations - totalExpenses;

  // Breakdown by Category
  const lillahTotal = donations
    .filter((d) => d.category === 'Lillah')
    .reduce((sum, d) => sum + d.amount, 0);
  const zakatTotal = donations
    .filter((d) => d.category === 'Zakat')
    .reduce((sum, d) => sum + d.amount, 0);
  const buildingTotal = donations
    .filter((d) => d.category === 'Building')
    .reduce((sum, d) => sum + d.amount, 0);

  const handleDonationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!donationForm.donorName.trim()) return;

    onAddDonation(donationForm);
    setIsDonationModalOpen(false);
    setDonationForm({
      voucherNo: `DON-2026-${String(donations.length + 105).padStart(3, '0')}`,
      date: new Date().toISOString().split('T')[0],
      donorName: '',
      donorPhone: '',
      category: 'Lillah',
      amount: 5000,
      paymentMode: 'Cash',
      purpose: '',
      collectorName: 'مولانا عمران (خزانچی)',
    });
  };

  const handleExpenseSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!expenseForm.title.trim()) return;

    onAddExpense(expenseForm);
    setIsExpenseModalOpen(false);
    setExpenseForm({
      voucherNo: `EXP-2026-${String(expenses.length + 45).padStart(3, '0')}`,
      date: new Date().toISOString().split('T')[0],
      title: '',
      category: 'Kitchen',
      amount: 3000,
      paidTo: '',
      approvedBy: 'مہتمم صاحب',
      notes: '',
    });
  };

  const handleDonorSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!donorForm.name.trim() || !onAddDonor) return;

    onAddDonor({
      ...donorForm,
      totalContributed: 0,
      lastDonationDate: new Date().toISOString().split('T')[0],
    });
    setIsDonorModalOpen(false);
    setDonorForm({
      name: '',
      fatherName: '',
      phone: '',
      category: 'ماہانہ',
      frequency: 'ماہانہ',
      promisedAmount: 5000,
      address: '',
      notes: 'مخلص و معاون مدرسہ',
    });
  };

  // WhatsApp Thank You Receipt
  const handleSendDonationWhatsApp = (donation: DonationRecord) => {
    const msg = `محترم جناب ${donation.donorName}! السلام علیکم ورحمۃ اللہ، مدرسہ قاسمیہ کو آپ کی طرف سے مبلغ ${donation.amount.toLocaleString()} روپے بطریق ${donation.paymentMode} بمد ${donation.category} موصول ہو گئے ہیں۔\nرسید نمبر: ${donation.voucherNo}\nبتاریخ: ${donation.date}\nاللہ تعالیٰ آپ کے مال و جان میں برکتیں عطا فرمائے اور اس تعاون کو دارین کی نجات کا ذریعہ بنائے۔ آمین۔\nمنجانب: ادارہ مدرسہ قاسمیہ`;
    const url = createWhatsAppLink(donation.donorPhone, msg);
    window.open(url, '_blank');
  };

  // WhatsApp Greeting to Donor
  const handleSendDonorWhatsApp = (donor: Donor) => {
    const msg = `محترم جناب ${donor.name}! السلام علیکم ورحمۃ اللہ، مدرسہ قاسمیہ کے تمام اساتذہ و طلبہ آپ کے مخلصانہ تعاون و دعاؤں کے تہہ دل سے شکر گزار ہیں۔ اللہ رب العزت آپ کے کاروبار و اہل خانہ کو سلامت رکھے۔ آمین۔`;
    const url = createWhatsAppLink(donor.phone, msg);
    window.open(url, '_blank');
  };

  // Pre-fill donation for a specific donor
  const handleQuickDonateFromDonor = (donor: Donor) => {
    setDonationForm({
      voucherNo: `DON-2026-${String(donations.length + 104).padStart(3, '0')}`,
      date: new Date().toISOString().split('T')[0],
      donorName: donor.name,
      donorPhone: donor.phone,
      category:
        donor.category === 'زکوٰۃ'
          ? 'Zakat'
          : donor.category === 'تعمیر'
          ? 'Building'
          : donor.category === 'صدقہ'
          ? 'Sadqah'
          : 'Lillah',
      amount: donor.promisedAmount || 5000,
      paymentMode: 'Online',
      purpose: `${donor.frequency} تعاون`,
      collectorName: 'مولانا عمران (خزانچی)',
    });
    setIsDonationModalOpen(true);
  };

  // Filtered donors list
  const filteredDonors = donors.filter((d) => {
    const matchesSearch =
      d.name.toLowerCase().includes(donorSearch.toLowerCase()) ||
      d.phone.includes(donorSearch) ||
      (d.address && d.address.toLowerCase().includes(donorSearch.toLowerCase()));

    const matchesCategory =
      donorCategoryFilter === 'all' || d.category === donorCategoryFilter;

    return matchesSearch && matchesCategory;
  });

  const canManage = currentRole === 'admin' || currentRole === 'nazim';

  return (
    <div className="space-y-6 animate-in fade-in duration-300 font-urdu">
      {/* Top Banner */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-13 h-13 rounded-2xl bg-purple-100 text-purple-800 flex items-center justify-center text-3xl shadow-inner border border-purple-200">
            🪙
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-emerald-950 font-urdu">
              {t.donationsLedgerTitle}
            </h2>
            <p className="text-xs text-slate-500 font-urdu">
              للہ، زکوٰۃ، تعمیراتی فنڈ، معاونین ڈائرکٹری اور اخراجات کا شفاف کھاتہ و واؤچرز
            </p>
          </div>
        </div>

        {canManage && (
          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => setIsDonorModalOpen(true)}
              className="flex items-center gap-2 bg-amber-500 hover:bg-amber-600 text-emerald-950 font-black px-4 py-2.5 rounded-2xl shadow-xs transition-all active:scale-95 cursor-pointer text-xs sm:text-sm"
            >
              <Users className="w-4 h-4" />
              <span>نیا معاون شامل کریں</span>
            </button>

            <button
              onClick={() => setIsDonationModalOpen(true)}
              id="add-donation-btn"
              className="flex items-center gap-2 bg-[#0F5D2F] hover:bg-emerald-800 text-white font-black px-4 py-2.5 rounded-2xl shadow-sm transition-all active:scale-95 cursor-pointer text-xs sm:text-sm"
            >
              <PlusCircle className="w-4 h-4 text-amber-400" />
              <span>{t.addDonation}</span>
            </button>

            <button
              onClick={() => setIsExpenseModalOpen(true)}
              id="add-expense-btn"
              className="flex items-center gap-2 bg-rose-700 hover:bg-rose-800 text-white font-black px-4 py-2.5 rounded-2xl shadow-sm transition-all active:scale-95 cursor-pointer text-xs sm:text-sm"
            >
              <PlusCircle className="w-4 h-4 text-amber-300" />
              <span>{t.addExpense}</span>
            </button>
          </div>
        )}
      </div>

      {/* Financial Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-emerald-50 border-2 border-emerald-200 p-4.5 rounded-2xl">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-emerald-800">{t.totalDonations}</span>
            <ArrowDownRight className="w-4 h-4 text-emerald-600" />
          </div>
          <span className="text-2xl sm:text-3xl font-black text-emerald-950 font-mono mt-1 block">
            {totalDonations.toLocaleString()} روپے
          </span>
          <div className="text-[11px] text-emerald-700 mt-2 flex items-center justify-between">
            <span>للہ: {lillahTotal.toLocaleString()}</span>
            <span>زکوٰۃ: {zakatTotal.toLocaleString()}</span>
            <span>تعمیر: {buildingTotal.toLocaleString()}</span>
          </div>
        </div>

        <div className="bg-rose-50 border-2 border-rose-200 p-4.5 rounded-2xl">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-rose-800">{t.totalExpenses}</span>
            <ArrowUpRight className="w-4 h-4 text-rose-600" />
          </div>
          <span className="text-2xl sm:text-3xl font-black text-rose-950 font-mono mt-1 block">
            {totalExpenses.toLocaleString()} روپے
          </span>
          <span className="text-[11px] text-rose-700 mt-2 block font-mono">
            {expenses.length} بل و اخراجات درج ہوئے
          </span>
        </div>

        <div className="bg-linear-to-br from-emerald-900 to-[#0F5D2F] text-white p-4.5 rounded-2xl shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-emerald-200">{t.netBalance}</span>
            <Wallet className="w-4 h-4 text-amber-400" />
          </div>
          <span className="text-2xl sm:text-3xl font-black text-amber-400 font-mono mt-1 block">
            {netBalance.toLocaleString()} روپے
          </span>
          <span className="text-[11px] text-emerald-200 mt-2 block">
            موجودہ محفوظ فنڈز برائے مدرسہ
          </span>
        </div>

        <div className="bg-amber-50 border-2 border-amber-200 p-4.5 rounded-2xl">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-amber-900">کل رجسٹرڈ معاونین</span>
            <HeartHandshake className="w-4 h-4 text-amber-700" />
          </div>
          <span className="text-2xl sm:text-3xl font-black text-amber-950 font-mono mt-1 block">
            {donors.length} مخلصین
          </span>
          <span className="text-[11px] text-amber-800 mt-2 block">
            ماہانہ و سالانہ مستقل عطیہ دہندگان
          </span>
        </div>
      </div>

      {/* Tabs Switcher: Donations vs Expenses vs Donors */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveTab('donations')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-sm font-bold transition-all cursor-pointer ${
            activeTab === 'donations'
              ? 'bg-[#0F5D2F] text-white shadow-sm'
              : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
          }`}
        >
          <Coins className="w-4 h-4" />
          <span>عطیات و چندہ کھاتہ ({donations.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('expenses')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-sm font-bold transition-all cursor-pointer ${
            activeTab === 'expenses'
              ? 'bg-rose-700 text-white shadow-sm'
              : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
          }`}
        >
          <Receipt className="w-4 h-4" />
          <span>اخراجات کھاتہ ({expenses.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('donors')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-sm font-bold transition-all cursor-pointer ${
            activeTab === 'donors'
              ? 'bg-amber-500 text-emerald-950 font-black shadow-sm'
              : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>معاونین و مخلصین ڈائرکٹری ({donors.length})</span>
        </button>
      </div>

      {/* 1. DONATIONS TABLE */}
      {activeTab === 'donations' && (
        <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-3">
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead className="bg-[#E8F5E9] text-emerald-900 font-urdu">
                <tr>
                  <th className="p-3">واؤچر نمبر</th>
                  <th className="p-3">تاریخ</th>
                  <th className="p-3">عطیہ دہندہ کا نام</th>
                  <th className="p-3">رابطہ فون</th>
                  <th className="p-3">کھاتہ / مد</th>
                  <th className="p-3">رقم</th>
                  <th className="p-3">طریقہ</th>
                  <th className="p-3">مقصد</th>
                  <th className="p-3 text-center">پرنٹ واؤچر</th>
                  <th className="p-3 text-center">واٹس ایپ رسید</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-emerald-50">
                {donations.map((don) => (
                  <tr key={don.id} className="hover:bg-emerald-50/40">
                    <td className="p-3 font-mono font-bold text-emerald-800">{don.voucherNo}</td>
                    <td className="p-3 font-mono">{don.date}</td>
                    <td className="p-3 font-bold text-slate-900">{don.donorName}</td>
                    <td className="p-3 font-mono" dir="ltr">
                      {don.donorPhone}
                    </td>
                    <td className="p-3">
                      <span
                        className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                          don.category === 'Lillah'
                            ? 'bg-emerald-100 text-emerald-800'
                            : don.category === 'Zakat'
                            ? 'bg-purple-100 text-purple-800'
                            : don.category === 'Building'
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {don.category === 'Lillah'
                          ? 'للہ'
                          : don.category === 'Zakat'
                          ? 'زکوٰۃ'
                          : don.category === 'Building'
                          ? 'تعمیرات'
                          : 'صدقہ'}
                      </span>
                    </td>
                    <td className="p-3 font-mono font-bold text-emerald-900">
                      {don.amount.toLocaleString()} روپے
                    </td>
                    <td className="p-3 font-bold text-slate-600">{don.paymentMode}</td>
                    <td className="p-3 text-slate-500">{don.purpose || '-'}</td>
                    <td className="p-3 text-center">
                      <button
                        onClick={() => onPrintDonationVoucher(don)}
                        className="p-1.5 rounded-lg bg-emerald-100 hover:bg-emerald-200 text-emerald-900 transition cursor-pointer"
                        title="واؤچر پرنٹ کریں"
                      >
                        <Printer className="w-4 h-4 inline" />
                      </button>
                    </td>
                    <td className="p-3 text-center">
                      <button
                        onClick={() => handleSendDonationWhatsApp(don)}
                        className="p-1.5 rounded-lg bg-[#25D366] hover:bg-[#20ba5a] text-white transition cursor-pointer"
                        title="واٹس ایپ پر رسید بھیجیں"
                      >
                        <Send className="w-4 h-4 inline" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 2. EXPENSES TABLE */}
      {activeTab === 'expenses' && (
        <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-3">
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead className="bg-rose-50 text-rose-950 font-urdu">
                <tr>
                  <th className="p-3">واؤچر نمبر</th>
                  <th className="p-3">تاریخ</th>
                  <th className="p-3">تفصیلِ خرچ</th>
                  <th className="p-3">شعبہ / مد</th>
                  <th className="p-3">رقم</th>
                  <th className="p-3">کس کو ادا کی گئی</th>
                  <th className="p-3">منظور کنندہ</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-rose-50">
                {expenses.map((exp) => (
                  <tr key={exp.id} className="hover:bg-rose-50/40">
                    <td className="p-3 font-mono font-bold text-rose-800">{exp.voucherNo}</td>
                    <td className="p-3 font-mono">{exp.date}</td>
                    <td className="p-3 font-bold text-slate-900">{exp.title}</td>
                    <td className="p-3">
                      <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-rose-100 text-rose-800">
                        {exp.category === 'Kitchen'
                          ? 'مطبخ / راشن'
                          : exp.category === 'Salaries'
                          ? 'اساتذہ تنخواہ'
                          : exp.category === 'Utilities'
                          ? 'بجلی/پانی بل'
                          : exp.category === 'Maintenance'
                          ? 'مرمت'
                          : 'کتب'}
                      </span>
                    </td>
                    <td className="p-3 font-mono font-bold text-rose-900">
                      {exp.amount.toLocaleString()} روپے
                    </td>
                    <td className="p-3 text-slate-700">{exp.paidTo}</td>
                    <td className="p-3 text-slate-500">{exp.approvedBy}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 3. DONORS DIRECTORY (معاونین و مخلصین لسٹ) */}
      {activeTab === 'donors' && (
        <div className="space-y-4">
          {/* Filter and Search Bar */}
          <div className="bg-white rounded-3xl p-4 border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3">
            <div className="relative flex-1 min-w-[240px]">
              <Search className="w-4 h-4 text-slate-400 absolute right-3 top-3" />
              <input
                type="text"
                value={donorSearch}
                onChange={(e) => setDonorSearch(e.target.value)}
                placeholder="معاون کا نام، فون نمبر یا شہر تلاش کریں..."
                className="w-full pl-3 pr-9 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm focus:border-amber-400 outline-hidden"
              />
            </div>

            {/* Category Filter */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
              {['all', 'ماہانہ', 'سالانہ', 'زکوٰۃ', 'صدقہ', 'لِلّٰہ', 'تعمیر'].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setDonorCategoryFilter(cat)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer shrink-0 ${
                    donorCategoryFilter === cat
                      ? 'bg-amber-500 text-emerald-950 font-black shadow-xs'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {cat === 'all' ? 'تمام زمرہ جات' : cat}
                </button>
              ))}
            </div>
          </div>

          {/* Donors Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredDonors.map((donor) => (
              <div
                key={donor.id}
                className="bg-white rounded-3xl p-5 border-2 border-amber-200/80 hover:border-amber-400 transition-all shadow-xs flex flex-col justify-between space-y-4"
              >
                <div>
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="font-black text-base text-emerald-950">{donor.name}</h4>
                      {donor.fatherName && (
                        <p className="text-xs text-slate-500">ولدیت: {donor.fatherName}</p>
                      )}
                    </div>
                    <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-900 border border-amber-300">
                      {donor.category}
                    </span>
                  </div>

                  <div className="mt-3 space-y-1.5 text-xs text-slate-600">
                    <div className="flex items-center gap-2">
                      <Phone className="w-3.5 h-3.5 text-emerald-600" />
                      <span className="font-mono font-bold" dir="ltr">
                        {donor.phone}
                      </span>
                    </div>

                    {donor.address && (
                      <div className="flex items-center gap-2">
                        <MapPin className="w-3.5 h-3.5 text-rose-500" />
                        <span>{donor.address}</span>
                      </div>
                    )}

                    <div className="flex items-center gap-2">
                      <Calendar className="w-3.5 h-3.5 text-amber-600" />
                      <span>تعدد: {donor.frequency} تعاون</span>
                    </div>
                  </div>

                  {/* Financial Overview for Donor */}
                  <div className="mt-3 p-3 bg-amber-50/60 rounded-2xl border border-amber-200 flex items-center justify-between text-xs">
                    <div>
                      <span className="text-[11px] text-slate-500 block">وعدہ شدہ رقم:</span>
                      <strong className="text-amber-950 font-mono text-sm">
                        {(donor.promisedAmount || 0).toLocaleString()} روپے
                      </strong>
                    </div>
                    <div className="text-left">
                      <span className="text-[11px] text-slate-500 block">کل جمع شدہ:</span>
                      <strong className="text-emerald-800 font-mono text-sm">
                        {(donor.totalContributed || 0).toLocaleString()} روپے
                      </strong>
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="pt-3 border-t border-slate-100 flex items-center gap-2">
                  <button
                    onClick={() => handleQuickDonateFromDonor(donor)}
                    className="flex-1 bg-[#0F5D2F] hover:bg-emerald-800 text-white text-xs font-bold py-2 rounded-xl transition cursor-pointer text-center"
                  >
                    عطیہ وصول کریں 💰
                  </button>

                  <button
                    onClick={() => handleSendDonorWhatsApp(donor)}
                    title="واٹس ایپ تشکر پیغام"
                    className="p-2 bg-[#25D366] hover:bg-[#20ba5a] text-white rounded-xl transition cursor-pointer"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ADD DONATION MODAL */}
      {isDonationModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden animate-in fade-in duration-200 my-8">
            <div className="bg-[#0F5D2F] text-white p-5 flex items-center justify-between border-b-4 border-amber-500">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center text-2xl">
                  🪙
                </div>
                <div>
                  <h3 className="font-bold text-lg font-urdu">{t.addDonation}</h3>
                  <p className="text-xs text-emerald-200 font-urdu">مدرسہ امداد و چندہ رسید</p>
                </div>
              </div>
              <button
                onClick={() => setIsDonationModalOpen(false)}
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleDonationSubmit} className="p-6 space-y-4 font-urdu">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">واؤچر نمبر:</label>
                  <input
                    type="text"
                    required
                    value={donationForm.voucherNo}
                    onChange={(e) =>
                      setDonationForm({ ...donationForm, voucherNo: e.target.value })
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-sm font-bold text-emerald-900"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">تاریخ:</label>
                  <input
                    type="date"
                    value={donationForm.date}
                    onChange={(e) => setDonationForm({ ...donationForm, date: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">
                  عطیہ دہندہ کا نام:
                </label>
                <input
                  type="text"
                  required
                  placeholder="مثال: حاجی عبد الرحمٰن صاحب"
                  value={donationForm.donorName}
                  onChange={(e) =>
                    setDonationForm({ ...donationForm, donorName: e.target.value })
                  }
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">
                    رابطہ فون نمبر:
                  </label>
                  <input
                    type="tel"
                    dir="ltr"
                    required
                    placeholder="+92 300 1234567"
                    value={donationForm.donorPhone}
                    onChange={(e) =>
                      setDonationForm({ ...donationForm, donorPhone: e.target.value })
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-sm text-left"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">مد / زمرہ:</label>
                  <select
                    value={donationForm.category}
                    onChange={(e) =>
                      setDonationForm({
                        ...donationForm,
                        category: e.target.value as DonationCategory,
                      })
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm bg-white"
                  >
                    <option value="Lillah">لِلّٰہ (Lillah)</option>
                    <option value="Zakat">زکوٰۃ (Zakat)</option>
                    <option value="Building">تعمیراتی فنڈ (Building)</option>
                    <option value="Sadqah">صدقہ (Sadqah)</option>
                    <option value="Fitra">فطرانہ (Fitra)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">
                    رقم (روپے):
                  </label>
                  <input
                    type="number"
                    min={1}
                    required
                    value={donationForm.amount}
                    onChange={(e) =>
                      setDonationForm({
                        ...donationForm,
                        amount: parseInt(e.target.value) || 0,
                      })
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono font-bold text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">طریقۂ ادائیگی:</label>
                  <select
                    value={donationForm.paymentMode}
                    onChange={(e) =>
                      setDonationForm({
                        ...donationForm,
                        paymentMode: e.target.value as any,
                      })
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm bg-white"
                  >
                    <option value="Cash">نقد (Cash)</option>
                    <option value="Online">آن لائن / جاز کیش / ایزی پیسہ</option>
                    <option value="Cheque">بینک چیک</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">مقصد / نوٹ:</label>
                <input
                  type="text"
                  placeholder="مثال: مطبخ کے راشن یا کتب کی خریداری کے لیے"
                  value={donationForm.purpose}
                  onChange={(e) =>
                    setDonationForm({ ...donationForm, purpose: e.target.value })
                  }
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
                />
              </div>

              <div className="flex items-center gap-3 pt-3 border-t border-slate-200">
                <button
                  type="submit"
                  className="flex-1 bg-[#0F5D2F] hover:bg-emerald-800 text-white font-bold py-3 px-6 rounded-2xl shadow-md transition-all cursor-pointer"
                >
                  عطیہ محفوظ کریں اور واؤچر بنائیں
                </button>
                <button
                  type="button"
                  onClick={() => setIsDonationModalOpen(false)}
                  className="px-5 py-3 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-sm cursor-pointer"
                >
                  {t.cancel}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ADD EXPENSE MODAL */}
      {isExpenseModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden animate-in fade-in duration-200 my-8">
            <div className="bg-rose-700 text-white p-5 flex items-center justify-between border-b-4 border-amber-400">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center text-2xl">
                  🧾
                </div>
                <div>
                  <h3 className="font-bold text-lg font-urdu">{t.addExpense}</h3>
                  <p className="text-xs text-rose-200 font-urdu">مدرسہ اخراجات واؤچر</p>
                </div>
              </div>
              <button
                onClick={() => setIsExpenseModalOpen(false)}
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleExpenseSubmit} className="p-6 space-y-4 font-urdu">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">واؤچر نمبر:</label>
                  <input
                    type="text"
                    required
                    value={expenseForm.voucherNo}
                    onChange={(e) =>
                      setExpenseForm({ ...expenseForm, voucherNo: e.target.value })
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">تاریخ:</label>
                  <input
                    type="date"
                    value={expenseForm.date}
                    onChange={(e) =>
                      setExpenseForm({ ...expenseForm, date: e.target.value })
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">تفصیلِ خرچ:</label>
                <input
                  type="text"
                  required
                  placeholder="مثال: مطبخ کے لیے آٹا، گھی اور چاول کی خریداری"
                  value={expenseForm.title}
                  onChange={(e) =>
                    setExpenseForm({ ...expenseForm, title: e.target.value })
                  }
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">شعبہ / مد:</label>
                  <select
                    value={expenseForm.category}
                    onChange={(e) =>
                      setExpenseForm({
                        ...expenseForm,
                        category: e.target.value as ExpenseCategory,
                      })
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm bg-white"
                  >
                    <option value="Kitchen">مطبخ / راشن</option>
                    <option value="Salaries">اساتذہ تنخواہیں</option>
                    <option value="Utilities">بجلی، گیس، پانی بل</option>
                    <option value="Maintenance">مرمت و تعمیر</option>
                    <option value="Books">کتب و اسٹیشنری</option>
                    <option value="Other">متفرق</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">
                    رقم (روپے):
                  </label>
                  <input
                    type="number"
                    min={1}
                    required
                    value={expenseForm.amount}
                    onChange={(e) =>
                      setExpenseForm({
                        ...expenseForm,
                        amount: parseInt(e.target.value) || 0,
                      })
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono font-bold text-sm"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">کس کو ادا کی گئی:</label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: مدینہ کریانہ اسٹور"
                    value={expenseForm.paidTo}
                    onChange={(e) =>
                      setExpenseForm({ ...expenseForm, paidTo: e.target.value })
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">منظور کنندہ:</label>
                  <input
                    type="text"
                    value={expenseForm.approvedBy}
                    onChange={(e) =>
                      setExpenseForm({ ...expenseForm, approvedBy: e.target.value })
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
                  />
                </div>
              </div>

              <div className="flex items-center gap-3 pt-3 border-t border-slate-200">
                <button
                  type="submit"
                  className="flex-1 bg-rose-700 hover:bg-rose-800 text-white font-bold py-3 px-6 rounded-2xl shadow-md transition-all cursor-pointer"
                >
                  خرچ کا اندراج محفوظ کریں
                </button>
                <button
                  type="button"
                  onClick={() => setIsExpenseModalOpen(false)}
                  className="px-5 py-3 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-sm cursor-pointer"
                >
                  {t.cancel}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ADD DONOR MODAL */}
      {isDonorModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden animate-in fade-in duration-200 my-8">
            <div className="bg-amber-500 text-emerald-950 p-5 flex items-center justify-between border-b-4 border-emerald-800">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-white/30 flex items-center justify-center text-2xl">
                  🤝
                </div>
                <div>
                  <h3 className="font-bold text-lg font-urdu">معاونِ مدرسہ کا نیا اندراج</h3>
                  <p className="text-xs text-emerald-900 font-urdu font-bold">
                    مخلصین و ماہانہ عطیہ دہندگان کی فہرست
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsDonorModalOpen(false)}
                className="w-8 h-8 rounded-full bg-black/10 hover:bg-black/20 flex items-center justify-center text-emerald-950 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleDonorSubmit} className="p-6 space-y-4 font-urdu">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">
                    معاون کا نام:
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: حاجی عبد الرحمٰن"
                    value={donorForm.name}
                    onChange={(e) => setDonorForm({ ...donorForm, name: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">ولدیت:</label>
                  <input
                    type="text"
                    placeholder="مثال: حاجی محمد یوسف"
                    value={donorForm.fatherName}
                    onChange={(e) =>
                      setDonorForm({ ...donorForm, fatherName: e.target.value })
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">
                    موبائل فون نمبر:
                  </label>
                  <input
                    type="tel"
                    dir="ltr"
                    required
                    placeholder="+92 300 1234567"
                    value={donorForm.phone}
                    onChange={(e) => setDonorForm({ ...donorForm, phone: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-sm text-left"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">زمرہ امداد:</label>
                  <select
                    value={donorForm.category}
                    onChange={(e) =>
                      setDonorForm({ ...donorForm, category: e.target.value as any })
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm bg-white"
                  >
                    <option value="ماہانہ">ماہانہ معاون</option>
                    <option value="سالانہ">سالانہ معاون</option>
                    <option value="زکوٰۃ">زکوٰۃ دہندہ</option>
                    <option value="صدقہ">صدقہ</option>
                    <option value="لِلّٰہ">لِلّٰہ فنڈ</option>
                    <option value="تعمیر">تعمیراتی معاون</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">
                    وعدہ شدہ رقم (روپے):
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={donorForm.promisedAmount}
                    onChange={(e) =>
                      setDonorForm({
                        ...donorForm,
                        promisedAmount: parseInt(e.target.value) || 0,
                      })
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono font-bold text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">تعدد:</label>
                  <select
                    value={donorForm.frequency}
                    onChange={(e) =>
                      setDonorForm({ ...donorForm, frequency: e.target.value as any })
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm bg-white"
                  >
                    <option value="ماہانہ">ماہانہ</option>
                    <option value="سالانہ">سالانہ</option>
                    <option value="یکمشتی">یکمشتی</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">پتہ / شہر:</label>
                <input
                  type="text"
                  placeholder="مثال: گلشن اقبال، کراچی"
                  value={donorForm.address}
                  onChange={(e) => setDonorForm({ ...donorForm, address: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
                />
              </div>

              <div className="flex items-center gap-3 pt-3 border-t border-slate-200">
                <button
                  type="submit"
                  className="flex-1 bg-amber-500 hover:bg-amber-600 text-emerald-950 font-black py-3 px-6 rounded-2xl shadow-md transition-all cursor-pointer"
                >
                  معاون محفوظ کریں
                </button>
                <button
                  type="button"
                  onClick={() => setIsDonorModalOpen(false)}
                  className="px-5 py-3 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-sm cursor-pointer"
                >
                  {t.cancel}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
