import React, { useState } from 'react';
import { Student, ExamRecord, UserRole, TeacherProfile } from '../types';
import { initialTeachers } from '../data/initialData';
import { Language, translations } from '../i18n/translations';
import { Award, Plus, Search, Printer, Share2, CheckCircle2, Trophy, Star, BookOpen } from 'lucide-react';

interface ExamsViewProps {
  students: Student[];
  exams: ExamRecord[];
  onAddExam: (newExam: Omit<ExamRecord, 'id'>) => void;
  onPrintResultCard: (exam: ExamRecord, student: Student) => void;
  lang: Language;
  currentRole: UserRole;
  activeTeacherName?: string;
  teachers?: TeacherProfile[];
  parentStudentMobile?: string;
}

export const ExamsView: React.FC<ExamsViewProps> = ({
  students,
  exams,
  onAddExam,
  onPrintResultCard,
  lang,
  currentRole,
  activeTeacherName = 'قاری عبد الوحید',
  teachers = initialTeachers,
  parentStudentMobile,
}) => {
  const t = translations[lang];
  const [searchTerm, setSearchTerm] = useState('');
  const [termFilter, setTermFilter] = useState<'All' | 'ShishMahi' | 'Salana' | 'Monthly'>('All');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // Available students for role
  const isParent = currentRole === 'parent';
  const isTeacher = currentRole === 'ustad';

  const availableStudents = isTeacher
    ? students.filter((s) => s.ustadName === activeTeacherName)
    : isParent && parentStudentMobile
    ? students.filter((s) => {
        const cleanDigits = parentStudentMobile.replace(/[^0-9]/g, '');
        const sDigits = s.parentMobile.replace(/[^0-9]/g, '');
        return sDigits.includes(cleanDigits) || cleanDigits.includes(sDigits);
      })
    : students;

  // Form State
  const [studentId, setStudentId] = useState(availableStudents[0]?.id || students[0]?.id || '');
  const [examTerm, setExamTerm] = useState<'ShishMahi' | 'Salana' | 'Monthly'>('ShishMahi');
  const [examNameUr, setExamNameUr] = useState('امتحان ششماہی حفظ و تجوید');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [hifzMarks, setHifzMarks] = useState(90);
  const [tajweedMarks, setTajweedMarks] = useState(45);
  const [nazraMarks, setNazraMarks] = useState(45);
  const [deeniyatMarks, setDeeniyatMarks] = useState(45);
  const [akhlaqMarks, setAkhlaqMarks] = useState(48);
  const [examinerUr, setExaminerUr] = useState(isTeacher ? activeTeacherName : 'قاری عبد الرشید صاحب');
  const [remarksUr, setRemarksUr] = useState('ماشاءاللہ بہت عمدہ یاد داشت اور حسنِ قرات۔');

  const visibleExams = exams.filter((exam) => {
    const student = students.find((s) => s.id === exam.studentId);
    if (!student) return false;

    if (isParent && parentStudentMobile) {
      const cleanDigits = parentStudentMobile.replace(/[^0-9]/g, '');
      const sDigits = student.parentMobile.replace(/[^0-9]/g, '');
      if (!sDigits.includes(cleanDigits) && !cleanDigits.includes(sDigits)) {
        return false;
      }
    }

    if (isTeacher) {
      if (student.ustadName !== activeTeacherName) {
        return false;
      }
    }

    const matchesSearch =
      student.nameUr.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.nameEn.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.rollNo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      exam.examNameUr.includes(searchTerm);

    const matchesTerm = termFilter === 'All' || exam.examTerm === termFilter;
    return matchesSearch && matchesTerm;
  });

  const calculateGrade = (pct: number): { grade: 'A+' | 'A' | 'B' | 'C' | 'D'; gradeUr: string } => {
    if (pct >= 90) return { grade: 'A+', gradeUr: 'ممتاز (A+)' };
    if (pct >= 80) return { grade: 'A', gradeUr: 'بہت خوب (A)' };
    if (pct >= 70) return { grade: 'B', gradeUr: 'خوب (B)' };
    if (pct >= 60) return { grade: 'C', gradeUr: 'مناسب (C)' };
    return { grade: 'D', gradeUr: 'قابل اصلاح (D)' };
  };

  const handleCreateExam = (e: React.FormEvent) => {
    e.preventDefault();
    const totalObtained = Number(hifzMarks) + Number(tajweedMarks) + Number(nazraMarks) + Number(deeniyatMarks) + Number(akhlaqMarks);
    const totalMax = 300;
    const percentage = Number(((totalObtained / totalMax) * 100).toFixed(1));
    const { grade, gradeUr } = calculateGrade(percentage);

    onAddExam({
      studentId,
      examTerm,
      examNameUr,
      examNameEn: examTerm === 'ShishMahi' ? 'Midterm Exam' : examTerm === 'Salana' ? 'Annual Exam' : 'Monthly Test',
      date,
      hifzMarks: Number(hifzMarks),
      tajweedMarks: Number(tajweedMarks),
      nazraMarks: Number(nazraMarks),
      deeniyatMarks: Number(deeniyatMarks),
      akhlaqMarks: Number(akhlaqMarks),
      totalObtained,
      totalMax,
      percentage,
      grade,
      gradeUr,
      examinerUr,
      remarksUr,
    });

    setIsAddModalOpen(false);
  };

  const handleWhatsAppShare = (exam: ExamRecord, student: Student) => {
    const text = `*مدرسہ قاسمیہ - رزلٹ کارڈ و سند مبارکباد* 🎓
محترم جناب ${student.fatherNameUr}!
السلام علیکم ورحمۃ اللہ،
آپ کے فرزند *${student.nameUr}* (رول نمبر: ${student.rollNo}) کے *${exam.examNameUr}* کے نتائج:
▫️ کل حاصل کردہ نمبر: *${exam.totalObtained} / ${exam.totalMax}*
▫️ فیصد: *${exam.percentage}%*
▫️ درجہ / گریڈ: *${exam.gradeUr}*
▫️ ممتحن کے ریمارکس: "${exam.remarksUr}"
اللہ پاک آپ کے فرزند کو علمِ نافع اور عامل بالقرآن بنائے۔ آمین!
جزاکم اللہ خیرا - دفتر امتحانات، مدرسہ قاسمیہ`;

    const cleanMobile = student.parentMobile.replace(/[^0-9]/g, '');
    const mobileWithCountry = cleanMobile.startsWith('0') ? `92${cleanMobile.slice(1)}` : cleanMobile;
    window.open(`https://wa.me/${mobileWithCountry}?text=${encodeURIComponent(text)}`, '_blank');
  };

  // Stats
  const avgPercentage = visibleExams.length
    ? (visibleExams.reduce((acc, curr) => acc + curr.percentage, 0) / visibleExams.length).toFixed(1)
    : '0';

  const aPlusCount = visibleExams.filter((e) => e.grade === 'A+').length;

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-linear-to-r from-[#0F5D2F] via-[#167039] to-[#0a4221] text-white p-6 rounded-3xl shadow-lg flex flex-wrap items-center justify-between gap-4 border border-emerald-500/30">
        <div>
          <div className="flex items-center gap-2 text-amber-300 font-bold text-sm">
            <Award className="w-5 h-5" />
            <span className="font-urdu">شعبہ امتحانات و تقسیم اسناد</span>
          </div>
          <h1 className="text-2xl font-black font-urdu mt-1">
            {lang === 'ur' ? 'امتحانات، نتائج و رزلٹ کارڈ' : 'Examinations & Result Cards'}
          </h1>
          <p className="text-emerald-100 text-xs font-urdu max-w-xl mt-1">
            {lang === 'ur'
              ? 'ششماہی و سالانہ امتحانات کے نمبرات، حفظ و تجوید کا جائزہ، باضابطہ رزلٹ کارڈ پرنٹ اور سرپرست کو واٹس ایپ ترسیل۔'
              : 'Midterm and annual examination records, Tajweed evaluation, official printable certificates & WhatsApp sharing.'}
          </p>
        </div>

        {/* Add Exam Button (Admin / Ustad) */}
        {!isParent && (
          <button
            onClick={() => setIsAddModalOpen(true)}
            className="flex items-center gap-2 bg-amber-400 hover:bg-amber-500 text-emerald-950 font-black px-5 py-3 rounded-2xl shadow-md transition-all active:scale-95 cursor-pointer text-sm font-urdu"
          >
            <Plus className="w-5 h-5" />
            <span>{lang === 'ur' ? 'نیا رزلٹ درج کریں' : 'Add New Result'}</span>
          </button>
        )}
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs text-right">
          <span className="text-xs text-slate-500 font-urdu block">کل امتحانی ریکارڈ</span>
          <span className="text-2xl font-black text-emerald-900 font-mono">{visibleExams.length}</span>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs text-right">
          <span className="text-xs text-slate-500 font-urdu block">اوسط حاصل کردہ فیصد</span>
          <span className="text-2xl font-black text-amber-600 font-mono">{avgPercentage}%</span>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs text-right">
          <span className="text-xs text-slate-500 font-urdu block">ممتاز (A+) درجے کے طلبہ</span>
          <span className="text-2xl font-black text-emerald-600 font-mono">{aPlusCount}</span>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs text-right">
          <span className="text-xs text-slate-500 font-urdu block">کامیابی کا تناسب</span>
          <span className="text-2xl font-black text-blue-600 font-mono">100%</span>
        </div>
      </div>

      {/* Filters Bar (Only if not parent) */}
      {!isParent && (
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3">
          <div className="flex-1 min-w-[240px] relative">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-3" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="طالب علم کا نام، رول نمبر یا امتحان سے تلاش کریں..."
              className="w-full pr-9 pl-4 py-2 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-600 font-urdu"
            />
          </div>

          <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl text-xs font-urdu">
            {(['All', 'ShishMahi', 'Salana', 'Monthly'] as const).map((term) => (
              <button
                key={term}
                onClick={() => setTermFilter(term)}
                className={`px-3 py-1.5 rounded-lg transition-all font-bold cursor-pointer ${
                  termFilter === term
                    ? 'bg-white text-emerald-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {term === 'All' && 'تمام امتحانات'}
                {term === 'ShishMahi' && 'ششماہی'}
                {term === 'Salana' && 'سالانہ'}
                {term === 'Monthly' && 'ماہانہ'}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Exams Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {visibleExams.map((exam) => {
          const student = students.find((s) => s.id === exam.studentId);
          if (!student) return null;

          return (
            <div
              key={exam.id}
              className="bg-white rounded-3xl border-2 border-emerald-600/20 p-5 shadow-sm hover:shadow-md transition-all flex flex-col justify-between gap-4 relative overflow-hidden"
            >
              {/* Decorative Corner Badge */}
              <div className="absolute top-0 left-0 bg-emerald-700 text-amber-300 px-4 py-1 rounded-br-2xl text-xs font-black font-urdu flex items-center gap-1">
                <Trophy className="w-3.5 h-3.5" />
                <span>{exam.gradeUr}</span>
              </div>

              <div>
                <div className="flex items-start justify-between gap-2 pr-1 pt-1">
                  <div>
                    <span className="text-[11px] text-slate-500 font-mono block">
                      رول نمبر: {student.rollNo} • درجہ: {student.class}
                    </span>
                    <h3 className="text-xl font-black text-emerald-950 font-urdu mt-0.5">
                      {student.nameUr}
                    </h3>
                    <p className="text-xs text-slate-600 font-urdu">ولدیت: {student.fatherNameUr}</p>
                  </div>
                  <div className="text-left font-mono">
                    <span className="text-2xl font-black text-emerald-800 block">
                      {exam.percentage}%
                    </span>
                    <span className="text-[10px] text-slate-500">
                      {exam.totalObtained}/{exam.totalMax}
                    </span>
                  </div>
                </div>

                {/* Exam Title & Date */}
                <div className="mt-3 p-2.5 rounded-xl bg-emerald-50/70 border border-emerald-200 text-xs font-urdu flex items-center justify-between">
                  <span className="font-bold text-emerald-900">{exam.examNameUr}</span>
                  <span className="text-slate-500 font-mono">{exam.date}</span>
                </div>

                {/* Subject Marks Breakdown */}
                <div className="grid grid-cols-5 gap-1 text-center mt-3 pt-2 border-t border-slate-100 font-urdu text-[11px]">
                  <div className="bg-slate-50 p-1.5 rounded-lg">
                    <span className="text-slate-500 block text-[10px]">حفظ/قرآن</span>
                    <span className="font-bold font-mono text-emerald-900">{exam.hifzMarks}/100</span>
                  </div>
                  <div className="bg-slate-50 p-1.5 rounded-lg">
                    <span className="text-slate-500 block text-[10px]">تجوید</span>
                    <span className="font-bold font-mono text-emerald-900">{exam.tajweedMarks}/50</span>
                  </div>
                  <div className="bg-slate-50 p-1.5 rounded-lg">
                    <span className="text-slate-500 block text-[10px]">ناظرہ</span>
                    <span className="font-bold font-mono text-emerald-900">{exam.nazraMarks}/50</span>
                  </div>
                  <div className="bg-slate-50 p-1.5 rounded-lg">
                    <span className="text-slate-500 block text-[10px]">دینیات</span>
                    <span className="font-bold font-mono text-emerald-900">{exam.deeniyatMarks}/50</span>
                  </div>
                  <div className="bg-slate-50 p-1.5 rounded-lg">
                    <span className="text-slate-500 block text-[10px]">اخلاق</span>
                    <span className="font-bold font-mono text-emerald-900">{exam.akhlaqMarks}/50</span>
                  </div>
                </div>

                {/* Examiner Remarks */}
                <div className="mt-3 text-xs text-slate-700 bg-amber-50/60 p-2.5 rounded-xl border border-amber-200/80 font-urdu">
                  <span className="font-bold text-amber-900 block mb-0.5">
                    ریمارکس ممتحن ({exam.examinerUr}):
                  </span>
                  <p className="italic">"{exam.remarksUr}"</p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 pt-2 border-t border-slate-100 font-urdu text-xs">
                <button
                  onClick={() => onPrintResultCard(exam, student)}
                  className="flex-1 flex items-center justify-center gap-1.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-2 px-3 rounded-xl transition-colors cursor-pointer shadow-2xs"
                >
                  <Printer className="w-3.5 h-3.5 text-amber-300" />
                  <span>رزلٹ کارڈ پرنٹ کریں 🖨️</span>
                </button>

                <button
                  onClick={() => handleWhatsAppShare(exam, student)}
                  className="flex items-center gap-1.5 bg-emerald-100 hover:bg-emerald-200 text-emerald-900 font-bold py-2 px-3 rounded-xl transition-colors cursor-pointer"
                  title="والدین کو واٹس ایپ مبارکباد بھیجیں"
                >
                  <Share2 className="w-3.5 h-3.5 text-emerald-700" />
                  <span>واٹس ایپ 💬</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {visibleExams.length === 0 && (
        <div className="p-12 text-center bg-white rounded-3xl border border-dashed border-slate-300">
          <BookOpen className="w-12 h-12 text-slate-300 mx-auto mb-2" />
          <h3 className="font-bold text-base text-slate-700 font-urdu">کوئی امتحانی ریکارڈ موجود نہیں ہے</h3>
          <p className="text-xs text-slate-500 font-urdu mt-1">امتحان کے نتائج درج کرنے کے لیے اوپر "نیا رزلٹ درج کریں" کے بٹن پر کلک کریں۔</p>
        </div>
      )}

      {/* Add Exam Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl shadow-2xl border-2 border-emerald-600/30 w-full max-w-xl overflow-hidden animate-in fade-in duration-200 my-auto">
            <div className="bg-[#0F5D2F] text-white p-4 flex items-center justify-between border-b-4 border-amber-500 font-urdu">
              <div className="flex items-center gap-2">
                <Award className="w-6 h-6 text-amber-300" />
                <h3 className="font-bold text-lg">امتحانی نتیجہ اور رزلٹ کارڈ اندراج</h3>
              </div>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="text-white/80 hover:text-white text-xl font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateExam} className="p-5 space-y-4 font-urdu text-sm">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">طالب علم منتخب کریں:</label>
                  <select
                    value={studentId}
                    onChange={(e) => setStudentId(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                    required
                  >
                    {availableStudents.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.nameUr} (رول #{s.rollNo} - {s.class})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">امتحان کی قسم:</label>
                  <select
                    value={examTerm}
                    onChange={(e) => {
                      const val = e.target.value as any;
                      setExamTerm(val);
                      if (val === 'ShishMahi') setExamNameUr('امتحان ششماہی حفظ و تجوید');
                      else if (val === 'Salana') setExamNameUr('امتحان سالانہ و تکمیل حفظ');
                      else setExamNameUr('ماہانہ ٹیسٹ');
                    }}
                    className="w-full p-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  >
                    <option value="ShishMahi">امتحان ششماہی (Midterm)</option>
                    <option value="Salana">امتحان سالانہ (Annual)</option>
                    <option value="Monthly">ماہانہ جائزہ ٹیسٹ</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">امتحان کا عنوان:</label>
                  <input
                    type="text"
                    value={examNameUr}
                    onChange={(e) => setExamNameUr(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">تاریخ امتحان:</label>
                  <input
                    type="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-600 font-mono"
                    required
                  />
                </div>
              </div>

              {/* Marks Entry */}
              <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-200">
                <span className="font-bold text-xs text-emerald-900 block mb-2">مضامین کے حاصل کردہ نمبرات:</span>
                <div className="grid grid-cols-5 gap-2">
                  <div>
                    <label className="text-[10px] text-slate-600 block">حفظ (100)</label>
                    <input
                      type="number"
                      min={0}
                      max={100}
                      value={hifzMarks}
                      onChange={(e) => setHifzMarks(Number(e.target.value))}
                      className="w-full p-2 text-center font-mono font-bold bg-white rounded-lg border border-slate-300"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-600 block">تجوید (50)</label>
                    <input
                      type="number"
                      min={0}
                      max={50}
                      value={tajweedMarks}
                      onChange={(e) => setTajweedMarks(Number(e.target.value))}
                      className="w-full p-2 text-center font-mono font-bold bg-white rounded-lg border border-slate-300"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-600 block">ناظرہ (50)</label>
                    <input
                      type="number"
                      min={0}
                      max={50}
                      value={nazraMarks}
                      onChange={(e) => setNazraMarks(Number(e.target.value))}
                      className="w-full p-2 text-center font-mono font-bold bg-white rounded-lg border border-slate-300"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-600 block">دینیات (50)</label>
                    <input
                      type="number"
                      min={0}
                      max={50}
                      value={deeniyatMarks}
                      onChange={(e) => setDeeniyatMarks(Number(e.target.value))}
                      className="w-full p-2 text-center font-mono font-bold bg-white rounded-lg border border-slate-300"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-600 block">اخلاق (50)</label>
                    <input
                      type="number"
                      min={0}
                      max={50}
                      value={akhlaqMarks}
                      onChange={(e) => setAkhlaqMarks(Number(e.target.value))}
                      className="w-full p-2 text-center font-mono font-bold bg-white rounded-lg border border-slate-300"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">ممتحن کا نام:</label>
                  <input
                    type="text"
                    value={examinerUr}
                    onChange={(e) => setExaminerUr(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-300"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">ممتحن کے ریمارکس:</label>
                  <input
                    type="text"
                    value={remarksUr}
                    onChange={(e) => setRemarksUr(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-300"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 bg-emerald-700 hover:bg-emerald-800 text-white font-black py-3 rounded-2xl shadow-md cursor-pointer transition-all"
                >
                  نتیجہ محفوظ کریں اور رزلٹ کارڈ تیار کریں 🎓
                </button>
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-2xl cursor-pointer"
                >
                  منسوخ
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
