import React, { useState } from 'react';
import { Student, AttendanceRecord, HifzDiaryEntry, FeePayment, DonationRecord, SystemSettings } from '../types';
import { Language, translations } from '../i18n/translations';
import { MessageSquare, Send, Copy, Check, X, Phone, UserCheck, HeartHandshake, AlertTriangle, BookOpen, Receipt } from 'lucide-react';

interface WhatsAppCenterModalProps {
  isOpen: boolean;
  onClose: () => void;
  students: Student[];
  attendance: AttendanceRecord[];
  hifzDiary: HifzDiaryEntry[];
  feePayments: FeePayment[];
  donations: DonationRecord[];
  settings: SystemSettings;
  lang: Language;
}

export const WhatsAppCenterModal: React.FC<WhatsAppCenterModalProps> = ({
  isOpen,
  onClose,
  students,
  attendance,
  hifzDiary,
  feePayments,
  donations,
  settings,
  lang,
}) => {
  if (!isOpen) return null;

  const t = translations[lang];
  const [templateType, setTemplateType] = useState<'absent' | 'sabaq' | 'fee' | 'donation' | 'general'>('absent');
  const [selectedStudentId, setSelectedStudentId] = useState(students[0]?.id || '');
  const [customPhone, setCustomPhone] = useState('');
  const [customMsg, setCustomMsg] = useState('');
  const [copied, setCopied] = useState(false);

  const selectedStudent = students.find((s) => s.id === selectedStudentId) || students[0];

  // Latest Sabaq for selected student
  const latestSabaq = hifzDiary.find((h) => h.studentId === selectedStudent?.id);

  // Latest fee payment for selected student
  const latestFee = feePayments.find((f) => f.studentId === selectedStudent?.id);

  // Latest donation
  const latestDonation = donations[0];

  const todayStr = new Date().toISOString().split('T')[0];

  const generateMessage = (): { text: string; phone: string } => {
    if (!selectedStudent) return { text: '', phone: '' };

    const studentPhone = selectedStudent.parentMobile.replace(/[^0-9]/g, '');

    switch (templateType) {
      case 'absent': {
        const text = `*اطلاعِ غیر حاضری - ${settings.madrasaNameUr}* ⚠️
━━━━━━━━━━━━━━━━━━━━
محترم جناب *${selectedStudent.fatherNameUr}* صاحب!
السلام علیکم ورحمۃ اللہ وبرکاتہ،

مطلع کیا جاتا ہے کہ آپ کا فرزند *${selectedStudent.nameUr}* (رول نمبر: ${selectedStudent.rollNo}، درجہ: ${selectedStudent.class}) آج بتاریخ *${todayStr}* مدرسہ سے بغیر پیشگی اطلاع کے *غیر حاضر* رہا ہے۔

براہِ کرم غیر حاضری کی وجہ سے مطلع فرمائیں تاکہ طالب علم کا تعلیمی حرج نہ ہو۔

جزاکم اللہ خیرا،
*انتظامیہ ${settings.madrasaNameUr}*
رابطہ: ${settings.phone}`;
        return { text, phone: studentPhone };
      }

      case 'sabaq': {
        const para = latestSabaq ? latestSabaq.sabaqPara : (selectedStudent.completedParas || 1);
        const sabqi = latestSabaq ? latestSabaq.sabqi : 'پارہ نمبر ' + para;
        const manzil = latestSabaq ? latestSabaq.manzil : 'آدھا پارہ';
        const grade = latestSabaq ? latestSabaq.grade : 'A+';
        const remarks = latestSabaq ? latestSabaq.teacherRemarks : 'ماشاءاللہ بہت عمدہ سنایا۔';

        const text = `*روزانہ قرآنی سبق و حفظ رپورٹ - ${settings.madrasaNameUr}* 📖
━━━━━━━━━━━━━━━━━━━━
محترم والدین! السلام علیکم ورحمۃ اللہ،
طالب علم: *${selectedStudent.nameUr}* (رول نمبر: ${selectedStudent.rollNo})
تاریخ: ${todayStr}

▫️ نیا سبق: پارہ نمبر *${para}* (${latestSabaq?.sabaqLinesOrPages || '1 صفحہ'})
▫️ سبقی: *${sabqi}*
▫️ منزل: *${manzil}*
▫️ کارکردگی گریڈ: *${grade}*
▫️ استاد کے ریمارکس: "${remarks}"

گھر پر بھی طالب علم کو دہرائی کی تلقین فرمائیں۔
دعاؤں کا طالب: *استادِ محترم، شعبہ تحفیظ القرآن*`;
        return { text, phone: studentPhone };
      }

      case 'fee': {
        const amount = latestFee ? latestFee.totalPaid : selectedStudent.monthlyFee;
        const receipt = latestFee ? latestFee.receiptNo : 'MQ-REC-AUTO';
        const month = latestFee ? latestFee.month : 'رواں ماہ';

        const text = `*فیس وصولی رسید - ${settings.madrasaNameUr}* 💰
━━━━━━━━━━━━━━━━━━━━
محترم جناب *${selectedStudent.fatherNameUr}*!
السلام علیکم ورحمۃ اللہ،

طالب علم *${selectedStudent.nameUr}* (رول نمبر: ${selectedStudent.rollNo}) کی ماہانہ فیس برائے *${month}* مبلغ *${amount} روپے* موصول پا کر باضابطہ رسید نمبر *${receipt}* جاری کر دی گئی ہے۔

مدرسہ کے تعلیمی نظام کے ساتھ تعاون پر ہم آپ کے تہہ دل سے شکر گزار ہیں۔

والسلام،
*دفتر حسابات، ${settings.madrasaNameUr}*`;
        return { text, phone: studentPhone };
      }

      case 'donation': {
        const donorName = latestDonation ? latestDonation.donorName : 'محترم مخیر حضرات';
        const donAmount = latestDonation ? latestDonation.amount : 5000;
        const cat = latestDonation ? latestDonation.category : 'Lillah';
        const vNo = latestDonation ? latestDonation.voucherNo : 'VCH-01';

        const text = `*رسید عطیہ و چندہ مع دعائیہ پیغام* 🕌
━━━━━━━━━━━━━━━━━━━━
محترم و مکرم *${donorName}* صاحب!
السلام علیکم ورحمۃ اللہ وبرکاتہ،

${settings.madrasaNameUr} کے دینی و تعلیمی شعبہ جات کے لیے آپ کا عطیہ مبلغ *${donAmount} روپے* بحساب *${cat}* موصول پا چکا ہے۔ رسید نمبر: *${vNo}*۔

*دعائے خیر:*
اللہ تبارک و تعالیٰ آپ کے اس پاکیزہ عطیہ کو اپنی بارگاہ میں شرفِ قبولیت عطا فرمائے، آپ کے مال و جان، اہل خانہ اور رزق و روزگار میں بے پناہ برکتیں نازل فرمائے اور اسے صدقہ جاریہ بنائے۔ آمین یا رب العالمین!

خادمِ مدرسہ: *مہتمم ${settings.madrasaNameUr}*`;
        return { text, phone: latestDonation?.donorPhone.replace(/[^0-9]/g, '') || '' };
      }

      case 'general': {
        const text = `*پیغام از ${settings.madrasaNameUr}* 📢
━━━━━━━━━━━━━━━━━━━━
محترم سرپرست / وابستگانِ مدرسہ!
السلام علیکم ورحمۃ اللہ،

${customMsg || 'اطلاع دی جاتی ہے کہ مدرسہ میں آئندہ ہفتہ خصوصی جائزہ نشست منعقد ہوگی۔'}

جزاکم اللہ خیرا،
*انتظامیہ ${settings.madrasaNameUr}*
رابطہ: ${settings.phone}`;
        return { text, phone: customPhone.replace(/[^0-9]/g, '') || studentPhone };
      }
    }
  };

  const { text: generatedText, phone: targetPhone } = generateMessage();

  const handleSendWhatsApp = () => {
    let cleanPhone = (customPhone || targetPhone).replace(/[^0-9]/g, '');
    if (cleanPhone.startsWith('0')) {
      cleanPhone = '92' + cleanPhone.slice(1);
    }
    const url = cleanPhone
      ? `https://wa.me/${cleanPhone}?text=${encodeURIComponent(generatedText)}`
      : `https://wa.me/?text=${encodeURIComponent(generatedText)}`;
    window.open(url, '_blank');
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(generatedText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl shadow-2xl border-2 border-emerald-600/30 w-full max-w-2xl overflow-hidden animate-in fade-in duration-200 my-auto font-urdu">
        {/* Header */}
        <div className="bg-[#0F5D2F] text-white p-4 flex items-center justify-between border-b-4 border-amber-500">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-emerald-700/80 flex items-center justify-center text-xl text-amber-300">
              💬
            </div>
            <div>
              <h3 className="font-bold text-lg leading-tight">مرکزی واٹس ایپ الرٹس و میسجنگ سینٹر</h3>
              <p className="text-xs text-emerald-200">والدین اور مخیرین کو خودکار اردو پیغامات و رسیدیں بھیجیں</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 sm:p-6 space-y-4">
          {/* Template Switcher */}
          <div>
            <label className="block text-xs font-bold text-slate-600 mb-1.5">پیغام کی قسم منتخب کریں:</label>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-1.5 text-xs">
              <button
                type="button"
                onClick={() => setTemplateType('absent')}
                className={`p-2 rounded-xl font-bold flex flex-col items-center gap-1 cursor-pointer transition-all border ${
                  templateType === 'absent'
                    ? 'bg-rose-50 border-rose-400 text-rose-900 ring-2 ring-rose-300/40'
                    : 'bg-slate-50 border-slate-200 hover:bg-slate-100 text-slate-700'
                }`}
              >
                <AlertTriangle className="w-4 h-4 text-rose-600" />
                <span>غیر حاضری الرٹ</span>
              </button>

              <button
                type="button"
                onClick={() => setTemplateType('sabaq')}
                className={`p-2 rounded-xl font-bold flex flex-col items-center gap-1 cursor-pointer transition-all border ${
                  templateType === 'sabaq'
                    ? 'bg-emerald-50 border-emerald-500 text-emerald-950 ring-2 ring-emerald-300/40'
                    : 'bg-slate-50 border-slate-200 hover:bg-slate-100 text-slate-700'
                }`}
              >
                <BookOpen className="w-4 h-4 text-emerald-700" />
                <span>سبق ڈائری</span>
              </button>

              <button
                type="button"
                onClick={() => setTemplateType('fee')}
                className={`p-2 rounded-xl font-bold flex flex-col items-center gap-1 cursor-pointer transition-all border ${
                  templateType === 'fee'
                    ? 'bg-amber-50 border-amber-500 text-amber-950 ring-2 ring-amber-300/40'
                    : 'bg-slate-50 border-slate-200 hover:bg-slate-100 text-slate-700'
                }`}
              >
                <Receipt className="w-4 h-4 text-amber-700" />
                <span>فیس رسید</span>
              </button>

              <button
                type="button"
                onClick={() => setTemplateType('donation')}
                className={`p-2 rounded-xl font-bold flex flex-col items-center gap-1 cursor-pointer transition-all border ${
                  templateType === 'donation'
                    ? 'bg-blue-50 border-blue-500 text-blue-950 ring-2 ring-blue-300/40'
                    : 'bg-slate-50 border-slate-200 hover:bg-slate-100 text-slate-700'
                }`}
              >
                <HeartHandshake className="w-4 h-4 text-blue-700" />
                <span>چندہ رسید مع دعا</span>
              </button>

              <button
                type="button"
                onClick={() => setTemplateType('general')}
                className={`p-2 rounded-xl font-bold flex flex-col items-center gap-1 cursor-pointer transition-all border ${
                  templateType === 'general'
                    ? 'bg-purple-50 border-purple-500 text-purple-950 ring-2 ring-purple-300/40'
                    : 'bg-slate-50 border-slate-200 hover:bg-slate-100 text-slate-700'
                }`}
              >
                <MessageSquare className="w-4 h-4 text-purple-700" />
                <span>عمومی پیغام</span>
              </button>
            </div>
          </div>

          {/* Student Selector (If applicable) */}
          {templateType !== 'donation' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-slate-50 p-3 rounded-2xl border border-slate-200">
              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">طالب علم منتخب کریں:</label>
                <select
                  value={selectedStudentId}
                  onChange={(e) => setSelectedStudentId(e.target.value)}
                  className="w-full p-2 text-xs rounded-xl border border-slate-300 bg-white font-urdu"
                >
                  {students.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.nameUr} (ولدیت: {s.fatherNameUr} - {s.parentMobile})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">واٹس ایپ نمبر (خودکار یا تبدیل کریں):</label>
                <input
                  type="tel"
                  value={customPhone || selectedStudent?.parentMobile || ''}
                  onChange={(e) => setCustomPhone(e.target.value)}
                  placeholder="مثال: 03001234567"
                  className="w-full p-2 text-xs rounded-xl border border-slate-300 bg-white font-mono"
                />
              </div>
            </div>
          )}

          {templateType === 'general' && (
            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">اپنا پیغام لکھیں:</label>
              <textarea
                rows={2}
                value={customMsg}
                onChange={(e) => setCustomMsg(e.target.value)}
                placeholder="یہاں اپنا پیغام درج کریں..."
                className="w-full p-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-600"
              />
            </div>
          )}

          {/* Live Preview Box */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-bold text-slate-600">پیغام کا پیشگی منظر (Live Preview):</span>
              <button
                type="button"
                onClick={handleCopy}
                className="text-[11px] text-emerald-800 hover:text-emerald-950 flex items-center gap-1 font-bold cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'کاپی ہو گیا!' : 'متن کاپی کریں'}</span>
              </button>
            </div>
            <pre className="p-3 bg-emerald-50/70 border border-emerald-300/80 rounded-2xl text-xs text-emerald-950 font-urdu whitespace-pre-wrap leading-relaxed max-h-48 overflow-y-auto">
              {generatedText}
            </pre>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2 pt-2">
            <button
              type="button"
              onClick={handleSendWhatsApp}
              className="flex-1 bg-[#25D366] hover:bg-[#1EBE5D] text-slate-950 font-black py-3 px-4 rounded-2xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer text-sm"
            >
              <Send className="w-4 h-4" />
              <span>براہِ راست واٹس ایپ پر بھیجیں 💬</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-2xl cursor-pointer text-xs"
            >
              بند کریں
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
