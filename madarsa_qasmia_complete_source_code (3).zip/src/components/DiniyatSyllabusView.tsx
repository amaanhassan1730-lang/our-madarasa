import React, { useState, useMemo } from 'react';
import { Student, UserRole, DiniyatTopic } from '../types';
import { Language, translations } from '../i18n/translations';
import { diniyatSyllabus } from '../data/initialData';
import {
  BookOpen,
  CheckCircle2,
  Calendar,
  Send,
  Printer,
  Sparkles,
  User,
  GraduationCap,
  Award,
  ChevronLeft,
  Search,
} from 'lucide-react';

type DiniyatStatus = 'بہترین' | 'بہتر' | 'مناسب' | 'زیرِ تدریس';

interface WeekProgress {
  status: DiniyatStatus;
  remarks: string;
}

interface DiniyatSyllabusViewProps {
  students: Student[];
  lang: Language;
  currentRole: UserRole;
  activeTeacherName?: string;
  parentStudentMobile?: string;
  onNavigateTab: (tab: string) => void;
}

export const DiniyatSyllabusView: React.FC<DiniyatSyllabusViewProps> = ({
  students,
  lang,
  currentRole,
  activeTeacherName = 'قاری عبد الوحید',
  parentStudentMobile,
  onNavigateTab,
}) => {
  const t = translations[lang];

  // Role filtering
  const visibleStudents = useMemo(() => {
    let list = students;
    if (currentRole === 'parent' && parentStudentMobile) {
      const clean = parentStudentMobile.replace(/[^0-9]/g, '');
      list = list.filter((s) => s.parentMobile.replace(/[^0-9]/g, '').includes(clean));
    } else if (currentRole === 'ustad' && activeTeacherName) {
      list = list.filter((s) => s.ustadName === activeTeacherName);
    }
    return list;
  }, [students, currentRole, parentStudentMobile, activeTeacherName]);

  const [selectedStudentId, setSelectedStudentId] = useState<string>(
    visibleStudents[0]?.id || ''
  );
  const [activeWeekFilter, setActiveWeekFilter] = useState<'all' | 'pending' | 'completed'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Persistent / in-memory student progress per week
  const [studentProgressMap, setStudentProgressMap] = useState<
    Record<string, Record<number, WeekProgress>>
  >({
    'std-1': {
      1: { status: 'بہترین', remarks: 'کامل تلفظ اور ترجمہ کے ساتھ یاد ہے' },
      2: { status: 'بہترین', remarks: 'ماشاءاللہ بہت عمدہ' },
      3: { status: 'بہتر', remarks: 'طہارت کے بنیادی مسائل معلوم ہیں' },
      4: { status: 'بہترین', remarks: 'وضو عملی طور پر درست کر کے دکھایا' },
      5: { status: 'بہتر', remarks: 'فرائض غسل یاد ہیں' },
    },
    'std-2': {
      1: { status: 'بہترین', remarks: 'ماشاءاللہ' },
      2: { status: 'بہتر', remarks: 'ایمان مفصل یاد کیا' },
      3: { status: 'مناسب', remarks: 'مزید دہرائی درکار ہے' },
    },
    'std-6': {
      1: { status: 'بہترین', remarks: 'پہلا کلمہ درست تلفظ سے یاد ہے' },
      2: { status: 'بہترین', remarks: 'بہترین انداز میں سنایا' },
    }
  });

  const selectedStudent = useMemo(() => {
    return students.find((s) => s.id === selectedStudentId) || visibleStudents[0];
  }, [students, selectedStudentId, visibleStudents]);

  // Current student week records
  const currentStudentRecords: Record<number, WeekProgress> = useMemo(() => {
    if (!selectedStudent) return {};
    return studentProgressMap[selectedStudent.id] || {};
  }, [studentProgressMap, selectedStudent]);

  // Calculate stats for current student
  const progressStats = useMemo(() => {
    const totalWeeks = 12;
    let completedCount = 0;
    let excellentCount = 0;

    (Object.values(currentStudentRecords) as WeekProgress[]).forEach((rec) => {
      if (rec.status === 'بہترین' || rec.status === 'بہتر') {
        completedCount++;
      }
      if (rec.status === 'بہترین') {
        excellentCount++;
      }
    });

    const percent = Math.round((completedCount / totalWeeks) * 100);
    return { totalWeeks, completedCount, excellentCount, percent };
  }, [currentStudentRecords]);

  // Update status for a specific week
  const handleUpdateWeekStatus = (weekNum: number, status: 'بہترین' | 'بہتر' | 'مناسب' | 'زیرِ تدریس') => {
    if (!selectedStudent) return;
    setStudentProgressMap((prev) => {
      const studentMap = { ...(prev[selectedStudent.id] || {}) };
      studentMap[weekNum] = {
        status,
        remarks: studentMap[weekNum]?.remarks || (status === 'بہترین' ? 'ماشاءاللہ مکمل اور پختہ' : 'زیرِ تدریس'),
      };
      return {
        ...prev,
        [selectedStudent.id]: studentMap,
      };
    });
  };

  // Filtered syllabus topics
  const filteredTopics = useMemo(() => {
    return diniyatSyllabus.filter((topic) => {
      const rec = currentStudentRecords[topic.week];
      const isDone = rec && (rec.status === 'بہترین' || rec.status === 'بہتر');

      if (activeWeekFilter === 'completed' && !isDone) return false;
      if (activeWeekFilter === 'pending' && isDone) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          topic.titleUr.toLowerCase().includes(q) ||
          topic.descriptionUr.toLowerCase().includes(q) ||
          topic.arabic.toLowerCase().includes(q) ||
          `ہفتہ ${topic.week}`.includes(q)
        );
      }
      return true;
    });
  }, [diniyatSyllabus, currentStudentRecords, activeWeekFilter, searchQuery]);

  // Send WhatsApp Progress Report
  const handleSendWhatsAppReport = () => {
    if (!selectedStudent) return;
    const text = `السلام علیکم ورحمۃ اللہ وبرکاتہ!
محترم سرپرستِ *${selectedStudent.nameUr}* (رول نمبر: ${selectedStudent.rollNo})
مدرسہ قاسمیہ کے *۱۲ ہفتوں کے دینیات و اسلامی اخلاقیات نصاب* کی ماہانہ رپورٹ:

🌟 *مجموعی پیشرفت:* ${progressStats.completedCount} / 12 اسباق مکمل (${progressStats.percent}%)
🎖️ *اعلیٰ معیار (بہترین):* ${progressStats.excellentCount} اسباق

کامیابی کے ساتھ سیکھے گئے ابواب:
${(Object.entries(currentStudentRecords) as [string, WeekProgress][])
  .map(([wk, rec]) => `• ہفتہ ${wk}: ${rec.status} (${rec.remarks})`)
  .join('\n')}

_ادارہ مدرسہ قاسمیہ، جامع مسجد و تعلیم القرآن_`;

    const cleanPhone = selectedStudent.parentMobile.replace(/[^0-9]/g, '');
    const url = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  // Print syllabus
  const handlePrintSyllabus = () => {
    window.print();
  };

  return (
    <div className="space-y-6 font-urdu pb-12" dir="rtl">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-teal-900 via-emerald-800 to-[#0F5D2F] rounded-3xl p-6 sm:p-8 text-white shadow-lg border-2 border-emerald-600 relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 bg-amber-400 text-emerald-950 px-3.5 py-1 rounded-full text-xs font-black tracking-wide shadow-xs font-sans">
              <Sparkles className="w-3.5 h-3.5" />
              <span>12-WEEK DINIYAT & ISLAMIC ETHICS SYLLABUS</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
              دینیات و اسلامی اخلاقیات کا ۱۲ ہفتوں کا جامع نصاب
            </h2>
            <p className="text-emerald-100 text-sm max-w-2xl leading-relaxed opacity-95">
              عقائد، ایمانیات، طہارت، وضو و غسل، نماز کے ارکان و شرائط، مسنون دعائیں، احادیث نبویہ اور اسلامی آداب کا باقاعدہ ہفتہ وار تربیتی خاکہ مع انفرادی طالب علم ایویلیوایشن۔
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={handleSendWhatsAppReport}
              className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2.5 px-4 rounded-2xl shadow-md transition-all cursor-pointer text-xs"
            >
              <Send className="w-4 h-4" />
              <span>واٹس ایپ رپورٹ 📲</span>
            </button>
            <button
              onClick={handlePrintSyllabus}
              className="flex items-center gap-2 bg-white/10 hover:bg-white/20 text-white font-bold py-2.5 px-4 rounded-2xl border border-white/20 transition-all cursor-pointer text-xs"
            >
              <Printer className="w-4 h-4 text-amber-300" />
              <span>پرنٹ نصاب 🖨️</span>
            </button>
          </div>
        </div>
      </div>

      {/* Student Selection & Overall Progress Meter */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-3">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <User className="w-4 h-4 text-emerald-700" />
              <span>طالب علم کا انتخاب برائے دینیات جانچ:</span>
            </label>
            <select
              value={selectedStudentId}
              onChange={(e) => setSelectedStudentId(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs font-bold font-urdu focus:ring-2 focus:ring-emerald-600 outline-none"
            >
              {visibleStudents.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.nameUr} ({s.rollNo} - {s.class})
                </option>
              ))}
            </select>
          </div>

          {/* Search Box */}
          <div className="relative w-full md:w-64">
            <Search className="w-4 h-4 absolute right-3.5 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="سبق، عنوان یا کلمہ تلاش کریں..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pr-10 pl-4 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-emerald-600 outline-none"
            />
          </div>
        </div>

        {/* Progress Bar for selected student */}
        {selectedStudent && (
          <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-emerald-950 flex items-center gap-1.5">
                <GraduationCap className="w-4 h-4 text-emerald-700" />
                <span>{selectedStudent.nameUr} کی دینیات تکمیل:</span>
              </span>
              <span className="font-mono font-bold text-emerald-900 bg-white px-2 py-0.5 rounded-md shadow-2xs">
                {progressStats.completedCount} / 12 اسباق ({progressStats.percent}%)
              </span>
            </div>
            <div className="w-full bg-emerald-200/70 h-3 rounded-full overflow-hidden">
              <div
                className="bg-emerald-600 h-full rounded-full transition-all duration-500"
                style={{ width: `${progressStats.percent}%` }}
              />
            </div>
          </div>
        )}

        {/* Filters Switcher */}
        <div className="flex items-center gap-2 pt-1 text-xs">
          <span className="font-bold text-slate-500">فلٹر:</span>
          <button
            onClick={() => setActiveWeekFilter('all')}
            className={`px-3 py-1 rounded-xl font-bold cursor-pointer transition-colors ${
              activeWeekFilter === 'all' ? 'bg-emerald-800 text-white shadow-xs' : 'bg-slate-100 text-slate-600'
            }`}
          >
            تمام ۱۲ اسباق
          </button>
          <button
            onClick={() => setActiveWeekFilter('completed')}
            className={`px-3 py-1 rounded-xl font-bold cursor-pointer transition-colors ${
              activeWeekFilter === 'completed' ? 'bg-emerald-800 text-white shadow-xs' : 'bg-slate-100 text-slate-600'
            }`}
          >
            مکمل شدہ ({progressStats.completedCount})
          </button>
          <button
            onClick={() => setActiveWeekFilter('pending')}
            className={`px-3 py-1 rounded-xl font-bold cursor-pointer transition-colors ${
              activeWeekFilter === 'pending' ? 'bg-emerald-800 text-white shadow-xs' : 'bg-slate-100 text-slate-600'
            }`}
          >
            زیرِ تدریس / باقی ({12 - progressStats.completedCount})
          </button>
        </div>
      </div>

      {/* 12-Week Syllabus Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredTopics.map((topic) => {
          const rec = currentStudentRecords[topic.week];
          const isDone = rec && (rec.status === 'بہترین' || rec.status === 'بہتر');

          return (
            <div
              key={topic.week}
              className={`bg-white rounded-3xl p-5 border-2 transition-all flex flex-col justify-between space-y-4 shadow-xs hover:shadow-md ${
                isDone ? 'border-emerald-300 bg-gradient-to-b from-emerald-50/30 to-white' : 'border-slate-200'
              }`}
            >
              <div>
                {/* Header: Week badge & title */}
                <div className="flex items-start justify-between gap-3 border-b border-slate-100 pb-3">
                  <div className="flex items-center gap-2.5">
                    <span className="w-10 h-10 rounded-2xl bg-teal-100 text-teal-900 flex items-center justify-center font-black text-sm font-sans shrink-0 border border-teal-200">
                      W{topic.week}
                    </span>
                    <div>
                      <h4 className="font-black text-base text-slate-900">{topic.titleUr}</h4>
                      <span className="text-[11px] text-slate-400 font-mono">ہفتہ نمبر {topic.week}</span>
                    </div>
                  </div>

                  {rec ? (
                    <span
                      className={`px-2.5 py-1 rounded-xl text-[11px] font-bold ${
                        rec.status === 'بہترین'
                          ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                          : rec.status === 'بہتر'
                          ? 'bg-blue-100 text-blue-900 border border-blue-300'
                          : 'bg-amber-100 text-amber-900 border border-amber-300'
                      }`}
                    >
                      {rec.status}
                    </span>
                  ) : (
                    <span className="px-2.5 py-1 rounded-xl text-[11px] font-bold bg-slate-100 text-slate-600">
                      غیر شروع شدہ
                    </span>
                  )}
                </div>

                {/* Arabic Text Card */}
                <div className="my-3 p-3.5 rounded-2xl bg-amber-50/70 border border-amber-200 text-center">
                  <p className="font-arabic text-lg text-emerald-950 leading-loose" dir="rtl">
                    {topic.arabic}
                  </p>
                </div>

                {/* Urdu Description */}
                <div className="space-y-1 text-xs text-slate-600">
                  <span className="font-bold text-slate-700 block">تفصیلِ نصاب:</span>
                  <p className="leading-relaxed">{topic.descriptionUr}</p>
                </div>

                {rec?.remarks && (
                  <div className="mt-2.5 p-2 rounded-xl bg-slate-50 border border-slate-200 text-[11px] text-slate-600">
                    <span className="font-bold text-slate-700">ملاحظہ استاد: </span>
                    <span>{rec.remarks}</span>
                  </div>
                )}
              </div>

              {/* Status Update Buttons */}
              <div className="border-t border-slate-100 pt-3 space-y-1.5">
                <span className="text-[11px] font-bold text-slate-500 block">کیفیت یادداشت درج کریں:</span>
                <div className="grid grid-cols-4 gap-1.5 text-xs font-urdu">
                  {(['بہترین', 'بہتر', 'مناسب', 'زیرِ تدریس'] as const).map((st) => (
                    <button
                      key={st}
                      type="button"
                      onClick={() => handleUpdateWeekStatus(topic.week, st)}
                      className={`py-1.5 px-1 rounded-xl font-bold cursor-pointer transition-colors text-[11px] ${
                        rec?.status === st
                          ? 'bg-emerald-800 text-white shadow-xs'
                          : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                      }`}
                    >
                      {st}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
