import React, { useState } from 'react';
import {
  Student,
  StudentClass,
  UserRole,
  HifzDiaryEntry,
  AttendanceRecord,
  FeePayment,
  MushafData,
  TeacherProfile,
} from '../types';
import { initialTeachers } from '../data/initialData';
import { translations, Language } from '../i18n/translations';
import { StudentDetailModal } from './StudentDetailModal';
import {
  UserPlus,
  Search,
  Printer,
  Edit,
  Trash2,
  Phone,
  Home,
  GraduationCap,
  X,
  Check,
  Eye,
  TrendingUp,
  BarChart2,
  Filter,
} from 'lucide-react';

interface StudentsViewProps {
  students: Student[];
  onAddStudent: (student: Omit<Student, 'id'>) => void;
  onUpdateStudent: (student: Student) => void;
  onDeleteStudent: (id: string) => void;
  onPrintIdCard: (student: Student) => void;
  lang: Language;
  currentRole: UserRole;
  activeTeacherName?: string;
  teachers?: TeacherProfile[];
  isQuickAddOpen?: boolean;
  onCloseQuickAdd?: () => void;
  hifzDiary?: HifzDiaryEntry[];
  attendance?: AttendanceRecord[];
  feePayments?: FeePayment[];
  mushafData?: MushafData;
}

export const StudentsView: React.FC<StudentsViewProps> = ({
  students,
  onAddStudent,
  onUpdateStudent,
  onDeleteStudent,
  onPrintIdCard,
  lang,
  currentRole,
  activeTeacherName = 'قاری عبد الوحید',
  teachers = initialTeachers,
  isQuickAddOpen = false,
  onCloseQuickAdd,
  hifzDiary = [],
  attendance = [],
  feePayments = [],
  mushafData = {},
}) => {
  const t = translations[lang];
  const [selectedClass, setSelectedClass] = useState<string>('all');
  const [hostelFilter, setHostelFilter] = useState<'all' | 'hostel' | 'dayscholar'>('all');
  const [teacherFilter, setTeacherFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(isQuickAddOpen);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [selectedProfileStudent, setSelectedProfileStudent] = useState<Student | null>(null);

  // Sync quick add from dashboard
  React.useEffect(() => {
    if (isQuickAddOpen) {
      setEditingStudent(null);
      setIsModalOpen(true);
    }
  }, [isQuickAddOpen]);

  // Form State
  const [formData, setFormData] = useState({
    rollNo: `MQ-${100 + students.length + 1}`,
    nameUr: '',
    nameEn: '',
    fatherNameUr: '',
    fatherNameEn: '',
    class: 'Hifz' as StudentClass,
    age: 10,
    parentMobile: '',
    isHostel: true,
    monthlyFee: 3000,
    admissionDate: new Date().toISOString().split('T')[0],
    completedParas: 0,
    address: '',
    ustadName: currentRole === 'ustad' ? activeTeacherName : teachers[0]?.nameUr || 'قاری عبد الوحید',
    halqa: teachers[0]?.halqaNameUr || 'حلقہ اول (شعبہ حفظ و تجوید)',
  });

  const handleOpenAdd = () => {
    setEditingStudent(null);
    const assignedUstad = currentRole === 'ustad' ? activeTeacherName : teachers[0]?.nameUr || 'قاری عبد الوحید';
    const tchObj = teachers.find((t) => t.nameUr === assignedUstad);
    setFormData({
      rollNo: `MQ-${100 + students.length + 1}`,
      nameUr: '',
      nameEn: '',
      fatherNameUr: '',
      fatherNameEn: '',
      class: 'Hifz',
      age: 10,
      parentMobile: '',
      isHostel: true,
      monthlyFee: 3000,
      admissionDate: new Date().toISOString().split('T')[0],
      completedParas: 0,
      address: '',
      ustadName: assignedUstad,
      halqa: tchObj?.halqaNameUr || 'حلقہ اول (شعبہ حفظ و تجوید)',
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (student: Student) => {
    setEditingStudent(student);
    setFormData({
      rollNo: student.rollNo,
      nameUr: student.nameUr,
      nameEn: student.nameEn,
      fatherNameUr: student.fatherNameUr,
      fatherNameEn: student.fatherNameEn,
      class: student.class,
      age: student.age,
      parentMobile: student.parentMobile,
      isHostel: student.isHostel,
      monthlyFee: student.monthlyFee,
      admissionDate: student.admissionDate,
      completedParas: student.completedParas || 0,
      address: student.address || '',
      ustadName: student.ustadName || teachers[0]?.nameUr || 'قاری عبد الوحید',
      halqa: student.halqa || 'حلقہ اول (شعبہ حفظ و تجوید)',
    });
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingStudent(null);
    if (onCloseQuickAdd) onCloseQuickAdd();
  };

  const handleSubmitForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.nameUr.trim()) return;

    if (editingStudent) {
      onUpdateStudent({
        ...editingStudent,
        ...formData,
      });
    } else {
      onAddStudent({
        ...formData,
        activeStatus: 'active',
      });
    }

    handleCloseModal();
  };

  // Filter students
  const filteredStudents = students.filter((s) => {
    // 1. Teacher isolation: Teacher can ONLY see their assigned students!
    if (currentRole === 'ustad' && s.ustadName !== activeTeacherName) {
      return false;
    }

    // 2. Admin teacher filter
    if (currentRole === 'admin' && teacherFilter !== 'all' && s.ustadName !== teacherFilter) {
      return false;
    }

    const matchesClass = selectedClass === 'all' || s.class === selectedClass;
    const matchesHostel =
      hostelFilter === 'all' ||
      (hostelFilter === 'hostel' && s.isHostel) ||
      (hostelFilter === 'dayscholar' && !s.isHostel);

    const q = searchQuery.toLowerCase();
    const matchesSearch =
      !q ||
      s.nameUr.includes(q) ||
      s.nameEn.toLowerCase().includes(q) ||
      s.fatherNameUr.includes(q) ||
      s.rollNo.toLowerCase().includes(q) ||
      s.parentMobile.includes(q);

    return matchesClass && matchesHostel && matchesSearch;
  });

  const canManage = currentRole === 'admin' || currentRole === 'ustad';

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Header & Search Bar */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center text-2xl shadow-inner">
            🎓
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-emerald-950 font-urdu">
              {t.studentList} ({filteredStudents.length})
            </h2>
            <p className="text-xs text-slate-500 font-urdu">
              {lang === 'ur'
                ? 'تمام داخل شدہ طلبہ کی تفصیلات، درجہ بندی اور سرپرست رابطہ'
                : 'Enrolled students records, class levels & parent contacts'}
            </p>
          </div>
        </div>

        {canManage && (
          <button
            onClick={handleOpenAdd}
            id="add-student-btn"
            className="flex items-center gap-2 bg-[#0F5D2F] hover:bg-emerald-800 text-white font-black px-5 py-3 rounded-2xl shadow-md transition-all active:scale-95 cursor-pointer font-urdu text-sm"
          >
            <UserPlus className="w-5 h-5 text-amber-400" />
            <span>{t.addNewStudent}</span>
          </button>
        )}
      </div>

      {/* Filters Bar: Classes & Search */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          {/* Class Filter Chips */}
          <div className="flex flex-wrap items-center gap-2">
            {[
              { id: 'all', label: t.allClasses, icon: '📚' },
              { id: 'Hifz', label: t.classHifz, icon: '📖' },
              { id: 'Nazra', label: t.classNazra, icon: '📜' },
              { id: 'Qaida', label: t.classQaida, icon: '🔤' },
              { id: 'Alim', label: t.classAlim, icon: '🎓' },
              { id: 'Deeniat', label: t.classDeeniat, icon: '🕌' },
            ].map((c) => (
              <button
                key={c.id}
                onClick={() => setSelectedClass(c.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer font-urdu ${
                  selectedClass === c.id
                    ? 'bg-[#0F5D2F] text-white shadow-sm ring-2 ring-emerald-600/30'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                <span>{c.icon}</span>
                <span>{c.label}</span>
              </button>
            ))}
          </div>

          {/* Hostel Filter */}
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl text-xs font-urdu">
            <button
              onClick={() => setHostelFilter('all')}
              className={`px-3 py-1 rounded-lg font-bold transition-colors cursor-pointer ${
                hostelFilter === 'all' ? 'bg-white text-emerald-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              تمام
            </button>
            <button
              onClick={() => setHostelFilter('hostel')}
              className={`px-3 py-1 rounded-lg font-bold transition-colors cursor-pointer ${
                hostelFilter === 'hostel' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-600'
              }`}
            >
              ہاسٹل (مقیم)
            </button>
            <button
              onClick={() => setHostelFilter('dayscholar')}
              className={`px-3 py-1 rounded-lg font-bold transition-colors cursor-pointer ${
                hostelFilter === 'dayscholar' ? 'bg-amber-600 text-white shadow-xs' : 'text-slate-600'
              }`}
            >
              غیر مقیم
            </button>
          </div>
        </div>

        {/* Admin Teacher Filter Bar */}
        {currentRole === 'admin' && (
          <div className="flex items-center gap-2 flex-wrap pt-2 border-t border-slate-100 font-urdu text-xs">
            <span className="font-bold text-slate-700 flex items-center gap-1">
              <span>📖</span>
              <span>اساتذہ کے لحاظ سے فلٹر:</span>
            </span>
            <button
              onClick={() => setTeacherFilter('all')}
              className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                teacherFilter === 'all'
                  ? 'bg-emerald-800 text-white shadow-xs'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
            >
              تمام اساتذہ ({students.length})
            </button>
            {teachers.map((tch) => {
              const count = students.filter((s) => s.ustadName === tch.nameUr).length;
              return (
                <button
                  key={tch.id}
                  onClick={() => setTeacherFilter(tch.nameUr)}
                  className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                    teacherFilter === tch.nameUr
                      ? 'bg-amber-500 text-slate-900 shadow-xs ring-2 ring-amber-600/30'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                  }`}
                >
                  {tch.nameUr} ({count})
                </button>
              );
            })}
          </div>
        )}

        {/* Search Input */}
        <div className="relative">
          <Search className="w-5 h-5 absolute right-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t.searchStudentPlaceholder}
            className="w-full pl-4 pr-11 py-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600 text-sm font-urdu"
          />
        </div>
      </div>

      {/* Students Cards Grid for Maximum Accessibility */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredStudents.map((student) => (
          <div
            key={student.id}
            className="bg-white rounded-2xl p-4.5 border-2 border-slate-100 hover:border-emerald-300 shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
          >
            <div>
              {/* Card Header: Roll No & Class (Clickable for Detail View) */}
              <div
                onClick={() => setSelectedProfileStudent(student)}
                className="flex items-start justify-between gap-2 border-b border-slate-100 pb-3 cursor-pointer group"
                title="طالب علم کی مکمل تفصیلات و حفظ پیشرفت دیکھنے کے لیے کلک کریں"
              >
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-xl bg-emerald-50 text-emerald-800 flex items-center justify-center text-xl font-bold border border-emerald-200 shrink-0 group-hover:scale-105 group-hover:bg-emerald-100 transition-all">
                    🎓
                  </div>
                  <div>
                    <h3 className="font-bold text-base text-emerald-950 font-urdu group-hover:text-emerald-700 transition-colors">
                      {student.nameUr}
                    </h3>
                    <p className="text-xs text-slate-500 font-sans">{student.nameEn}</p>
                  </div>
                </div>
                <div className="text-left">
                  <span className="font-mono text-xs font-bold bg-slate-100 text-slate-800 px-2 py-0.5 rounded border border-slate-200 block">
                    {student.rollNo}
                  </span>
                  <span className="text-[11px] font-urdu font-bold text-emerald-800 mt-1 block">
                    {student.class}
                  </span>
                </div>
              </div>

              {/* Card Body Details */}
              <div className="py-3 space-y-2.5 text-xs font-urdu">
                <div className="flex items-center justify-between text-slate-600">
                  <span>والد کا نام:</span>
                  <strong className="text-slate-800">{student.fatherNameUr}</strong>
                </div>

                <div className="flex items-center justify-between text-slate-600">
                  <span className="flex items-center gap-1">
                    <Phone className="w-3.5 h-3.5 text-emerald-600" />
                    <span>موبائل:</span>
                  </span>
                  <a
                    href={`tel:${student.parentMobile}`}
                    className="font-mono font-bold text-emerald-800 hover:underline"
                    dir="ltr"
                  >
                    {student.parentMobile}
                  </a>
                </div>

                <div className="flex items-center justify-between text-slate-600">
                  <span className="flex items-center gap-1">
                    <Home className="w-3.5 h-3.5 text-amber-600" />
                    <span>قیام گاہ:</span>
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded-md font-bold text-[11px] ${
                      student.isHostel ? 'bg-amber-100 text-amber-900' : 'bg-slate-100 text-slate-700'
                    }`}
                  >
                    {student.isHostel ? 'مقیم (ہاسٹل)' : 'غیر مقیم'}
                  </span>
                </div>

                {/* Assigned Teacher Badge */}
                {student.ustadName && (
                  <div className="flex items-center justify-between bg-amber-50/70 px-2.5 py-1.5 rounded-xl border border-amber-200 text-amber-950">
                    <span className="flex items-center gap-1 text-[11px] font-bold text-amber-900">
                      <span>📖</span>
                      <span>استاد محترم:</span>
                    </span>
                    <span className="font-bold text-xs">{student.ustadName}</span>
                  </div>
                )}

                {/* Hifz Completion Progress Bar on Card */}
                {student.class === 'Hifz' && (
                  <div
                    onClick={() => setSelectedProfileStudent(student)}
                    className="p-2 rounded-xl bg-emerald-50/70 border border-emerald-100 space-y-1.5 cursor-pointer hover:bg-emerald-100/60 transition-colors"
                    title="حفظ تکمیل چارٹ دیکھنے کے لیے کلک کریں"
                  >
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="font-bold text-emerald-950 flex items-center gap-1">
                        <TrendingUp className="w-3 h-3 text-emerald-700" />
                        <span>حفظ تکمیل:</span>
                      </span>
                      <span className="font-mono font-bold text-emerald-900 bg-white px-1.5 py-0.5 rounded shadow-2xs">
                        {student.completedParas || 0} / 30 پارے ({Math.min(100, Math.round(((student.completedParas || 0) / 30) * 100))}%)
                      </span>
                    </div>
                    <div className="w-full bg-emerald-200/60 h-2 rounded-full overflow-hidden">
                      <div
                        className="bg-emerald-600 h-full rounded-full transition-all duration-300"
                        style={{ width: `${Math.min(100, Math.round(((student.completedParas || 0) / 30) * 100))}%` }}
                      />
                    </div>
                  </div>
                )}

                <div className="flex items-center justify-between text-slate-600">
                  <span>ماہانہ فیس:</span>
                  <span className="font-mono font-bold text-slate-900">{student.monthlyFee} روپے</span>
                </div>
              </div>
            </div>

            {/* Card Actions Footer */}
            <div className="border-t border-slate-100 pt-3 flex items-center justify-between gap-1.5 flex-wrap">
              <button
                id={`student-detail-btn-${student.id}`}
                onClick={() => setSelectedProfileStudent(student)}
                title="تفصیلات و حفظ پیشرفت چارٹ"
                className="flex-1 flex items-center justify-center gap-1.5 py-1.5 px-2 bg-[#0F5D2F] hover:bg-emerald-800 text-white rounded-xl text-xs font-bold font-urdu transition-all cursor-pointer shadow-xs"
              >
                <TrendingUp className="w-3.5 h-3.5" />
                <span>تفصیلات و چارٹ 📊</span>
              </button>

              <button
                onClick={() => onPrintIdCard(student)}
                title={t.printIdCard}
                className="flex items-center justify-center gap-1 py-1.5 px-2.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 rounded-xl text-xs font-bold font-urdu transition-colors cursor-pointer border border-emerald-200"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>کارڈ 🪪</span>
              </button>

              {canManage && (
                <>
                  <button
                    onClick={() => handleOpenEdit(student)}
                    title="Edit"
                    className="p-2 bg-slate-100 hover:bg-blue-100 text-slate-700 hover:text-blue-800 rounded-xl transition-colors cursor-pointer"
                  >
                    <Edit className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => {
                      if (window.confirm(t.confirmDelete)) {
                        onDeleteStudent(student.id);
                      }
                    }}
                    title="Delete"
                    className="p-2 bg-slate-100 hover:bg-rose-100 text-slate-700 hover:text-rose-800 rounded-xl transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </>
              )}
            </div>
          </div>
        ))}
      </div>

      {filteredStudents.length === 0 && (
        <div className="bg-white rounded-3xl p-12 text-center text-slate-400 font-urdu space-y-2 border border-slate-200">
          <GraduationCap className="w-12 h-12 mx-auto text-slate-300" />
          <h4 className="text-base font-bold text-slate-600">کوئی طالب علم نہیں ملا</h4>
          <p className="text-xs">برائے مہربانی فلٹر تبدیل کریں یا نیا طالب علم داخل کریں۔</p>
        </div>
      )}

      {/* Add / Edit Student Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-xl overflow-hidden animate-in fade-in duration-200">
            <div className="bg-[#0F5D2F] text-white p-5 flex items-center justify-between border-b-4 border-amber-500">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center text-2xl">
                  🎓
                </div>
                <div>
                  <h3 className="font-bold text-lg font-urdu">
                    {editingStudent ? t.editStudent : t.addNewStudent}
                  </h3>
                  <p className="text-xs text-emerald-200 font-urdu">مدرسہ قاسمیہ داخلہ رجسٹر</p>
                </div>
              </div>
              <button
                onClick={handleCloseModal}
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitForm} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto font-urdu">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Roll No */}
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">{t.rollNo}:</label>
                  <input
                    type="text"
                    required
                    value={formData.rollNo}
                    onChange={(e) => setFormData({ ...formData, rollNo: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono font-bold text-sm"
                  />
                </div>

                {/* Class */}
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">{t.class}:</label>
                  <select
                    value={formData.class}
                    onChange={(e) => setFormData({ ...formData, class: e.target.value as StudentClass })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-sm bg-white"
                  >
                    <option value="Hifz">حفظ القرآن</option>
                    <option value="Nazra">ناظرہ قرآن</option>
                    <option value="Qaida">نورانی قاعدہ</option>
                    <option value="Alim">درسِ نظامی (عالم)</option>
                    <option value="Deeniat">ابتدائی دینیات</option>
                  </select>
                </div>

                {/* Name Urdu */}
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">{t.studentName} (اردو):</label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: محمد احمد"
                    value={formData.nameUr}
                    onChange={(e) => setFormData({ ...formData, nameUr: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-sm"
                  />
                </div>

                {/* Name English */}
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">{t.studentName} (English):</label>
                  <input
                    type="text"
                    placeholder="e.g. Muhammad Ahmad"
                    value={formData.nameEn}
                    onChange={(e) => setFormData({ ...formData, nameEn: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-sans text-sm"
                    dir="ltr"
                  />
                </div>

                {/* Father Name Urdu */}
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">{t.fatherName} (اردو):</label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: عبد الرشید"
                    value={formData.fatherNameUr}
                    onChange={(e) => setFormData({ ...formData, fatherNameUr: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
                  />
                </div>

                {/* Father Name English */}
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">{t.fatherName} (English):</label>
                  <input
                    type="text"
                    placeholder="e.g. Abdul Rasheed"
                    value={formData.fatherNameEn}
                    onChange={(e) => setFormData({ ...formData, fatherNameEn: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-sans text-sm"
                    dir="ltr"
                  />
                </div>

                {/* Parent Mobile */}
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">{t.mobileNumber}:</label>
                  <input
                    type="tel"
                    required
                    placeholder="03001234567"
                    value={formData.parentMobile}
                    onChange={(e) => setFormData({ ...formData, parentMobile: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-sm"
                    dir="ltr"
                  />
                </div>

                {/* Age */}
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">{t.age}:</label>
                  <input
                    type="number"
                    min={4}
                    max={30}
                    value={formData.age}
                    onChange={(e) => setFormData({ ...formData, age: parseInt(e.target.value) || 10 })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-sm"
                  />
                </div>

                {/* Monthly Fee */}
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">{t.monthlyFee} (روپے):</label>
                  <input
                    type="number"
                    min={0}
                    step={100}
                    value={formData.monthlyFee}
                    onChange={(e) => setFormData({ ...formData, monthlyFee: parseInt(e.target.value) || 0 })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-sm"
                  />
                </div>

                {/* Completed Paras */}
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">{t.completedParas} (0 تا 30):</label>
                  <input
                    type="number"
                    min={0}
                    max={30}
                    value={formData.completedParas}
                    onChange={(e) => setFormData({ ...formData, completedParas: parseInt(e.target.value) || 0 })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-sm"
                  />
                </div>
              </div>

              {/* Hostel Status Radio */}
              <div className="pt-2">
                <label className="block text-xs font-bold text-slate-600 mb-2">{t.hostelStatus}:</label>
                <div className="flex gap-4">
                  <label className="flex items-center gap-2 cursor-pointer text-sm">
                    <input
                      type="radio"
                      name="isHostel"
                      checked={formData.isHostel}
                      onChange={() => setFormData({ ...formData, isHostel: true })}
                      className="w-4 h-4 text-emerald-600"
                    />
                    <span>{t.hostelYes}</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer text-sm">
                    <input
                      type="radio"
                      name="isHostel"
                      checked={!formData.isHostel}
                      onChange={() => setFormData({ ...formData, isHostel: false })}
                      className="w-4 h-4 text-emerald-600"
                    />
                    <span>{t.hostelNo}</span>
                  </label>
                </div>
              </div>

              {/* Teacher Assignment */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  استاد محترم و حلقہ کا تعین:
                </label>
                <select
                  value={formData.ustadName}
                  onChange={(e) => {
                    const tch = teachers.find((t) => t.nameUr === e.target.value);
                    setFormData({
                      ...formData,
                      ustadName: e.target.value,
                      halqa: tch?.halqaNameUr || formData.halqa,
                    });
                  }}
                  disabled={currentRole === 'ustad'}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-slate-800 text-sm font-urdu focus:ring-2 focus:ring-emerald-600"
                >
                  {teachers.map((tch) => (
                    <option key={tch.id} value={tch.nameUr}>
                      {tch.nameUr} — ({tch.halqaNameUr})
                    </option>
                  ))}
                </select>
                {currentRole === 'ustad' && (
                  <span className="text-[10px] text-amber-700 mt-1 block">
                    استاد کی حیثیت سے آپ صرف اپنے حلقے میں طالب علم داخل کر سکتے ہیں۔
                  </span>
                )}
              </div>

              {/* Address */}
              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">مکمل پتہ و محلہ:</label>
                <input
                  type="text"
                  placeholder="گھر / محلہ کا پتہ"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
                />
              </div>

              <div className="flex items-center gap-3 pt-4 border-t border-slate-200">
                <button
                  type="submit"
                  className="flex-1 bg-[#0F5D2F] hover:bg-emerald-800 text-white font-bold py-3 px-6 rounded-2xl shadow-md transition-all cursor-pointer flex items-center justify-center gap-2"
                >
                  <Check className="w-5 h-5" />
                  <span>{t.save}</span>
                </button>
                <button
                  type="button"
                  onClick={handleCloseModal}
                  className="px-5 py-3 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-sm cursor-pointer"
                >
                  {t.cancel}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Student Detail View with Recharts Hifz Completion Progress Chart */}
      {selectedProfileStudent && (
        <StudentDetailModal
          student={selectedProfileStudent}
          isOpen={!!selectedProfileStudent}
          onClose={() => setSelectedProfileStudent(null)}
          onPrintIdCard={onPrintIdCard}
          onEditStudent={handleOpenEdit}
          hifzDiary={hifzDiary}
          attendance={attendance}
          feePayments={feePayments}
          mushafData={mushafData}
          lang={lang}
          currentRole={currentRole}
        />
      )}
    </div>
  );
};
