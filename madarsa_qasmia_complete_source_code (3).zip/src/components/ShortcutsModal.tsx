import React, { useState } from 'react';
import { X, Keyboard, Zap, Compass, Sparkles, ExternalLink, ArrowRight } from 'lucide-react';
import { Language } from '../i18n/translations';

interface ShortcutItem {
  id: string;
  category: 'quick' | 'nav' | 'system';
  keys: string[];
  titleUr: string;
  titleEn: string;
  descUr: string;
  descEn: string;
  icon: string;
  action: () => void;
}

interface ShortcutsModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  onNavigateTab: (tab: string) => void;
  onOpenQuickAddStudent?: () => void;
  onOpenQuickCollectFee?: () => void;
  onOpenQuickLogHifz?: () => void;
  onOpenWhatsAppCenter?: () => void;
  onOpenRoleModal?: () => void;
}

export const ShortcutsModal: React.FC<ShortcutsModalProps> = ({
  isOpen,
  onClose,
  lang,
  onNavigateTab,
  onOpenQuickAddStudent,
  onOpenQuickCollectFee,
  onOpenQuickLogHifz,
  onOpenWhatsAppCenter,
  onOpenRoleModal,
}) => {
  const [activeCategory, setActiveCategory] = useState<'all' | 'quick' | 'nav' | 'system'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  if (!isOpen) return null;

  const isUrdu = lang === 'ur';

  const shortcuts: ShortcutItem[] = [
    // Quick Actions
    {
      id: 'quick-sabaq',
      category: 'quick',
      keys: ['Alt', 'L'],
      titleUr: 'سبق ڈائری کا فوری اندراج',
      titleEn: 'Quick Log Daily Sabaq',
      descUr: 'آج کا سبق، سبقی اور منزل فوراً درج کریں',
      descEn: 'Log Sabaq, Sabqi & Manzil in one click',
      icon: '📖',
      action: () => {
        onClose();
        if (onOpenQuickLogHifz) onOpenQuickLogHifz();
      },
    },
    {
      id: 'quick-add-student',
      category: 'quick',
      keys: ['Alt', 'S'],
      titleUr: 'نیا داخلہ فارم کھولیں',
      titleEn: 'Enroll New Student Form',
      descUr: 'نئے طالب علم کے داخلہ کا فوری پاپ اپ',
      descEn: 'Open student registration popup',
      icon: '🎓',
      action: () => {
        onClose();
        if (onOpenQuickAddStudent) onOpenQuickAddStudent();
      },
    },
    {
      id: 'quick-fee',
      category: 'quick',
      keys: ['Alt', 'F'],
      titleUr: 'فوری فیس وصولی',
      titleEn: 'Quick Fee Collection',
      descUr: 'فیس واؤچر اور رسید کا براہ راست فارم',
      descEn: 'Collect fee & generate receipt directly',
      icon: '💰',
      action: () => {
        onClose();
        if (onOpenQuickCollectFee) onOpenQuickCollectFee();
      },
    },
    {
      id: 'quick-whatsapp',
      category: 'quick',
      keys: ['Alt', 'W'],
      titleUr: 'واٹس ایپ الرٹس سینٹر',
      titleEn: 'WhatsApp Alerts Hub',
      descUr: 'غیر حاضری، سبق اور فیس کے پیغامات سرپرستوں کو بھیجیں',
      descEn: 'Send absent, fee & diary alerts to parents',
      icon: '💬',
      action: () => {
        onClose();
        if (onOpenWhatsAppCenter) onOpenWhatsAppCenter();
      },
    },
    {
      id: 'quick-role',
      category: 'quick',
      keys: ['Alt', 'R'],
      titleUr: 'رول لاگ ان و سوئچ',
      titleEn: 'Switch User Role / PIN',
      descUr: 'مہتمم، استاد، محاسب یا والدین کا رول منتخب کریں',
      descEn: 'Switch role with PIN verification',
      icon: '👑',
      action: () => {
        onClose();
        if (onOpenRoleModal) onOpenRoleModal();
      },
    },

    // Navigation Tabs
    {
      id: 'nav-dashboard',
      category: 'nav',
      keys: ['Alt', '1'],
      titleUr: 'ڈیش بورڈ (مرکزی جائزہ)',
      titleEn: 'Dashboard Home',
      descUr: 'مرکزی اعداد و شمار اور کوئیک ٹریکر',
      descEn: 'Overview metrics and quick tracker',
      icon: '🕌',
      action: () => {
        onClose();
        onNavigateTab('dashboard');
      },
    },
    {
      id: 'nav-students',
      category: 'nav',
      keys: ['Alt', '2'],
      titleUr: 'طلبہ ڈائریکٹری و فہرست',
      titleEn: 'Students Directory',
      descUr: 'تمام طلبہ کے کوائف، فلٹرز اور کارڈز',
      descEn: 'Manage student records, search and filter',
      icon: '🎓',
      action: () => {
        onClose();
        onNavigateTab('students');
      },
    },
    {
      id: 'nav-attendance',
      category: 'nav',
      keys: ['Alt', '3'],
      titleUr: 'حاضری رجسٹر و ماہانہ شیٹ',
      titleEn: 'Daily & Monthly Attendance',
      descUr: 'طلبہ کی روزانہ حاضری، رخصت اور غیر حاضری ریکارڈ',
      descEn: 'Mark and view monthly attendance grid',
      icon: '✅',
      action: () => {
        onClose();
        onNavigateTab('attendance');
      },
    },
    {
      id: 'nav-hifz',
      category: 'nav',
      keys: ['Alt', '4'],
      titleUr: 'جامع تعلیمی ڈائری (حفظ و ناظرہ)',
      titleEn: 'Advanced Hifz & Sabaq Diary',
      descUr: 'روزانہ کا سبق، سبقی، منزل اور گریڈ ریکارڈ',
      descEn: 'Daily Quran memorization progress & grades',
      icon: '📖',
      action: () => {
        onClose();
        onNavigateTab('hifz');
      },
    },
    {
      id: 'nav-mushaf',
      category: 'nav',
      keys: ['Alt', '5'],
      titleUr: 'مصحف شریف (۳۰ پارے ویور)',
      titleEn: 'Mushaf (30 Paras Progress)',
      descUr: '۳۰ پاروں کے رنگین اسٹیٹس اور تجوید ٹریکر',
      descEn: 'Visual 30 Paras memorization progress',
      icon: '📜',
      action: () => {
        onClose();
        onNavigateTab('mushaf');
      },
    },
    {
      id: 'nav-revision',
      category: 'nav',
      keys: ['Alt', '6'],
      titleUr: 'اسمارٹ ریویژن شیڈولر',
      titleEn: 'Smart Revision Scheduler',
      descUr: 'منزل و دہرائی کا خودکار اور ذہین الگورتھم',
      descEn: 'Spaced repetition revision schedule',
      icon: '⚡',
      action: () => {
        onClose();
        onNavigateTab('revision');
      },
    },
    {
      id: 'nav-fees',
      category: 'nav',
      keys: ['Alt', '7'],
      titleUr: 'فیس و واجبات کھاتہ',
      titleEn: 'Fees & Dues Management',
      descUr: 'ماہانہ فیس کی وصولی، رسیدیں اور نادہندگان لسٹ',
      descEn: 'Fee payments, receipts and defaulters list',
      icon: '💰',
      action: () => {
        onClose();
        onNavigateTab('fees');
      },
    },
    {
      id: 'nav-donations',
      category: 'nav',
      keys: ['Alt', '8'],
      titleUr: 'چندہ، عطیات و اخراجات',
      titleEn: 'Donations & Madrasa Finance',
      descUr: 'آمدنی و اخراجات کی تفاصیل اور رسیدیں',
      descEn: 'Record donations and operational expenses',
      icon: '🪙',
      action: () => {
        onClose();
        onNavigateTab('donations');
      },
    },
    {
      id: 'nav-exams',
      category: 'nav',
      keys: ['Alt', '9'],
      titleUr: 'امتحانات و رزلٹ کارڈز',
      titleEn: 'Exams & Result Cards',
      descUr: 'سہ ماہی، ششماہی اور سالانہ امتحانات و رزلٹ شیٹ',
      descEn: 'Quarterly, half-yearly and annual exam grades',
      icon: '🏆',
      action: () => {
        onClose();
        onNavigateTab('exams');
      },
    },
    {
      id: 'nav-notices',
      category: 'nav',
      keys: ['Alt', '0'],
      titleUr: 'اعلانات و اطلاعات بورڈ',
      titleEn: 'Notice Board & Announcements',
      descUr: 'تعطیلات، تقاریب اور ضروری پیغامات برائے والدین',
      descEn: 'Madrasa announcements, holidays & events',
      icon: '📢',
      action: () => {
        onClose();
        onNavigateTab('notices');
      },
    },
    {
      id: 'nav-reports',
      category: 'system',
      keys: ['Alt', 'P'],
      titleUr: 'پرنٹ، رپورٹس و ڈیٹا بیک اپ',
      titleEn: 'Reports & Data Backup',
      descUr: 'مکمل پی ڈی ایف و ایکسل پرنٹ اور بیک اپ فائل ڈاؤن لوڈ',
      descEn: 'Export JSON, print ledgers and reports',
      icon: '🖨️',
      action: () => {
        onClose();
        onNavigateTab('reports');
      },
    },
    {
      id: 'system-help',
      category: 'system',
      keys: ['Alt', 'K'],
      titleUr: 'شارٹ کٹس گائیڈ (یہ ونڈو)',
      titleEn: 'Shortcuts Help Window',
      descUr: 'کی بورڈ شارٹ کٹس کی فہرست دیکھیں',
      descEn: 'Show all application shortcuts',
      icon: '⌨️',
      action: () => {},
    },
  ];

  const filteredShortcuts = shortcuts.filter((item) => {
    if (activeCategory !== 'all' && item.category !== activeCategory) return false;
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      item.titleUr.toLowerCase().includes(q) ||
      item.titleEn.toLowerCase().includes(q) ||
      item.keys.join(' ').toLowerCase().includes(q)
    );
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 backdrop-blur-xs p-4 overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl shadow-2xl border-2 border-emerald-600/40 w-full max-w-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header Banner */}
        <div className="bg-gradient-to-r from-[#0F5D2F] via-[#0a4221] to-[#062914] text-white p-5 flex items-center justify-between border-b-4 border-amber-400">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-amber-400 text-emerald-950 flex items-center justify-center font-bold text-2xl shadow-inner">
              ⌨️
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-mono uppercase tracking-wider bg-amber-400/20 text-amber-300 px-2 py-0.5 rounded-full font-bold">
                  KEYBOARD SHORTCUTS
                </span>
                <span className="text-[11px] text-emerald-200 font-urdu">
                  تیز ترین کام کے لیے
                </span>
              </div>
              <h3 className="font-black text-xl font-urdu mt-0.5">
                {isUrdu ? 'کی بورڈ شارٹ کٹس و فوری اقدامات' : 'Keyboard Shortcuts & Quick Actions'}
              </h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search & Filter Bar */}
        <div className="p-4 bg-slate-50 border-b border-slate-200 space-y-3 font-urdu">
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={isUrdu ? 'شارٹ کٹ تلاش کریں (مثلاً: سبق، فیس، داخلہ، Alt+L)...' : 'Search shortcut...'}
              className="w-full bg-white border border-slate-300 rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:border-transparent"
            />
          </div>

          <div className="flex items-center gap-2 flex-wrap text-xs">
            <button
              onClick={() => setActiveCategory('all')}
              className={`px-3 py-1.5 rounded-xl font-bold transition cursor-pointer ${
                activeCategory === 'all'
                  ? 'bg-emerald-800 text-white shadow-xs'
                  : 'bg-white hover:bg-slate-200 text-slate-700 border border-slate-200'
              }`}
            >
              {isUrdu ? 'تمام شارٹ کٹس' : 'All Shortcuts'}
            </button>
            <button
              onClick={() => setActiveCategory('quick')}
              className={`px-3 py-1.5 rounded-xl font-bold transition cursor-pointer flex items-center gap-1.5 ${
                activeCategory === 'quick'
                  ? 'bg-amber-500 text-emerald-950 font-black shadow-xs'
                  : 'bg-white hover:bg-slate-200 text-slate-700 border border-slate-200'
              }`}
            >
              <Zap className="w-3.5 h-3.5" />
              <span>{isUrdu ? 'فوری اقدامات' : 'Quick Actions'}</span>
            </button>
            <button
              onClick={() => setActiveCategory('nav')}
              className={`px-3 py-1.5 rounded-xl font-bold transition cursor-pointer flex items-center gap-1.5 ${
                activeCategory === 'nav'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'bg-white hover:bg-slate-200 text-slate-700 border border-slate-200'
              }`}
            >
              <Compass className="w-3.5 h-3.5" />
              <span>{isUrdu ? 'نیویگیشن ٹیبز' : 'Navigation Tabs'}</span>
            </button>
            <button
              onClick={() => setActiveCategory('system')}
              className={`px-3 py-1.5 rounded-xl font-bold transition cursor-pointer flex items-center gap-1.5 ${
                activeCategory === 'system'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'bg-white hover:bg-slate-200 text-slate-700 border border-slate-200'
              }`}
            >
              <span>{isUrdu ? 'ٹولز و سسٹم' : 'Tools & System'}</span>
            </button>
          </div>
        </div>

        {/* Shortcuts List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2.5 divide-y divide-slate-100 font-urdu">
          {filteredShortcuts.length === 0 ? (
            <div className="text-center py-12 text-slate-400">
              <Keyboard className="w-10 h-10 mx-auto text-slate-300 mb-2" />
              <p>{isUrdu ? 'کوئی شارٹ کٹ نہیں ملا' : 'No shortcuts found'}</p>
            </div>
          ) : (
            filteredShortcuts.map((item) => (
              <div
                key={item.id}
                onClick={item.action}
                className="pt-2.5 first:pt-0 flex items-center justify-between gap-3 p-2.5 rounded-2xl hover:bg-emerald-50/70 border border-transparent hover:border-emerald-200 transition-all cursor-pointer group"
                title={isUrdu ? 'اس شارٹ کٹ کو فوراً چلانے کے لیے کلک کریں' : 'Click to run shortcut now'}
              >
                <div className="flex items-center gap-3">
                  <span className="text-2xl w-9 h-9 rounded-xl bg-slate-100 group-hover:bg-amber-100 flex items-center justify-center shrink-0 transition-colors">
                    {item.icon}
                  </span>
                  <div>
                    <h4 className="font-bold text-sm text-slate-900 group-hover:text-emerald-950 flex items-center gap-1.5">
                      <span>{isUrdu ? item.titleUr : item.titleEn}</span>
                      <ArrowRight className="w-3 h-3 text-emerald-600 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </h4>
                    <p className="text-xs text-slate-500">
                      {isUrdu ? item.descUr : item.descEn}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1 shrink-0 font-mono">
                  {item.keys.map((k, idx) => (
                    <React.Fragment key={k}>
                      <kbd className="px-2.5 py-1 text-xs font-bold text-slate-800 bg-slate-100 border border-slate-300 rounded-lg shadow-2xs group-hover:border-amber-400 group-hover:bg-amber-50">
                        {k}
                      </kbd>
                      {idx < item.keys.length - 1 && (
                        <span className="text-slate-400 text-xs">+</span>
                      )}
                    </React.Fragment>
                  ))}
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-600 font-urdu">
          <div className="flex items-center gap-2">
            <span className="text-base">💡</span>
            <span>
              {isUrdu
                ? 'مشورہ: کسی بھی شارٹ کٹ پر کلک کر کے اسے فوراً بھی کھول سکتے ہیں!'
                : 'Tip: You can also click any shortcut row to trigger it immediately!'}
            </span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white font-bold cursor-pointer"
          >
            {isUrdu ? 'بند کریں' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
