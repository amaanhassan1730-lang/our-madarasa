import React, { useState, useMemo } from 'react';
import { Student, HifzDiaryEntry, UserRole } from '../types';
import { Language, translations } from '../i18n/translations';
import {
  Flame,
  Calendar,
  Clock,
  CheckCircle,
  AlertTriangle,
  Send,
  BookOpen,
  Filter,
  Search,
  User,
  Sparkles,
  ChevronRight,
  TrendingUp,
  RefreshCw,
} from 'lucide-react';

interface SmartRevisionSchedulerViewProps {
  students: Student[];
  hifzDiary: HifzDiaryEntry[];
  onAddDiaryEntry?: (entry: Omit<HifzDiaryEntry, 'id'>) => void;
  onNavigateTab: (tab: string) => void;
  lang: Language;
  currentRole: UserRole;
  activeTeacherName?: string;
  parentStudentMobile?: string;
}

interface RevisionParaItem {
  studentId: string;
  studentName: string;
  studentRollNo: string;
  parentMobile: string;
  para: number;
  lastReviewedDate: string | null;
  daysElapsed: number;
  mistakesCount: number;
  lastQuality: string;
  urgencyScore: number; // 0 to 100
  urgencyLevel: 'critical' | 'high' | 'medium' | 'low' | 'fresh';
  recommendationUr: string;
  recommendedPages: string;
}

export const SmartRevisionSchedulerView: React.FC<SmartRevisionSchedulerViewProps> = ({
  students,
  hifzDiary,
  onAddDiaryEntry,
  onNavigateTab,
  lang,
  currentRole,
  activeTeacherName = 'قاری عبد الوحید',
  parentStudentMobile,
}) => {
  const t = translations[lang];

  // Filter students based on role
  const hifzStudents = useMemo(() => {
    let list = students.filter((s) => s.class === 'Hifz' || (s.completedParas && s.completedParas > 0));
    if (currentRole === 'parent' && parentStudentMobile) {
      const clean = parentStudentMobile.replace(/[^0-9]/g, '');
      list = list.filter((s) => s.parentMobile.replace(/[^0-9]/g, '').includes(clean));
    } else if (currentRole === 'ustad' && activeTeacherName) {
      list = list.filter((s) => s.ustadName === activeTeacherName);
    }
    return list;
  }, [students, currentRole, parentStudentMobile, activeTeacherName]);

  const [selectedStudentFilter, setSelectedStudentFilter] = useState<string>('all');
  const [urgencyFilter, setUrgencyFilter] = useState<'all' | 'critical' | 'high' | 'medium' | 'fresh'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [dailyQuota, setDailyQuota] = useState<'half_para' | 'one_para' | 'two_paras'>('one_para');
  const [quickLogPara, setQuickLogPara] = useState<RevisionParaItem | null>(null);
  const [quickLogRemarks, setQuickLogRemarks] = useState('ماشاءاللہ آج کی دہرائی تسلی بخش رہی۔');
  const [quickLogQuality, setQuickLogQuality] = useState<'بہترین' | 'بہتر' | 'مناسب'>('بہترین');
  const [quickLogMistakes, setQuickLogMistakes] = useState({ atakna: 0, bhoolna: 0, tajweed: 0 });

  // Calculate intelligent revision matrix for each completed para of each student
  const revisionItems = useMemo<RevisionParaItem[]>(() => {
    const today = new Date();
    const items: RevisionParaItem[] = [];

    hifzStudents.forEach((student) => {
      const completed = Math.max(student.completedParas || 1, 1);
      const studentEntries = hifzDiary.filter((d) => d.studentId === student.id);

      for (let p = 1; p <= completed; p++) {
        // Find latest diary entry mentioning this para in manzil or sabaq
        const matchingEntries = studentEntries.filter(
          (d) =>
            (d.manzil && (d.manzil.includes(`پارہ ${p}`) || d.manzil.includes(`پارہ ${p} `) || d.manzil === `${p}`)) ||
            d.sabaqPara === p
        );

        let lastDate: string | null = null;
        let mistakes = 0;
        let quality = 'نامعلوم';

        if (matchingEntries.length > 0) {
          const sorted = [...matchingEntries].sort((a, b) => b.date.localeCompare(a.date));
          const latest = sorted[0];
          lastDate = latest.date;
          quality = latest.quality || 'بہتر';
          mistakes = (latest.mistakes?.atakna || 0) + (latest.mistakes?.bhoolna || 0) + (latest.mistakes?.tajweed || 0);
        }

        let daysElapsed = 30; // Default if never reviewed
        if (lastDate) {
          const diffMs = today.getTime() - new Date(lastDate).getTime();
          daysElapsed = Math.max(0, Math.floor(diffMs / (1000 * 60 * 60 * 24)));
        }

        // Urgency score calculation algorithm:
        // Score = (DaysElapsed * 3) + (Mistakes * 8) + (Quality Penalty)
        let score = daysElapsed * 3.2 + mistakes * 8;
        if (quality === 'مناسب') score += 20;
        if (quality === 'کمزور') score += 35;
        if (!lastDate) score += 40; // Never reviewed bonus

        score = Math.min(100, Math.round(score));

        let urgencyLevel: 'critical' | 'high' | 'medium' | 'low' | 'fresh' = 'fresh';
        let recommendationUr = 'دہرائی محفوظ اور پختہ ہے';

        if (score >= 75 || daysElapsed > 14) {
          urgencyLevel = 'critical';
          recommendationUr = 'فوری دہرائی واجب ہے، بھولنے کا خدشہ ہے!';
        } else if (score >= 50 || daysElapsed > 7) {
          urgencyLevel = 'high';
          recommendationUr = 'آج یا کل میں اس پارے کا دور لازم ہے۔';
        } else if (score >= 30 || daysElapsed > 4) {
          urgencyLevel = 'medium';
          recommendationUr = 'معمول کے مطابق دہرائی شیڈول کریں۔';
        } else {
          urgencyLevel = 'fresh';
          recommendationUr = 'حالیہ دہرایا گیا، الحمدللہ پختہ ہے۔';
        }

        items.push({
          studentId: student.id,
          studentName: student.nameUr,
          studentRollNo: student.rollNo,
          parentMobile: student.parentMobile,
          para: p,
          lastReviewedDate: lastDate,
          daysElapsed,
          mistakesCount: mistakes,
          lastQuality: quality,
          urgencyScore: score,
          urgencyLevel,
          recommendationUr,
          recommendedPages: `پارہ ${p} (مکمل ۲۰ صفحات)`,
        });
      }
    });

    return items.sort((a, b) => b.urgencyScore - a.urgencyScore);
  }, [hifzStudents, hifzDiary]);

  // Filtered items
  const filteredItems = useMemo(() => {
    return revisionItems.filter((item) => {
      if (selectedStudentFilter !== 'all' && item.studentId !== selectedStudentFilter) return false;
      if (urgencyFilter !== 'all') {
        if (urgencyFilter === 'critical' && item.urgencyLevel !== 'critical') return false;
        if (urgencyFilter === 'high' && item.urgencyLevel !== 'high') return false;
        if (urgencyFilter === 'medium' && item.urgencyLevel !== 'medium') return false;
        if (urgencyFilter === 'fresh' && item.urgencyLevel !== 'fresh') return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          item.studentName.toLowerCase().includes(q) ||
          item.studentRollNo.toLowerCase().includes(q) ||
          `پارہ ${item.para}`.includes(q) ||
          String(item.para) === q
        );
      }
      return true;
    });
  }, [revisionItems, selectedStudentFilter, urgencyFilter, searchQuery]);

  // Metrics Summary
  const stats = useMemo(() => {
    const total = revisionItems.length;
    const critical = revisionItems.filter((i) => i.urgencyLevel === 'critical').length;
    const high = revisionItems.filter((i) => i.urgencyLevel === 'high').length;
    const medium = revisionItems.filter((i) => i.urgencyLevel === 'medium').length;
    const fresh = revisionItems.filter((i) => i.urgencyLevel === 'fresh').length;
    return { total, critical, high, medium, fresh };
  }, [revisionItems]);

  // Handle Quick Revision Log Submission
  const handleQuickLogSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickLogPara || !onAddDiaryEntry) return;

    onAddDiaryEntry({
      studentId: quickLogPara.studentId,
      date: new Date().toISOString().split('T')[0],
      hifzType: 'حفظ',
      sabaqPara: quickLogPara.para,
      sabaqLinesOrPages: 'دہرائی پارہ',
      sabqi: '',
      manzil: `پارہ ${quickLogPara.para}`,
      quality: quickLogQuality,
      grade: quickLogQuality === 'بہترین' ? 'A+' : quickLogQuality === 'بہتر' ? 'A' : 'B',
      hadaf: { quantity: 1, unit: 'صفحہ' },
      mistakes: quickLogMistakes,
      teacherRemarks: quickLogRemarks,
      ustadName: 'قاری عبد الوحید (نگران دہرائی)',
    });

    setQuickLogPara(null);
    setQuickLogMistakes({ atakna: 0, bhoolna: 0, tajweed: 0 });
    setQuickLogRemarks('ماشاءاللہ آج کی دہرائی تسلی بخش رہی۔');
  };

  // WhatsApp Alert for Schedule
  const handleSendWhatsAppSchedule = (item: RevisionParaItem) => {
    const text = `السلام علیکم ورحمۃ اللہ وبرکاتہ!
محترم سرپرستِ *${item.studentName}* (رول نمبر: ${item.studentRollNo})
مدرسہ قاسمیہ کے اسمارٹ ریویژن شیڈولر کے مطابق:

📖 *منزل و دہرائی شیڈول:*
پارہ نمبر: *${item.para}*
آخری دہرائی: ${item.lastReviewedDate || 'کافی دن قبل'} (${item.daysElapsed} دن ہوئے)
کیفیت: *${item.urgencyLevel === 'critical' ? '🚨 فوری دہرائی ضروری' : '⚡ ترجیحی دہرائی'}*
ہدایت استاد: ${item.recommendationUr}

براہِ کرم گھر پر بھی اس پارے کی دہرائی پر خصوصی توجہ دلائیں۔
_ادارہ مدرسہ قاسمیہ_`;

    const cleanPhone = item.parentMobile.replace(/[^0-9]/g, '');
    const url = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  return (
    <div className="space-y-6 font-urdu pb-12" dir="rtl">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-[#0F5D2F] via-emerald-800 to-teal-900 rounded-3xl p-6 sm:p-8 text-white shadow-lg border-2 border-emerald-600 relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 bg-amber-400 text-emerald-950 px-3.5 py-1 rounded-full text-xs font-black tracking-wide shadow-xs font-sans">
              <Sparkles className="w-3.5 h-3.5" />
              <span>SMART REVISION SCHEDULER (منزل و دور کا خودکار نظام)</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
              اسمارٹ ریویژن شیڈولر • دہرائی و منزل نگران
            </h2>
            <p className="text-emerald-100 text-sm max-w-2xl leading-relaxed opacity-95">
              طلبہ کے ہر پارے کی آخری دہرائی، ریکارڈ شدہ اغلاط (اٹکنا، بھولنا، تجوید) اور ایام کی بنیاد پر خودکار الگورتھم جو بتاتا ہے کہ آج کس طالب علم کو کون سا پارہ سنانا ناگزیر ہے۔
            </p>
          </div>

          {/* Quick Actions */}
          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => onNavigateTab('mushaf')}
              className="flex items-center gap-2 bg-white/10 hover:bg-white/20 text-white font-bold py-2.5 px-4 rounded-2xl border border-white/20 transition-all cursor-pointer text-xs"
            >
              <BookOpen className="w-4 h-4 text-amber-300" />
              <span>مصحف شریف ٹریکر 📜</span>
            </button>
            <button
              onClick={() => onNavigateTab('hifz')}
              className="flex items-center gap-2 bg-amber-400 hover:bg-amber-500 text-emerald-950 font-bold py-2.5 px-4 rounded-2xl shadow-md transition-all cursor-pointer text-xs"
            >
              <Clock className="w-4 h-4" />
              <span>جامع تعلیمی ڈائری 📖</span>
            </button>
          </div>
        </div>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3.5">
        <div
          onClick={() => setUrgencyFilter('all')}
          className={`bg-white rounded-2xl p-4 border-2 transition-all cursor-pointer ${
            urgencyFilter === 'all' ? 'border-emerald-600 shadow-sm bg-emerald-50/40' : 'border-slate-100 hover:border-slate-300'
          }`}
        >
          <span className="text-xs text-slate-500 block">کل پارے منزل زیرِ نگرانی</span>
          <strong className="text-2xl font-black text-slate-900 font-mono mt-1 block">{stats.total}</strong>
          <span className="text-[11px] text-emerald-700 mt-0.5 block">تمام طلبہ کا مجموعہ</span>
        </div>

        <div
          onClick={() => setUrgencyFilter('critical')}
          className={`bg-white rounded-2xl p-4 border-2 transition-all cursor-pointer ${
            urgencyFilter === 'critical' ? 'border-rose-600 shadow-sm bg-rose-50/50' : 'border-slate-100 hover:border-rose-200'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs text-rose-700 font-bold">فوری دہرائی لازم 🔥</span>
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping"></span>
          </div>
          <strong className="text-2xl font-black text-rose-800 font-mono mt-1 block">{stats.critical}</strong>
          <span className="text-[11px] text-rose-600 mt-0.5 block">تاخیر یا زائد اغلاط</span>
        </div>

        <div
          onClick={() => setUrgencyFilter('high')}
          className={`bg-white rounded-2xl p-4 border-2 transition-all cursor-pointer ${
            urgencyFilter === 'high' ? 'border-amber-600 shadow-sm bg-amber-50/50' : 'border-slate-100 hover:border-amber-200'
          }`}
        >
          <span className="text-xs text-amber-800 font-bold block">قریب الوقوع (آج / کل) ⚡</span>
          <strong className="text-2xl font-black text-amber-900 font-mono mt-1 block">{stats.high}</strong>
          <span className="text-[11px] text-amber-700 mt-0.5 block">ایک ہفتہ سے زائد</span>
        </div>

        <div
          onClick={() => setUrgencyFilter('medium')}
          className={`bg-white rounded-2xl p-4 border-2 transition-all cursor-pointer ${
            urgencyFilter === 'medium' ? 'border-blue-600 shadow-sm bg-blue-50/50' : 'border-slate-100 hover:border-blue-200'
          }`}
        >
          <span className="text-xs text-blue-700 font-bold block">معمول کی دہرائی 🔄</span>
          <strong className="text-2xl font-black text-blue-900 font-mono mt-1 block">{stats.medium}</strong>
          <span className="text-[11px] text-blue-600 mt-0.5 block">۴ تا ۷ دن قبل</span>
        </div>

        <div
          onClick={() => setUrgencyFilter('fresh')}
          className={`bg-white rounded-2xl p-4 border-2 transition-all cursor-pointer ${
            urgencyFilter === 'fresh' ? 'border-emerald-600 shadow-sm bg-emerald-50/50' : 'border-slate-100 hover:border-emerald-200'
          }`}
        >
          <span className="text-xs text-emerald-800 font-bold block">تازہ و پختہ ✅</span>
          <strong className="text-2xl font-black text-emerald-950 font-mono mt-1 block">{stats.fresh}</strong>
          <span className="text-[11px] text-emerald-700 mt-0.5 block">حال ہی میں سنایا</span>
        </div>
      </div>

      {/* Control Filters Bar */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          {/* Student Selector */}
          <div className="flex flex-wrap items-center gap-3">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <User className="w-4 h-4 text-emerald-700" />
              <span>طالب علم منتخب کریں:</span>
            </label>
            <select
              value={selectedStudentFilter}
              onChange={(e) => setSelectedStudentFilter(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2 text-xs font-bold font-urdu focus:ring-2 focus:ring-emerald-600 outline-none"
            >
              <option value="all">تمام طلبہ ({hifzStudents.length} طلبہ)</option>
              {hifzStudents.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.nameUr} ({s.rollNo} - {s.completedParas || 0} پارے)
                </option>
              ))}
            </select>
          </div>

          {/* Daily Quota Selector */}
          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-600 font-bold">روزانہ ہدف دہرائی:</span>
            <div className="inline-flex rounded-xl bg-slate-100 p-1 border border-slate-200">
              <button
                onClick={() => setDailyQuota('half_para')}
                className={`px-3 py-1 rounded-lg font-bold transition-colors cursor-pointer ${
                  dailyQuota === 'half_para' ? 'bg-white text-emerald-900 shadow-xs' : 'text-slate-600'
                }`}
              >
                نصف پارہ / یوم
              </button>
              <button
                onClick={() => setDailyQuota('one_para')}
                className={`px-3 py-1 rounded-lg font-bold transition-colors cursor-pointer ${
                  dailyQuota === 'one_para' ? 'bg-white text-emerald-900 shadow-xs' : 'text-slate-600'
                }`}
              >
                ۱ پارہ / یوم (معیاری)
              </button>
              <button
                onClick={() => setDailyQuota('two_paras')}
                className={`px-3 py-1 rounded-lg font-bold transition-colors cursor-pointer ${
                  dailyQuota === 'two_paras' ? 'bg-white text-emerald-900 shadow-xs' : 'text-slate-600'
                }`}
              >
                ۲ پارے / یوم (پختہ)
              </button>
            </div>
          </div>

          {/* Search Box */}
          <div className="relative w-full lg:w-72">
            <Search className="w-4 h-4 absolute right-3.5 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="طالب علم، رول نمبر یا پارہ..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pr-10 pl-4 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-emerald-600 outline-none"
            />
          </div>
        </div>
      </div>

      {/* Revision Items Grid */}
      <div className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <h3 className="font-black text-base text-slate-900 flex items-center gap-2">
            <span>ترجیحی دہرائی فہرست ({filteredItems.length} پارے)</span>
            <span className="text-xs font-normal text-slate-500">
              (الگورتھم کی ترجیحی درجہ بندی کے تحت ترتیب شدہ)
            </span>
          </h3>
        </div>

        {filteredItems.length === 0 ? (
          <div className="p-12 text-center bg-white rounded-3xl border border-slate-200 space-y-3">
            <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-700 flex items-center justify-center text-2xl mx-auto">
              ✅
            </div>
            <h4 className="font-bold text-base text-slate-800">اس فلٹر کے تحت کوئی پارہ التواء میں نہیں ہے!</h4>
            <p className="text-xs text-slate-500">ماشاءاللہ تمام طلبہ کی دہرائی وقت پر مکمل اور پختہ ہے۔</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredItems.map((item, idx) => {
              const isUrgent = item.urgencyLevel === 'critical';
              const isHigh = item.urgencyLevel === 'high';

              return (
                <div
                  key={`${item.studentId}-${item.para}`}
                  className={`bg-white rounded-3xl p-5 border-2 transition-all flex flex-col justify-between space-y-4 shadow-xs hover:shadow-md ${
                    isUrgent
                      ? 'border-rose-200 hover:border-rose-400 bg-gradient-to-b from-rose-50/30 to-white'
                      : isHigh
                      ? 'border-amber-200 hover:border-amber-400 bg-gradient-to-b from-amber-50/20 to-white'
                      : 'border-slate-100 hover:border-emerald-300'
                  }`}
                >
                  {/* Card Header */}
                  <div className="flex items-start justify-between gap-3 border-b border-slate-100 pb-3">
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-12 h-12 rounded-2xl flex flex-col items-center justify-center font-black shrink-0 border ${
                          isUrgent
                            ? 'bg-rose-100 border-rose-300 text-rose-950'
                            : isHigh
                            ? 'bg-amber-100 border-amber-300 text-amber-950'
                            : 'bg-emerald-50 border-emerald-200 text-emerald-950'
                        }`}
                      >
                        <span className="text-[10px] opacity-75">پارہ</span>
                        <span className="text-lg font-mono font-bold -mt-1">{item.para}</span>
                      </div>
                      <div>
                        <h4 className="font-black text-base text-slate-900">{item.studentName}</h4>
                        <div className="flex items-center gap-2 text-xs text-slate-500">
                          <span className="font-mono">{item.studentRollNo}</span>
                          <span>•</span>
                          <span className="text-emerald-800 font-bold">{item.recommendedPages}</span>
                        </div>
                      </div>
                    </div>

                    <span
                      className={`px-2.5 py-1 rounded-xl text-[11px] font-bold font-sans border ${
                        isUrgent
                          ? 'bg-rose-100 text-rose-900 border-rose-200'
                          : isHigh
                          ? 'bg-amber-100 text-amber-900 border-amber-200'
                          : 'bg-emerald-100 text-emerald-900 border-emerald-200'
                      }`}
                    >
                      ترجیح: {item.urgencyScore}%
                    </span>
                  </div>

                  {/* Card Body Details */}
                  <div className="space-y-2 text-xs">
                    <div className="flex items-center justify-between text-slate-600">
                      <span>آخری دہرائی تاریخ:</span>
                      <strong className="text-slate-800 font-mono font-bold">
                        {item.lastReviewedDate || 'ریکارڈ موجود نہیں'} ({item.daysElapsed} دن قبل)
                      </strong>
                    </div>

                    <div className="flex items-center justify-between text-slate-600">
                      <span>سابقہ غلطیاں:</span>
                      <span
                        className={`px-2 py-0.5 rounded font-mono font-bold ${
                          item.mistakesCount > 3 ? 'bg-rose-100 text-rose-900' : 'bg-slate-100 text-slate-800'
                        }`}
                      >
                        {item.mistakesCount} اغلاط
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-slate-600">
                      <span>حفظ معیار:</span>
                      <span className="font-bold text-emerald-900 bg-emerald-50 px-2 py-0.5 rounded">
                        {item.lastQuality}
                      </span>
                    </div>

                    <div
                      className={`p-2.5 rounded-xl border text-[11px] font-bold leading-relaxed ${
                        isUrgent
                          ? 'bg-rose-50 border-rose-200 text-rose-900'
                          : isHigh
                          ? 'bg-amber-50 border-amber-200 text-amber-900'
                          : 'bg-emerald-50 border-emerald-100 text-emerald-900'
                      }`}
                    >
                      💡 {item.recommendationUr}
                    </div>
                  </div>

                  {/* Card Footer Actions */}
                  <div className="border-t border-slate-100 pt-3 flex items-center justify-between gap-2">
                    {onAddDiaryEntry && (
                      <button
                        onClick={() => setQuickLogPara(item)}
                        className="flex-1 bg-[#0F5D2F] hover:bg-emerald-800 text-white font-bold py-2 px-3 rounded-xl text-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-xs"
                      >
                        <CheckCircle className="w-3.5 h-3.5" />
                        <span>آج سنا گیا لاگ کریں</span>
                      </button>
                    )}

                    <button
                      onClick={() => handleSendWhatsAppSchedule(item)}
                      title="سرپرست کو واٹس ایپ الرٹ بھیجیں"
                      className="p-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-xl transition-colors cursor-pointer border border-emerald-200"
                    >
                      <Send className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => onNavigateTab('mushaf')}
                      title="مصحف میں دیکھیں"
                      className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl transition-colors cursor-pointer"
                    >
                      <BookOpen className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Quick Revision Log Modal */}
      {quickLogPara && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4 font-urdu text-right animate-in fade-in zoom-in duration-200">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="font-black text-lg text-emerald-950">دہرائی و منزل لاگ اندراج</h3>
                <p className="text-xs text-slate-500">
                  {quickLogPara.studentName} ({quickLogPara.studentRollNo}) • پارہ {quickLogPara.para}
                </p>
              </div>
              <button
                onClick={() => setQuickLogPara(null)}
                className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleQuickLogSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">دہرائی کا معیار (Quality):</label>
                <div className="grid grid-cols-3 gap-2">
                  {(['بہترین', 'بہتر', 'مناسب'] as const).map((q) => (
                    <button
                      key={q}
                      type="button"
                      onClick={() => setQuickLogQuality(q)}
                      className={`py-2 rounded-xl font-bold cursor-pointer transition-all border ${
                        quickLogQuality === q
                          ? 'bg-emerald-800 text-white border-emerald-900 shadow-xs'
                          : 'bg-slate-50 border-slate-200 text-slate-700'
                      }`}
                    >
                      {q}
                    </button>
                  ))}
                </div>
              </div>

              {/* Mistakes Counter */}
              <div>
                <label className="block font-bold text-slate-700 mb-1.5">اغلاط کی تفصیل:</label>
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div className="p-2 rounded-xl bg-amber-50 border border-amber-200">
                    <span className="block text-[11px] text-amber-900 font-bold mb-1">اٹکنا</span>
                    <div className="flex items-center justify-center gap-2">
                      <button
                        type="button"
                        onClick={() =>
                          setQuickLogMistakes((m) => ({ ...m, atakna: Math.max(0, m.atakna - 1) }))
                        }
                        className="w-6 h-6 rounded bg-white text-slate-800 font-bold border"
                      >
                        -
                      </button>
                      <span className="font-mono font-bold text-base">{quickLogMistakes.atakna}</span>
                      <button
                        type="button"
                        onClick={() => setQuickLogMistakes((m) => ({ ...m, atakna: m.atakna + 1 }))}
                        className="w-6 h-6 rounded bg-white text-slate-800 font-bold border"
                      >
                        +
                      </button>
                    </div>
                  </div>

                  <div className="p-2 rounded-xl bg-rose-50 border border-rose-200">
                    <span className="block text-[11px] text-rose-900 font-bold mb-1">بھولنا</span>
                    <div className="flex items-center justify-center gap-2">
                      <button
                        type="button"
                        onClick={() =>
                          setQuickLogMistakes((m) => ({ ...m, bhoolna: Math.max(0, m.bhoolna - 1) }))
                        }
                        className="w-6 h-6 rounded bg-white text-slate-800 font-bold border"
                      >
                        -
                      </button>
                      <span className="font-mono font-bold text-base">{quickLogMistakes.bhoolna}</span>
                      <button
                        type="button"
                        onClick={() => setQuickLogMistakes((m) => ({ ...m, bhoolna: m.bhoolna + 1 }))}
                        className="w-6 h-6 rounded bg-white text-slate-800 font-bold border"
                      >
                        +
                      </button>
                    </div>
                  </div>

                  <div className="p-2 rounded-xl bg-blue-50 border border-blue-200">
                    <span className="block text-[11px] text-blue-900 font-bold mb-1">تجوید</span>
                    <div className="flex items-center justify-center gap-2">
                      <button
                        type="button"
                        onClick={() =>
                          setQuickLogMistakes((m) => ({ ...m, tajweed: Math.max(0, m.tajweed - 1) }))
                        }
                        className="w-6 h-6 rounded bg-white text-slate-800 font-bold border"
                      >
                        -
                      </button>
                      <span className="font-mono font-bold text-base">{quickLogMistakes.tajweed}</span>
                      <button
                        type="button"
                        onClick={() => setQuickLogMistakes((m) => ({ ...m, tajweed: m.tajweed + 1 }))}
                        className="w-6 h-6 rounded bg-white text-slate-800 font-bold border"
                      >
                        +
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">استاد کا تبصرہ:</label>
                <input
                  type="text"
                  value={quickLogRemarks}
                  onChange={(e) => setQuickLogRemarks(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white text-xs outline-none"
                />
              </div>

              <div className="flex items-center gap-3 pt-3 border-t border-slate-100">
                <button
                  type="submit"
                  className="flex-1 bg-[#0F5D2F] hover:bg-emerald-800 text-white font-bold py-2.5 px-4 rounded-xl cursor-pointer shadow-xs transition-colors"
                >
                  دہرائی محفوظ کریں ✅
                </button>
                <button
                  type="button"
                  onClick={() => setQuickLogPara(null)}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold cursor-pointer"
                >
                  منسوخ
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
