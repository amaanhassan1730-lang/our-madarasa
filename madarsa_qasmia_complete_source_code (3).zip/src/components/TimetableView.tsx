import React, { useState } from 'react';
import { TimetableSchedule, StudentClass, UserRole } from '../types';
import { translations, Language } from '../i18n/translations';
import {
  CalendarDays,
  PlusCircle,
  Clock,
  BookOpen,
  User,
  MapPin,
  Printer,
  Trash2,
  X,
  Edit,
} from 'lucide-react';

interface TimetableViewProps {
  timetable: TimetableSchedule[];
  onUpdateTimetable: (timetable: TimetableSchedule[]) => void;
  lang: Language;
  currentRole: UserRole;
}

export const TimetableView: React.FC<TimetableViewProps> = ({
  timetable,
  onUpdateTimetable,
  lang,
  currentRole,
}) => {
  const t = translations[lang];
  const [selectedClass, setSelectedClass] = useState<StudentClass>('Hifz');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<TimetableSchedule | null>(null);

  const [formData, setFormData] = useState({
    class: 'Hifz' as StudentClass,
    periodNameUr: 'پیریڈ 1',
    periodNameEn: 'Period 1',
    timeRange: '08:00 AM - 09:30 AM',
    subjectUr: '',
    subjectEn: '',
    teacherUr: '',
    teacherEn: '',
    room: 'مرکزی ہال',
  });

  const filteredItems = timetable.filter((item) => item.class === selectedClass);

  const handleOpenAdd = () => {
    setEditingItem(null);
    setFormData({
      class: selectedClass,
      periodNameUr: `پیریڈ ${filteredItems.length + 1}`,
      periodNameEn: `Period ${filteredItems.length + 1}`,
      timeRange: '08:00 AM - 09:30 AM',
      subjectUr: '',
      subjectEn: '',
      teacherUr: '',
      teacherEn: '',
      room: 'مرکزی درسگاہ',
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (item: TimetableSchedule) => {
    setEditingItem(item);
    setFormData({
      class: item.class,
      periodNameUr: item.periodNameUr,
      periodNameEn: item.periodNameEn,
      timeRange: item.timeRange,
      subjectUr: item.subjectUr,
      subjectEn: item.subjectEn,
      teacherUr: item.teacherUr,
      teacherEn: item.teacherEn,
      room: item.room,
    });
    setIsModalOpen(true);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('کیا آپ واقعی یہ پیریڈ شیڈول سے خارج کرنا چاہتے ہیں؟')) {
      onUpdateTimetable(timetable.filter((item) => item.id !== id));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.subjectUr.trim()) return;

    if (editingItem) {
      const updated = timetable.map((it) =>
        it.id === editingItem.id ? { ...it, ...formData } : it
      );
      onUpdateTimetable(updated);
    } else {
      const newItem: TimetableSchedule = {
        id: `tt-${Date.now()}`,
        ...formData,
      };
      onUpdateTimetable([...timetable, newItem]);
    }

    setIsModalOpen(false);
  };

  const canEdit = currentRole === 'admin' || currentRole === 'ustad';

  return (
    <div className="space-y-6 animate-in fade-in duration-300 font-urdu">
      {/* Top Banner */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-900 flex items-center justify-center text-3xl shadow-inner">
            🗓️
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-emerald-950 font-urdu">
              {t.timetableTitle}
            </h2>
            <p className="text-xs text-slate-500 font-urdu">
              {lang === 'ur'
                ? 'تمام درجات کے اوقاتِ تدریس، مضامین، اساتذہ اور درسگاہیں'
                : 'Class schedules, Islamic subjects, assigned Ustads & rooms'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {canEdit && (
            <button
              onClick={handleOpenAdd}
              id="add-period-btn"
              className="flex items-center gap-2 bg-[#0F5D2F] hover:bg-emerald-800 text-white font-black px-4 py-2.5 rounded-2xl shadow-sm transition-all active:scale-95 cursor-pointer text-xs sm:text-sm"
            >
              <PlusCircle className="w-4 h-4 text-amber-400" />
              <span>{t.addNewPeriod}</span>
            </button>
          )}

          <button
            onClick={() => window.print()}
            className="flex items-center gap-1.5 px-3.5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-2xl transition-colors cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>پرنٹ 🖨️</span>
          </button>
        </div>
      </div>

      {/* Class Selector Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 pb-3">
        {[
          { id: 'Hifz', label: t.classHifz, icon: '📖' },
          { id: 'Nazra', label: t.classNazra, icon: '📜' },
          { id: 'Qaida', label: t.classQaida, icon: '🔤' },
          { id: 'Alim', label: t.classAlim, icon: '🎓' },
          { id: 'Deeniat', label: t.classDeeniat, icon: '🕌' },
        ].map((c) => (
          <button
            key={c.id}
            onClick={() => setSelectedClass(c.id as StudentClass)}
            className={`flex items-center gap-2 px-4 py-2 rounded-2xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
              selectedClass === c.id
                ? 'bg-[#0F5D2F] text-white shadow-sm ring-2 ring-emerald-600/30'
                : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
            }`}
          >
            <span>{c.icon}</span>
            <span>{c.label}</span>
          </button>
        ))}
      </div>

      {/* Timetable Periods Timeline / Cards */}
      <div className="space-y-3">
        {filteredItems.length === 0 ? (
          <div className="bg-white rounded-3xl p-12 text-center text-slate-400 border border-slate-200 text-xs">
            اس درجہ کے لیے ابھی اوقات کار درج نہیں کیے گئے۔ نیا پیریڈ شامل کرنے کے لیے اوپر بٹن دبائیں۔
          </div>
        ) : (
          filteredItems.map((period, idx) => (
            <div
              key={period.id}
              className="bg-white rounded-2xl p-4.5 border border-slate-200 hover:border-emerald-300 shadow-xs transition-all flex flex-wrap items-center justify-between gap-4"
            >
              {/* Period Number & Time */}
              <div className="flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-900 font-mono font-bold flex items-center justify-center text-base border border-amber-300 shrink-0">
                  #{idx + 1}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-base text-emerald-950">
                      {period.periodNameUr}
                    </span>
                    <span className="flex items-center gap-1 text-xs font-mono text-slate-600 bg-slate-100 px-2 py-0.5 rounded-md">
                      <Clock className="w-3.5 h-3.5 text-emerald-700" />
                      <span dir="ltr">{period.timeRange}</span>
                    </span>
                  </div>
                  <h4 className="font-bold text-slate-900 text-sm mt-1">
                    {period.subjectUr}
                  </h4>
                </div>
              </div>

              {/* Teacher & Room */}
              <div className="flex items-center gap-4 text-xs text-slate-600">
                <div className="flex items-center gap-1.5 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-100">
                  <User className="w-3.5 h-3.5 text-emerald-700" />
                  <span>
                    استاد: <strong>{period.teacherUr}</strong>
                  </span>
                </div>

                <div className="flex items-center gap-1.5 bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-200">
                  <MapPin className="w-3.5 h-3.5 text-amber-600" />
                  <span>{period.room}</span>
                </div>

                {canEdit && (
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleOpenEdit(period)}
                      className="p-1.5 bg-slate-100 hover:bg-blue-100 text-slate-600 hover:text-blue-800 rounded-lg transition-colors cursor-pointer"
                    >
                      <Edit className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleDelete(period.id)}
                      className="p-1.5 bg-slate-100 hover:bg-rose-100 text-slate-600 hover:text-rose-800 rounded-lg transition-colors cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))
        )}
      </div>

      {/* Add / Edit Period Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-md overflow-hidden animate-in fade-in duration-200">
            <div className="bg-[#0F5D2F] text-white p-5 flex items-center justify-between border-b-4 border-amber-500">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center text-2xl">
                  🗓️
                </div>
                <div>
                  <h3 className="font-bold text-lg font-urdu">
                    {editingItem ? 'پیریڈ میں ترمیم کریں' : t.addNewPeriod}
                  </h3>
                  <p className="text-xs text-emerald-200 font-urdu">درجہ: {selectedClass}</p>
                </div>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4 font-urdu">
              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">
                  پیریڈ کا نام (اردو):
                </label>
                <input
                  type="text"
                  required
                  value={formData.periodNameUr}
                  onChange={(e) => setFormData({ ...formData, periodNameUr: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">
                  اوقات کار (وقت):
                </label>
                <input
                  type="text"
                  required
                  placeholder="08:00 AM - 09:30 AM"
                  value={formData.timeRange}
                  onChange={(e) => setFormData({ ...formData, timeRange: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-sm"
                  dir="ltr"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">
                  مضمون / سرگرمی (Subject):
                </label>
                <input
                  type="text"
                  required
                  placeholder="مثال: حفظ قرآن، تجوید مشق، عربی نحو"
                  value={formData.subjectUr}
                  onChange={(e) => setFormData({ ...formData, subjectUr: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">
                    استاد محترم کا نام:
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: قاری عبد الوحید"
                    value={formData.teacherUr}
                    onChange={(e) => setFormData({ ...formData, teacherUr: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">
                    کمرہ / درسگاہ (Room):
                  </label>
                  <input
                    type="text"
                    placeholder="مرکزی ہال"
                    value={formData.room}
                    onChange={(e) => setFormData({ ...formData, room: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
                  />
                </div>
              </div>

              <div className="flex items-center gap-3 pt-3 border-t border-slate-200">
                <button
                  type="submit"
                  className="flex-1 bg-[#0F5D2F] hover:bg-emerald-800 text-white font-bold py-3 px-6 rounded-2xl shadow-md transition-all cursor-pointer"
                >
                  {t.save}
                </button>
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-5 py-3 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-sm cursor-pointer"
                >
                  {t.cancel}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
