import React from 'react';
import { Student, FeePayment, DonationRecord, ExamRecord, SystemSettings } from '../types';
import { translations, Language } from '../i18n/translations';
import { Printer, X } from 'lucide-react';

export type PrintDocumentType =
  | { type: 'id_card'; student: Student }
  | { type: 'fee_receipt'; payment: FeePayment; student: Student }
  | { type: 'donation_voucher'; donation: DonationRecord }
  | { type: 'result_card'; exam: ExamRecord; student: Student };

interface PrintModalProps {
  isOpen: boolean;
  onClose: () => void;
  documentData: PrintDocumentType | null;
  settings: SystemSettings;
  lang: Language;
}

export const PrintModal: React.FC<PrintModalProps> = ({
  isOpen,
  onClose,
  documentData,
  settings,
  lang,
}) => {
  if (!isOpen || !documentData) return null;
  const t = translations[lang];

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden animate-in fade-in duration-200">
        {/* Modal Controls Bar */}
        <div className="no-print bg-emerald-800 text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-2 font-urdu font-bold">
            <Printer className="w-5 h-5 text-amber-400" />
            <span>
              {documentData.type === 'id_card' && (lang === 'ur' ? 'شناختی کارڈ پرنٹ کا منظر' : 'Student ID Card Preview')}
              {documentData.type === 'fee_receipt' && (lang === 'ur' ? 'فیس رسید کا پرنٹ منظر' : 'Fee Receipt Preview')}
              {documentData.type === 'donation_voucher' && (lang === 'ur' ? 'چندہ رسید کا پرنٹ منظر' : 'Donation Voucher Preview')}
              {documentData.type === 'result_card' && (lang === 'ur' ? 'امتحانی رزلٹ کارڈ و سند' : 'Official Examination Result Card')}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="bg-amber-400 hover:bg-amber-500 text-emerald-950 font-bold px-4 py-1.5 rounded-xl text-sm transition-all flex items-center gap-1.5 shadow-sm cursor-pointer font-urdu"
            >
              <Printer className="w-4 h-4" />
              <span>{t.print}</span>
            </button>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Area Target */}
        <div id="printable-area" className="p-6 sm:p-8 bg-white text-slate-900">
          {/* 1. STUDENT ID CARD */}
          {documentData.type === 'id_card' && (
            <div className="max-w-md mx-auto border-4 border-[#0F5D2F] rounded-3xl p-6 shadow-md bg-linear-to-b from-[#E8F5E9]/50 via-white to-[#E8F5E9]/30 relative overflow-hidden">
              {/* Islamic Decorative Corners */}
              <div className="absolute top-0 right-0 w-16 h-16 bg-[#0F5D2F] text-amber-400 flex items-start justify-end p-2 rounded-bl-3xl">
                <span className="text-xl">🕌</span>
              </div>
              <div className="absolute bottom-0 left-0 w-16 h-16 bg-[#0F5D2F] text-amber-400 flex items-end justify-start p-2 rounded-tr-3xl">
                <span className="text-xl">📖</span>
              </div>

              {/* Madrasa Title Header */}
              <div className="text-center pb-4 border-b-2 border-emerald-700/30">
                <div className="text-xs font-arabic text-emerald-800">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</div>
                <h2 className="text-2xl font-black text-[#0F5D2F] font-urdu tracking-wide">
                  {settings.madrasaNameUr}
                </h2>
                <p className="text-xs text-slate-600 font-sans font-bold">{settings.madrasaNameEn}</p>
                <span className="inline-block mt-2 bg-amber-500 text-emerald-950 text-xs font-black px-3 py-0.5 rounded-full font-urdu">
                  طالب علم شناختی کارڈ / STUDENT ID CARD
                </span>
              </div>

              {/* Student Details with Photo Badge */}
              <div className="flex items-center gap-5 py-5">
                {/* Photo Placeholder / Avatar */}
                <div className="w-24 h-28 rounded-2xl border-2 border-emerald-600 bg-emerald-50 flex flex-col items-center justify-center text-slate-400 shrink-0 relative overflow-hidden shadow-inner">
                  <span className="text-4xl">🎓</span>
                  <span className="text-[9px] font-bold text-emerald-800 mt-1 uppercase tracking-wider">
                    {documentData.student.rollNo}
                  </span>
                </div>

                {/* Info List */}
                <div className="space-y-1.5 text-sm font-urdu flex-1">
                  <div>
                    <span className="text-xs text-slate-500 block">طالب علم کا نام:</span>
                    <span className="font-bold text-base text-emerald-950">
                      {documentData.student.nameUr}
                    </span>
                    <span className="text-xs text-slate-500 block font-sans font-medium">
                      {documentData.student.nameEn}
                    </span>
                  </div>

                  <div>
                    <span className="text-xs text-slate-500 block">والد کا نام:</span>
                    <span className="font-bold text-slate-800">
                      {documentData.student.fatherNameUr}
                    </span>
                  </div>

                  <div className="flex items-center justify-between pt-1">
                    <div>
                      <span className="text-xs text-slate-500 block">درجہ / کلاس:</span>
                      <span className="font-bold text-emerald-800 px-2 py-0.5 bg-emerald-100 rounded-md text-xs">
                        {documentData.student.class}
                      </span>
                    </div>
                    <div>
                      <span className="text-xs text-slate-500 block">قیام گاہ:</span>
                      <span className="font-bold text-amber-800 px-2 py-0.5 bg-amber-100 rounded-md text-xs">
                        {documentData.student.isHostel ? 'مقیم (ہاسٹل)' : 'غیر مقیم'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Footer with Contact & Principal Stamp Area */}
              <div className="border-t border-emerald-700/20 pt-3 flex items-center justify-between text-xs">
                <div>
                  <span className="text-slate-500 block font-urdu">سرپرست رابطہ نمبر:</span>
                  <span className="font-mono font-bold text-emerald-900" dir="ltr">
                    {documentData.student.parentMobile}
                  </span>
                </div>
                <div className="text-center font-urdu">
                  <div className="w-20 border-b border-dashed border-slate-400 mb-1"></div>
                  <span className="text-[10px] text-slate-500">دستخط ناظم / مہر</span>
                </div>
              </div>
            </div>
          )}

          {/* 2. FEE RECEIPT VOUCHER */}
          {documentData.type === 'fee_receipt' && (
            <div className="border-2 border-emerald-800 rounded-2xl p-6 bg-white space-y-4">
              {/* Receipt Header */}
              <div className="flex items-start justify-between border-b-2 border-emerald-700 pb-3">
                <div>
                  <div className="text-xs font-arabic text-emerald-800">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</div>
                  <h2 className="text-2xl font-black text-emerald-900 font-urdu">{settings.madrasaNameUr}</h2>
                  <p className="text-xs text-slate-600 font-sans">{settings.madrasaNameEn}</p>
                  <p className="text-xs text-slate-500 font-urdu mt-0.5">{settings.addressUr} - فون: {settings.phone}</p>
                </div>
                <div className="text-right">
                  <span className="inline-block bg-emerald-100 text-emerald-900 font-black px-3 py-1 rounded-lg text-xs font-urdu border border-emerald-300">
                    رسید فیس / FEE RECEIPT
                  </span>
                  <div className="text-xs text-slate-600 mt-2 font-mono">
                    <strong>رسید نمبر:</strong> {documentData.payment.receiptNo}
                  </div>
                  <div className="text-xs text-slate-600 font-mono">
                    <strong>تاریخ:</strong> {documentData.payment.date}
                  </div>
                </div>
              </div>

              {/* Student Details Banner */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-emerald-50/60 p-3 rounded-xl text-xs font-urdu border border-emerald-100">
                <div>
                  <span className="text-slate-500 block">نام طالب علم:</span>
                  <strong className="text-emerald-950 text-sm">{documentData.student.nameUr}</strong>
                </div>
                <div>
                  <span className="text-slate-500 block">رول نمبر:</span>
                  <strong className="font-mono text-emerald-950">{documentData.student.rollNo}</strong>
                </div>
                <div>
                  <span className="text-slate-500 block">والد کا نام:</span>
                  <strong>{documentData.student.fatherNameUr}</strong>
                </div>
                <div>
                  <span className="text-slate-500 block">کلاس:</span>
                  <strong className="text-emerald-800">{documentData.student.class}</strong>
                </div>
              </div>

              {/* Fee Breakdown Table */}
              <table className="w-full text-right text-xs border border-slate-200">
                <thead className="bg-emerald-800 text-white font-urdu">
                  <tr>
                    <th className="p-2.5">شمار</th>
                    <th className="p-2.5">تفصیلِ فیس</th>
                    <th className="p-2.5">برائے مہینہ</th>
                    <th className="p-2.5 text-left">رقم (روپے)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 font-urdu">
                  {documentData.payment.tuitionFee > 0 && (
                    <tr>
                      <td className="p-2.5 text-center">1</td>
                      <td className="p-2.5 font-bold">تعلیمی ماہانہ فیس (Tuition Fee)</td>
                      <td className="p-2.5">{documentData.payment.month}</td>
                      <td className="p-2.5 text-left font-mono font-bold">{documentData.payment.tuitionFee}</td>
                    </tr>
                  )}
                  {documentData.payment.booksFee > 0 && (
                    <tr>
                      <td className="p-2.5 text-center">2</td>
                      <td className="p-2.5 font-bold">کتب، قاعدہ و اسٹیشنری</td>
                      <td className="p-2.5">-</td>
                      <td className="p-2.5 text-left font-mono font-bold">{documentData.payment.booksFee}</td>
                    </tr>
                  )}
                  {documentData.payment.hostelFee > 0 && (
                    <tr>
                      <td className="p-2.5 text-center">3</td>
                      <td className="p-2.5 font-bold">قیام و طعام (ہاسٹل و میس فیس)</td>
                      <td className="p-2.5">{documentData.payment.month}</td>
                      <td className="p-2.5 text-left font-mono font-bold">{documentData.payment.hostelFee}</td>
                    </tr>
                  )}
                  {documentData.payment.transportFee > 0 && (
                    <tr>
                      <td className="p-2.5 text-center">4</td>
                      <td className="p-2.5 font-bold">ٹرانسپورٹ فیس</td>
                      <td className="p-2.5">{documentData.payment.month}</td>
                      <td className="p-2.5 text-left font-mono font-bold">{documentData.payment.transportFee}</td>
                    </tr>
                  )}
                  {documentData.payment.discount > 0 && (
                    <tr className="text-emerald-700 bg-emerald-50/50">
                      <td className="p-2.5 text-center">5</td>
                      <td className="p-2.5 font-bold">رعایت / وظیفہ (Discount)</td>
                      <td className="p-2.5">-</td>
                      <td className="p-2.5 text-left font-mono font-bold">-{documentData.payment.discount}</td>
                    </tr>
                  )}
                </tbody>
                <tfoot className="bg-emerald-100 font-urdu border-t-2 border-emerald-800">
                  <tr>
                    <td colSpan={3} className="p-2.5 font-black text-sm text-emerald-950">
                      کل وصول شدہ رقم:
                    </td>
                    <td className="p-2.5 text-left font-mono font-black text-base text-emerald-950">
                      {documentData.payment.totalPaid} روپے
                    </td>
                  </tr>
                </tfoot>
              </table>

              {/* Payment Mode & Signatures */}
              <div className="flex items-center justify-between text-xs pt-4 font-urdu">
                <div>
                  <span className="text-slate-500 block">طریقہ ادائیگی:</span>
                  <span className="font-bold text-slate-800">{documentData.payment.paymentMethod}</span>
                  <span className="text-slate-500 block mt-1">وصول کنندہ: {documentData.payment.collectedBy}</span>
                </div>
                <div className="text-center">
                  <div className="w-28 border-b border-dashed border-slate-600 mb-1"></div>
                  <span className="text-[11px] text-slate-600">دستخط محاسب / مہر مدرسہ</span>
                </div>
              </div>
            </div>
          )}

          {/* 3. CHANDA & DONATION VOUCHER */}
          {documentData.type === 'donation_voucher' && (
            <div className="border-2 border-emerald-800 rounded-2xl p-6 bg-white space-y-4">
              <div className="flex items-start justify-between border-b-2 border-emerald-700 pb-3">
                <div>
                  <div className="text-xs font-arabic text-emerald-800">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</div>
                  <h2 className="text-2xl font-black text-emerald-900 font-urdu">{settings.madrasaNameUr}</h2>
                  <p className="text-xs text-slate-600 font-sans">{settings.madrasaNameEn}</p>
                </div>
                <div className="text-right">
                  <span className="inline-block bg-amber-100 text-amber-950 font-black px-3 py-1 rounded-lg text-xs font-urdu border border-amber-300">
                    رسید برائے چندہ و عطیات
                  </span>
                  <div className="text-xs text-slate-600 mt-2 font-mono">
                    <strong>واؤچر نمبر:</strong> {documentData.donation.voucherNo}
                  </div>
                  <div className="text-xs text-slate-600 font-mono">
                    <strong>تاریخ:</strong> {documentData.donation.date}
                  </div>
                </div>
              </div>

              <div className="space-y-3 font-urdu text-sm bg-emerald-50/50 p-4 rounded-xl border border-emerald-100">
                <div className="flex items-center justify-between">
                  <span className="text-slate-600">نام محترم عطیہ دہندہ:</span>
                  <strong className="text-base text-emerald-950">{documentData.donation.donorName}</strong>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-600">رابطہ فون نمبر:</span>
                  <span className="font-mono text-slate-800" dir="ltr">{documentData.donation.donorPhone}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-600">مد / کھاتہ:</span>
                  <span className="px-3 py-1 bg-emerald-200 text-emerald-900 rounded-full font-bold text-xs">
                    {documentData.donation.category === 'Lillah' && 'للہ فنڈ'}
                    {documentData.donation.category === 'Zakat' && 'زکوٰۃ فنڈ'}
                    {documentData.donation.category === 'Building' && 'تعمیراتی فنڈ'}
                    {documentData.donation.category === 'Sadqah' && 'عام صدقہ و عطیہ'}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-600">مقصد / خصوصی دعا:</span>
                  <span className="text-slate-800 font-medium">{documentData.donation.purpose || 'تعاون برائے دین اسلام'}</span>
                </div>
                <div className="flex items-center justify-between border-t border-emerald-200 pt-3">
                  <span className="font-black text-base text-emerald-950">کل وصول شدہ رقم:</span>
                  <span className="font-mono font-black text-xl text-emerald-900">
                    {documentData.donation.amount.toLocaleString()} روپے
                  </span>
                </div>
              </div>

              <div className="text-xs text-slate-600 italic font-urdu text-center py-1">
                "جزاکم اللہ خیراً و احسن الجزاء فی الدارین - اللہ رب العزت آپ کے اس تعاون کو اپنی بارگاہ میں قبول فرمائے"
              </div>

              <div className="flex items-center justify-between text-xs pt-4 font-urdu border-t border-slate-200">
                <div>
                  <span>وصول کنندہ: <strong>{documentData.donation.collectorName}</strong></span>
                  <span className="block text-slate-500">ادائیگی ذریعہ: {documentData.donation.paymentMode}</span>
                </div>
                <div className="text-center">
                  <div className="w-28 border-b border-dashed border-slate-600 mb-1"></div>
                  <span className="text-[11px] text-slate-600">دستخط و مہر</span>
                </div>
              </div>
            </div>
          )}

          {/* 4. EXAMINATION RESULT CARD & CERTIFICATE */}
          {documentData.type === 'result_card' && (
            <div className="max-w-2xl mx-auto border-8 border-double border-[#0F5D2F] rounded-3xl p-6 sm:p-8 bg-linear-to-b from-[#F9FBF9] via-white to-[#F0F7F2] relative overflow-hidden shadow-xl">
              {/* Islamic Decorative Header */}
              <div className="text-center pb-4 border-b-2 border-emerald-800/30 relative">
                <div className="text-xs font-arabic text-emerald-800 font-bold tracking-widest">
                  بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
                </div>
                <div className="text-sm font-arabic text-amber-700 font-bold my-1">
                  ﴿ وَقُلْ رَبِّ زِدْنِي عِلْمًا ﴾
                </div>
                <h2 className="text-2xl sm:text-3xl font-black text-[#0F5D2F] font-urdu tracking-wide">
                  {settings.madrasaNameUr}
                </h2>
                <p className="text-xs text-slate-600 font-sans font-bold">{settings.madrasaNameEn}</p>
                <div className="mt-2 inline-block bg-[#0F5D2F] text-amber-300 font-urdu font-black text-sm px-6 py-1 rounded-full shadow-xs border border-amber-400">
                  {documentData.exam.examNameUr} / سال 2026ء
                </div>
              </div>

              {/* Student Metadata Box */}
              <div className="grid grid-cols-2 gap-3 my-4 p-4 rounded-2xl bg-white border border-emerald-200 shadow-2xs font-urdu text-sm">
                <div>
                  <span className="text-xs text-slate-500 block">طالب علم کا نام:</span>
                  <strong className="text-base text-emerald-950 block">{documentData.student.nameUr}</strong>
                  <span className="text-xs text-slate-500 font-sans font-medium">{documentData.student.nameEn}</span>
                </div>
                <div>
                  <span className="text-xs text-slate-500 block">والدِ محترم کا نام:</span>
                  <strong className="text-base text-slate-800 block">{documentData.student.fatherNameUr}</strong>
                  <span className="text-xs text-slate-500 font-sans font-medium">{documentData.student.fatherNameEn}</span>
                </div>
                <div>
                  <span className="text-xs text-slate-500 block">رول نمبر:</span>
                  <span className="font-mono font-bold text-emerald-900 bg-emerald-50 px-2.5 py-0.5 rounded-md text-xs">
                    {documentData.student.rollNo}
                  </span>
                </div>
                <div>
                  <span className="text-xs text-slate-500 block">درجہ / کلاس:</span>
                  <span className="font-bold text-slate-800">{documentData.student.class}</span>
                </div>
              </div>

              {/* Marks Table */}
              <div className="overflow-hidden rounded-2xl border border-emerald-300 shadow-2xs mb-4 font-urdu text-sm">
                <table className="w-full text-right border-collapse">
                  <thead className="bg-[#0F5D2F] text-white text-xs">
                    <tr>
                      <th className="p-2.5 text-right font-bold">نمبر شمار</th>
                      <th className="p-2.5 text-right font-bold">مضمون / شعبہ</th>
                      <th className="p-2.5 text-center font-bold">کل نمبر</th>
                      <th className="p-2.5 text-center font-bold">حاصل کردہ نمبر</th>
                      <th className="p-2.5 text-center font-bold">کیفیت</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-emerald-100 bg-white text-slate-800 text-xs">
                    <tr>
                      <td className="p-2.5 text-slate-500 font-mono">1</td>
                      <td className="p-2.5 font-bold text-emerald-950">حفظ القرآن / تلاوت</td>
                      <td className="p-2.5 text-center font-mono">100</td>
                      <td className="p-2.5 text-center font-mono font-bold text-emerald-900">{documentData.exam.hifzMarks}</td>
                      <td className="p-2.5 text-center text-emerald-700 font-bold">{documentData.exam.hifzMarks >= 80 ? 'بہترین' : 'تسلی بخش'}</td>
                    </tr>
                    <tr className="bg-slate-50/50">
                      <td className="p-2.5 text-slate-500 font-mono">2</td>
                      <td className="p-2.5 font-bold text-emerald-950">تجوید، ترتیل و مخارج الحروف</td>
                      <td className="p-2.5 text-center font-mono">50</td>
                      <td className="p-2.5 text-center font-mono font-bold text-emerald-900">{documentData.exam.tajweedMarks}</td>
                      <td className="p-2.5 text-center text-emerald-700 font-bold">{documentData.exam.tajweedMarks >= 40 ? 'بہترین' : 'تسلی بخش'}</td>
                    </tr>
                    <tr>
                      <td className="p-2.5 text-slate-500 font-mono">3</td>
                      <td className="p-2.5 font-bold text-emerald-950">ناظرہ و روانی</td>
                      <td className="p-2.5 text-center font-mono">50</td>
                      <td className="p-2.5 text-center font-mono font-bold text-emerald-900">{documentData.exam.nazraMarks}</td>
                      <td className="p-2.5 text-center text-emerald-700 font-bold">{documentData.exam.nazraMarks >= 40 ? 'بہترین' : 'تسلی بخش'}</td>
                    </tr>
                    <tr className="bg-slate-50/50">
                      <td className="p-2.5 text-slate-500 font-mono">4</td>
                      <td className="p-2.5 font-bold text-emerald-950">دینیات، مسنون دعائیں و فقہی مسائل</td>
                      <td className="p-2.5 text-center font-mono">50</td>
                      <td className="p-2.5 text-center font-mono font-bold text-emerald-900">{documentData.exam.deeniyatMarks}</td>
                      <td className="p-2.5 text-center text-emerald-700 font-bold">{documentData.exam.deeniyatMarks >= 40 ? 'بہترین' : 'تسلی بخش'}</td>
                    </tr>
                    <tr>
                      <td className="p-2.5 text-slate-500 font-mono">5</td>
                      <td className="p-2.5 font-bold text-emerald-950">حسنِ خط، پابندیِ نماز و اخلاقیات</td>
                      <td className="p-2.5 text-center font-mono">50</td>
                      <td className="p-2.5 text-center font-mono font-bold text-emerald-900">{documentData.exam.akhlaqMarks}</td>
                      <td className="p-2.5 text-center text-emerald-700 font-bold">{documentData.exam.akhlaqMarks >= 40 ? 'بہترین' : 'تسلی بخش'}</td>
                    </tr>
                  </tbody>
                  <tfoot className="bg-emerald-100/70 text-emerald-950 font-bold text-xs">
                    <tr>
                      <td colSpan={2} className="p-2.5 font-black text-sm text-right">مجموعی میزان:</td>
                      <td className="p-2.5 text-center font-mono font-black">{documentData.exam.totalMax}</td>
                      <td className="p-2.5 text-center font-mono font-black text-emerald-900 text-sm">
                        {documentData.exam.totalObtained}
                      </td>
                      <td className="p-2.5 text-center font-mono font-black text-sm text-emerald-900">
                        {documentData.exam.percentage}%
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>

              {/* Grade Banner & Remarks */}
              <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-amber-50 rounded-2xl border border-amber-300 font-urdu text-sm mb-4">
                <div>
                  <span className="text-xs text-amber-800 block font-bold">فائنل پوزیشن / گریڈ:</span>
                  <span className="text-xl font-black text-[#0F5D2F]">{documentData.exam.gradeUr}</span>
                </div>
                <div className="flex-1 max-w-sm text-right">
                  <span className="text-xs text-amber-800 block font-bold">خصوصی ریمارکس:</span>
                  <p className="text-xs italic text-slate-700">"{documentData.exam.remarksUr}"</p>
                </div>
              </div>

              {/* Signatures & Seal */}
              <div className="grid grid-cols-3 gap-4 pt-6 border-t-2 border-emerald-800/30 text-center font-urdu text-xs">
                <div>
                  <div className="w-28 mx-auto border-b border-dashed border-slate-700 mb-1.5 h-6"></div>
                  <span className="font-bold text-slate-800 block">دستخط استاد محترم</span>
                  <span className="text-[10px] text-slate-500">نگرانِ شعبہ حفظ</span>
                </div>

                <div>
                  <div className="w-20 h-20 mx-auto rounded-full border-2 border-dashed border-emerald-700/60 flex items-center justify-center text-[10px] text-emerald-800 font-bold">
                    مہر مدرسہ
                  </div>
                </div>

                <div>
                  <div className="w-28 mx-auto border-b border-dashed border-slate-700 mb-1.5 h-6"></div>
                  <span className="font-bold text-slate-800 block">دستخط و تصدیق مہتمم</span>
                  <span className="text-[10px] text-slate-500">جامعہ قاسمیہ اسلامیہ</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
