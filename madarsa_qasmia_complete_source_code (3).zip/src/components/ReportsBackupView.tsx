import React, { useState, useRef } from 'react';
import {
  Student,
  DonationRecord,
  ExpenseRecord,
  FeePayment,
  SystemSettings,
  UserRole,
} from '../types';
import { translations, Language } from '../i18n/translations';
import {
  exportFullBackup,
  exportStudentsCSV,
  exportFinancesCSV,
} from '../utils/storage';
import { triggerProjectZipDownload } from '../utils/downloadZip';
import {
  Printer,
  Download,
  Upload,
  FileSpreadsheet,
  Lock,
  KeyRound,
  CheckCircle,
  AlertTriangle,
  RotateCcw,
  Sparkles,
} from 'lucide-react';

interface ReportsBackupViewProps {
  students: Student[];
  donations: DonationRecord[];
  expenses: ExpenseRecord[];
  feePayments: FeePayment[];
  settings: SystemSettings;
  onUpdateSettings: (settings: SystemSettings) => void;
  onRestoreData: (importedData: any) => void;
  onResetToDefaults: () => void;
  onDownloadSingleFile: () => void;
  lang: Language;
  currentRole: UserRole;
  onPrintStudentIdCard: (student: Student) => void;
}

export const ReportsBackupView: React.FC<ReportsBackupViewProps> = ({
  students,
  donations,
  expenses,
  feePayments,
  settings,
  onUpdateSettings,
  onRestoreData,
  onResetToDefaults,
  onDownloadSingleFile,
  lang,
  currentRole,
  onPrintStudentIdCard,
}) => {
  const t = translations[lang];
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [pinForm, setPinForm] = useState({
    adminPin: settings.adminPin,
    ustadPin: settings.ustadPin,
    accountantPin: settings.accountantPin,
  });
  const [pinSuccessMsg, setPinSuccessMsg] = useState(false);
  const [selectedStudentForId, setSelectedStudentForId] = useState(students[0]?.id || '');

  const handleSavePins = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateSettings({
      ...settings,
      adminPin: pinForm.adminPin,
      ustadPin: pinForm.ustadPin,
      accountantPin: pinForm.accountantPin,
    });
    setPinSuccessMsg(true);
    setTimeout(() => setPinSuccessMsg(false), 3500);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const json = JSON.parse(event.target?.result as string);
        onRestoreData(json);
        alert(t.dataRestored);
      } catch (err) {
        alert('خراب یا نامکمل فائل! برائے مہربانی درست JSON بیک اپ فائل منتخب کریں۔');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300 font-urdu">
      {/* Top Banner */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-teal-100 text-teal-800 flex items-center justify-center text-3xl shadow-inner">
            🖨️
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-emerald-950 font-urdu">
              {t.reportsTitle}
            </h2>
            <p className="text-xs text-slate-500 font-urdu">
              {lang === 'ur'
                ? 'شناختی کارڈ پرنٹنگ، ایکسل و CSV ڈاؤن لوڈ، اور مکمل آف لائن بیک اپ'
                : 'ID Cards, printable vouchers, CSV export, and 100% offline data backup'}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Big Highlight: Single-File HTML Download */}
          <button
            onClick={onDownloadSingleFile}
            className="flex items-center gap-2 bg-amber-500 hover:bg-amber-600 text-emerald-950 font-black px-4 py-2.5 rounded-2xl shadow-md transition-all active:scale-95 cursor-pointer text-sm"
          >
            <Download className="w-4 h-4" />
            <span>{t.downloadSingleHtml}</span>
          </button>

          {/* Full Source Code ZIP Download */}
          <button
            onClick={() => triggerProjectZipDownload('madarsa_qasmia_complete_project.zip')}
            className="flex items-center gap-2 bg-[#0F5D2F] hover:bg-[#0d4a26] text-white font-black px-4 py-2.5 rounded-2xl shadow-md transition-all active:scale-95 cursor-pointer text-sm border border-emerald-400/30"
          >
            <Download className="w-4 h-4 text-amber-300" />
            <span>سورس کوڈ ZIP فائل ڈاؤن لوڈ کریں 📦</span>
          </button>
        </div>
      </div>

      {/* Grid: 1. ID Cards & Printable Hub | 2. Data Exports */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Printable ID Cards Hub */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center text-xl font-bold">
              🪪
            </div>
            <div>
              <h3 className="text-base font-bold text-emerald-950">
                طلبہ کے شناختی کارڈز کا اجرا (Print Student ID Card)
              </h3>
              <p className="text-xs text-slate-500">
                مدرسہ کے مہر و نشان اور بارکوڈ کے ساتھ پرنٹ کے لیے تیار
              </p>
            </div>
          </div>

          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-3">
            <label className="block text-xs font-bold text-slate-600">
              طالب علم کا انتخاب کریں:
            </label>
            <select
              value={selectedStudentForId}
              onChange={(e) => setSelectedStudentForId(e.target.value)}
              className="w-full px-3 py-2.5 rounded-xl border border-slate-300 font-bold text-sm bg-white"
            >
              {students.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.nameUr} (رول نمبر: {s.rollNo} - درجہ: {s.class})
                </option>
              ))}
            </select>

            <button
              onClick={() => {
                const s = students.find((st) => st.id === selectedStudentForId);
                if (s) onPrintStudentIdCard(s);
              }}
              className="w-full bg-[#0F5D2F] hover:bg-emerald-800 text-white font-bold py-3 px-4 rounded-xl shadow-sm transition-colors cursor-pointer flex items-center justify-center gap-2 text-sm"
            >
              <Printer className="w-4 h-4 text-amber-400" />
              <span>منتخب کارڈ پرنٹ کریں 🪪</span>
            </button>
          </div>
        </div>

        {/* Excel & CSV Exports Hub */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-800 flex items-center justify-center text-xl font-bold">
              📊
            </div>
            <div>
              <h3 className="text-base font-bold text-emerald-950">
                ایکسل و CSV فائلز برائے ریکارڈ (Export Data)
              </h3>
              <p className="text-xs text-slate-500">
                مائیکروسافٹ ایکسل یا گوگل شیٹس میں کھولنے کے لیے فوری ڈاؤن لوڈ
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <button
              onClick={() => exportStudentsCSV(students)}
              className="p-4 rounded-2xl bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-200 font-bold text-xs transition-all flex items-center gap-3 cursor-pointer text-right"
            >
              <FileSpreadsheet className="w-6 h-6 text-emerald-700 shrink-0" />
              <div>
                <span className="block font-black text-sm">{t.exportStudentsCSV}</span>
                <span className="text-[11px] text-emerald-700">کل {students.length} طلبہ کا ریکارڈ</span>
              </div>
            </button>

            <button
              onClick={() => exportFinancesCSV(donations, expenses)}
              className="p-4 rounded-2xl bg-blue-50 hover:bg-blue-100 text-blue-900 border border-blue-200 font-bold text-xs transition-all flex items-center gap-3 cursor-pointer text-right"
            >
              <FileSpreadsheet className="w-6 h-6 text-blue-700 shrink-0" />
              <div>
                <span className="block font-black text-sm">{t.exportDonationsCSV}</span>
                <span className="text-[11px] text-blue-700">عطیات، چندہ و اخراجات کھاتہ</span>
              </div>
            </button>
          </div>
        </div>
      </div>

      {/* JSON Backup & Restore + Security PIN Management */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Full JSON Offline Backup & Restore */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center text-xl font-bold">
              💾
            </div>
            <div>
              <h3 className="text-base font-bold text-emerald-950">
                مکمل سسٹم بیک اپ و بحالی (Offline JSON Backup)
              </h3>
              <p className="text-xs text-slate-500">
                تمام ریکارڈز کو ایک سنگل فائل میں محفوظ کریں اور دوسرے کمپیوٹر پر چلائیں
              </p>
            </div>
          </div>

          <div className="space-y-3">
            <button
              onClick={() => triggerProjectZipDownload('madarsa_qasmia_complete_source_code.zip')}
              className="w-full p-3.5 bg-linear-to-r from-emerald-800 to-emerald-950 hover:from-emerald-700 hover:to-emerald-900 text-white font-black rounded-2xl transition-all shadow-md cursor-pointer flex items-center justify-center gap-2 text-sm border-2 border-amber-400 active:scale-95"
            >
              <Download className="w-5 h-5 text-amber-400" />
              <span>مکمل سورس کوڈ ZIP فائل ڈاؤن لوڈ کریں (برائے Vercel و لوکل) 📦</span>
            </button>

            <button
              onClick={exportFullBackup}
              className="w-full p-3.5 bg-slate-100 hover:bg-slate-200 text-slate-900 font-bold rounded-2xl transition-colors cursor-pointer flex items-center justify-center gap-2 text-sm border border-slate-300"
            >
              <Download className="w-4 h-4 text-emerald-700" />
              <span>{t.downloadJsonBackup}</span>
            </button>

            <div className="relative">
              <input
                type="file"
                ref={fileInputRef}
                accept=".json"
                onChange={handleFileUpload}
                className="hidden"
              />
              <button
                onClick={() => fileInputRef.current?.click()}
                className="w-full p-3.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 font-bold rounded-2xl transition-colors cursor-pointer flex items-center justify-center gap-2 text-sm border border-emerald-300"
              >
                <Upload className="w-4 h-4 text-emerald-700" />
                <span>{t.restoreJsonBackup}</span>
              </button>
            </div>

            <div className="pt-2">
              <button
                onClick={() => {
                  if (
                    window.confirm(
                      'کیا آپ واقعی تمام ریکارڈز کو ابتدائی نمونہ ڈیٹا پر واپس لانا چاہتے ہیں؟'
                    )
                  ) {
                    onResetToDefaults();
                  }
                }}
                className="w-full text-xs text-rose-700 hover:text-rose-900 font-bold py-2 text-center cursor-pointer flex items-center justify-center gap-1"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>{t.resetToDefault}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Security PINs Setup */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-800 flex items-center justify-center text-xl font-bold">
              🔒
            </div>
            <div>
              <h3 className="text-base font-bold text-emerald-950">{t.settingsSecurity}</h3>
              <p className="text-xs text-slate-500">{t.changePinDesc}</p>
            </div>
          </div>

          <form onSubmit={handleSavePins} className="space-y-3">
            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">
                  ایڈمن پن (Admin):
                </label>
                <input
                  type="text"
                  required
                  maxLength={6}
                  value={pinForm.adminPin}
                  onChange={(e) => setPinForm({ ...pinForm, adminPin: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono font-bold text-center text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">
                  استاد پن (Ustad):
                </label>
                <input
                  type="text"
                  required
                  maxLength={6}
                  value={pinForm.ustadPin}
                  onChange={(e) => setPinForm({ ...pinForm, ustadPin: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono font-bold text-center text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">
                  خزانچی (Account):
                </label>
                <input
                  type="text"
                  required
                  maxLength={6}
                  value={pinForm.accountantPin}
                  onChange={(e) => setPinForm({ ...pinForm, accountantPin: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono font-bold text-center text-sm"
                />
              </div>
            </div>

            <p className="text-[11px] text-emerald-800 bg-emerald-50 p-2.5 rounded-xl border border-emerald-200 leading-tight">
              {t.parentPortalNote}
            </p>

            {pinSuccessMsg && (
              <div className="p-2.5 rounded-xl bg-emerald-100 text-emerald-900 font-bold text-xs flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-700" />
                <span>{t.pinUpdateSuccess}</span>
              </div>
            )}

            <button
              type="submit"
              className="w-full bg-[#0F5D2F] hover:bg-emerald-800 text-white font-bold py-2.5 px-4 rounded-xl shadow-sm transition-colors cursor-pointer flex items-center justify-center gap-1.5 text-xs sm:text-sm"
            >
              <KeyRound className="w-4 h-4 text-amber-400" />
              <span>{t.updatePins}</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
