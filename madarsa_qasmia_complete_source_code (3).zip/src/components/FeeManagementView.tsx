import React, { useState } from 'react';
import { Student, FeePayment, UserRole } from '../types';
import { translations, Language } from '../i18n/translations';
import { createWhatsAppLink } from '../utils/storage';
import {
  DollarSign,
  PlusCircle,
  Printer,
  Send,
  AlertCircle,
  CheckCircle,
  Receipt,
  X,
  CreditCard,
  Search,
} from 'lucide-react';

interface FeeManagementViewProps {
  students: Student[];
  feePayments: FeePayment[];
  onAddFeePayment: (payment: Omit<FeePayment, 'id'>) => void;
  onPrintReceipt: (payment: FeePayment, student: Student) => void;
  lang: Language;
  currentRole: UserRole;
  activeTeacherName?: string;
  isQuickCollectOpen?: boolean;
  onCloseQuickCollect?: () => void;
  parentStudentMobile?: string;
}

export const FeeManagementView: React.FC<FeeManagementViewProps> = ({
  students,
  feePayments,
  onAddFeePayment,
  onPrintReceipt,
  lang,
  currentRole,
  activeTeacherName = 'قاری عبد الوحید',
  isQuickCollectOpen = false,
  onCloseQuickCollect,
  parentStudentMobile,
}) => {
  const t = translations[lang];
  const [activeTab, setActiveTab] = useState<'payments' | 'defaulters'>('payments');
  const [isModalOpen, setIsModalOpen] = useState(isQuickCollectOpen);
  const [searchQuery, setSearchQuery] = useState('');

  // Auto sync quick collect trigger
  React.useEffect(() => {
    if (isQuickCollectOpen) {
      setIsModalOpen(true);
    }
  }, [isQuickCollectOpen]);

  // Form State
  const [formData, setFormData] = useState({
    studentId: students[0]?.id || '',
    receiptNo: `REC-2026-${String(feePayments.length + 84).padStart(3, '0')}`,
    date: new Date().toISOString().split('T')[0],
    month: 'مارچ 2026',
    tuitionFee: 2000,
    booksFee: 0,
    hostelFee: 0,
    transportFee: 0,
    discount: 0,
    paymentMethod: 'Cash' as 'Cash' | 'Easypaisa' | 'JazzCash' | 'Bank',
    collectedBy: 'مولانا عمران (خزانچی)',
    notes: '',
  });

  const handleStudentChange = (id: string) => {
    const student = students.find((s) => s.id === id);
    if (student) {
      setFormData((prev) => ({
        ...prev,
        studentId: id,
        tuitionFee: student.isHostel ? Math.max(1000, student.monthlyFee - 1500) : student.monthlyFee,
        hostelFee: student.isHostel ? 1500 : 0,
      }));
    }
  };

  const calculatedTotal = Math.max(
    0,
    Number(formData.tuitionFee || 0) +
      Number(formData.booksFee || 0) +
      Number(formData.hostelFee || 0) +
      Number(formData.transportFee || 0) -
      Number(formData.discount || 0)
  );

  const handleOpenCollectModal = (prefillStudentId?: string) => {
    const targetStudentId = prefillStudentId || students[0]?.id || '';
    const student = students.find((s) => s.id === targetStudentId);

    setFormData({
      studentId: targetStudentId,
      receiptNo: `REC-2026-${String(feePayments.length + 85).padStart(3, '0')}`,
      date: new Date().toISOString().split('T')[0],
      month: 'مارچ 2026',
      tuitionFee: student ? (student.isHostel ? Math.max(1000, student.monthlyFee - 1500) : student.monthlyFee) : 2000,
      booksFee: 0,
      hostelFee: student?.isHostel ? 1500 : 0,
      transportFee: 0,
      discount: 0,
      paymentMethod: 'Cash',
      collectedBy: 'مولانا عمران (خزانچی)',
      notes: '',
    });
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    if (onCloseQuickCollect) onCloseQuickCollect();
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.studentId) return;

    onAddFeePayment({
      ...formData,
      totalPaid: calculatedTotal,
    });

    handleCloseModal();
  };

  // WhatsApp Fee Reminder Trigger
  const handleSendWhatsAppFeeReminder = (student: Student) => {
    const message =
      lang === 'ur'
        ? `محترم سرپرست! السلام علیکم، آپ کے فرزند "${student.nameUr}" (رول نمبر: ${student.rollNo}) کی ماہانہ فیس برائے مارچ 2026 مبلغ ${student.monthlyFee} روپے واجب الادا ہے۔ برائے مہربانی بروقت فیس جمع کروا کر رسید حاصل فرمائیں۔ شکریہ - دفتر حسابات مدرسہ قاسمیہ`
        : `Respected Guardian! Assalamu Alaikum, monthly fee for ${student.nameEn || student.nameUr} (Roll: ${student.rollNo}) for March 2026 of Rs. ${student.monthlyFee} is pending. Kindly deposit at your earliest convenience. JazakAllah - Accounts Office Madarsa Qasmia`;

    const url = createWhatsAppLink(student.parentMobile, message);
    window.open(url, '_blank');
  };

  // Role-based filtering
  const isParent = currentRole === 'parent';
  const isTeacher = currentRole === 'ustad';

  const roleFilteredStudents = isParent && parentStudentMobile
    ? students.filter((s) => {
        const cleanDigits = parentStudentMobile.replace(/[^0-9]/g, '');
        const sDigits = s.parentMobile.replace(/[^0-9]/g, '');
        return sDigits.includes(cleanDigits) || cleanDigits.includes(sDigits);
      })
    : isTeacher
    ? students.filter((s) => s.ustadName === activeTeacherName)
    : students;

  const roleStudentIds = new Set(roleFilteredStudents.map((s) => s.id));

  // Defaulters Calculation
  const paidStudentIds = new Set(feePayments.map((f) => f.studentId));
  const defaulterStudents = roleFilteredStudents.filter((s) => !paidStudentIds.has(s.id));

  // Payments specific to role
  const visiblePayments = feePayments.filter((f) => roleStudentIds.has(f.studentId));

  const totalCollected = visiblePayments.reduce((sum, f) => sum + (f.totalPaid || 0), 0);
  const totalPending = defaulterStudents.reduce((sum, s) => sum + (s.monthlyFee || 0), 0);

  const canManage = currentRole === 'admin' || currentRole === 'accountant';

  return (
    <div className="space-y-6 animate-in fade-in duration-300 font-urdu">
      {/* Top Banner */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-blue-100 text-blue-800 flex items-center justify-center text-3xl shadow-inner">
            💰
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-emerald-950 font-urdu">
              {t.feeManagementTitle}
            </h2>
            <p className="text-xs text-slate-500 font-urdu">
              {lang === 'ur'
                ? 'ماہانہ فیس وصولی، کمپیوٹرائزڈ رسیدیں اور واٹس ایپ یاد دہانی'
                : 'Fee collection, digital printable vouchers & WhatsApp reminders'}
            </p>
          </div>
        </div>

        {canManage && (
          <button
            onClick={() => handleOpenCollectModal()}
            id="collect-fee-btn"
            className="flex items-center gap-2 bg-[#0F5D2F] hover:bg-emerald-800 text-white font-black px-5 py-3 rounded-2xl shadow-md transition-all active:scale-95 cursor-pointer text-sm"
          >
            <PlusCircle className="w-5 h-5 text-amber-400" />
            <span>{t.collectFeeTitle}</span>
          </button>
        )}
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-emerald-50 border-2 border-emerald-200 p-4.5 rounded-2xl">
          <span className="text-xs font-bold text-emerald-800 block">وصول شدہ فیس:</span>
          <span className="text-2xl sm:text-3xl font-black text-emerald-950 font-mono mt-1 block">
            {totalCollected.toLocaleString()} روپے
          </span>
          <span className="text-xs text-emerald-700 mt-1 block font-mono">
            {feePayments.length} رسیدیں جاری ہوئیں
          </span>
        </div>

        <div className="bg-rose-50 border-2 border-rose-200 p-4.5 rounded-2xl">
          <span className="text-xs font-bold text-rose-800 block">واجب الادا بقایا جات (تخمینہ):</span>
          <span className="text-2xl sm:text-3xl font-black text-rose-950 font-mono mt-1 block">
            {totalPending.toLocaleString()} روپے
          </span>
          <span className="text-xs text-rose-700 mt-1 block font-mono">
            {defaulterStudents.length} طلبہ کی فیس باقی ہے
          </span>
        </div>

        <div className="bg-blue-50 border-2 border-blue-200 p-4.5 rounded-2xl">
          <span className="text-xs font-bold text-blue-800 block">فیس وصولی شرح:</span>
          <span className="text-2xl sm:text-3xl font-black text-blue-950 font-mono mt-1 block">
            {students.length > 0 ? Math.round((paidStudentIds.size / students.length) * 100) : 0}%
          </span>
          <span className="text-xs text-blue-700 mt-1 block">
            {paidStudentIds.size} از {students.length} طلبہ
          </span>
        </div>
      </div>

      {/* Navigation Sub-Tabs: Payments vs Defaulters */}
      {currentRole !== 'parent' && (
        <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
          <button
            onClick={() => setActiveTab('payments')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all cursor-pointer ${
              activeTab === 'payments'
                ? 'bg-emerald-700 text-white shadow-sm'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
            }`}
          >
            <Receipt className="w-4 h-4" />
            <span>وصول شدہ فیس ریکارڈ ({feePayments.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('defaulters')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all cursor-pointer ${
              activeTab === 'defaulters'
                ? 'bg-rose-700 text-white shadow-sm'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
            }`}
          >
            <AlertCircle className="w-4 h-4" />
            <span>بقایا جات والے طلبہ ({defaulterStudents.length})</span>
          </button>
        </div>
      )}

      {/* 1. PAYMENTS HISTORY LIST */}
      {activeTab === 'payments' && (
        <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-emerald-950 font-urdu flex items-center gap-2">
              <span>🧾</span>
              <span>جاری شدہ کمپیوٹرائزڈ رسیدیں</span>
            </h3>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead className="bg-[#E8F5E9] text-emerald-900 font-urdu">
                <tr>
                  <th className="p-3">رسید نمبر</th>
                  <th className="p-3">طالب علم</th>
                  <th className="p-3">ماہ</th>
                  <th className="p-3">تعلیمی فیس</th>
                  <th className="p-3">ہاسٹل</th>
                  <th className="p-3">کتب</th>
                  <th className="p-3">کل وصول</th>
                  <th className="p-3">طریقہ</th>
                  <th className="p-3 text-center">پرنٹ رسید</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-emerald-50">
                {visiblePayments.map((payment) => {
                  const student = students.find((s) => s.id === payment.studentId);
                  return (
                    <tr key={payment.id} className="hover:bg-emerald-50/40">
                      <td className="p-3 font-mono font-bold text-emerald-800">{payment.receiptNo}</td>
                      <td className="p-3">
                        <span className="font-bold text-slate-900 block">{student?.nameUr || 'طالب علم'}</span>
                        <span className="text-[10px] font-mono text-slate-400">{student?.rollNo}</span>
                      </td>
                      <td className="p-3">{payment.month}</td>
                      <td className="p-3 font-mono">{payment.tuitionFee}</td>
                      <td className="p-3 font-mono">{payment.hostelFee}</td>
                      <td className="p-3 font-mono">{payment.booksFee}</td>
                      <td className="p-3 font-mono font-black text-emerald-900 text-sm">
                        {payment.totalPaid} روپے
                      </td>
                      <td className="p-3">
                        <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded text-[11px] font-medium">
                          {payment.paymentMethod}
                        </span>
                      </td>
                      <td className="p-3 text-center">
                        <button
                          onClick={() => student && onPrintReceipt(payment, student)}
                          title="رسید پرنٹ کریں"
                          className="px-2.5 py-1.5 bg-emerald-100 hover:bg-emerald-200 text-emerald-900 rounded-xl text-xs font-bold transition-colors cursor-pointer inline-flex items-center gap-1"
                        >
                          <Printer className="w-3.5 h-3.5" />
                          <span>پرنٹ 🖨️</span>
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 2. DEFAULTERS LIST (Students with pending fees) */}
      {activeTab === 'defaulters' && (
        <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-rose-950 font-urdu flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-rose-600" />
              <span>{t.defaultersList}</span>
            </h3>
            <span className="text-xs text-slate-500">
              واٹس ایپ بٹن پر کلک کر کے والدین کو ایک کلک میں یاد دہانی بھیجیں
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {defaulterStudents.map((student) => (
              <div
                key={student.id}
                className="p-4 rounded-2xl bg-rose-50/40 border border-rose-200 hover:border-rose-400 transition-all flex flex-wrap items-center justify-between gap-3"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="font-bold text-base text-rose-950">{student.nameUr}</h4>
                    <span className="text-xs font-mono bg-white px-2 py-0.5 rounded border border-rose-200">
                      {student.rollNo}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-1">
                    والد: {student.fatherNameUr} | درجہ: {student.class} |{' '}
                    {student.isHostel ? 'مقیم (ہاسٹل)' : 'غیر مقیم'}
                  </p>
                  <p className="text-xs text-slate-500 font-mono mt-0.5" dir="ltr">
                    موبائل: {student.parentMobile}
                  </p>
                </div>

                <div className="text-left flex flex-col items-end gap-2">
                  <span className="font-mono font-black text-base text-rose-700">
                    {student.monthlyFee} روپے واجب الادا
                  </span>

                  <div className="flex items-center gap-2">
                    {/* WhatsApp Fee Reminder */}
                    <button
                      onClick={() => handleSendWhatsAppFeeReminder(student)}
                      title={t.sendFeeReminderWhatsApp}
                      className="px-3 py-1.5 rounded-xl bg-[#25D366] hover:bg-[#20ba5a] text-white text-xs font-bold transition-all shadow-xs cursor-pointer flex items-center gap-1.5"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>یاد دہانی 💬</span>
                    </button>

                    {/* Quick Receive Fee Button */}
                    <button
                      onClick={() => handleOpenCollectModal(student.id)}
                      className="px-3 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold transition-all cursor-pointer"
                    >
                      وصول کریں 💰
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Collect Fee Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden animate-in fade-in duration-200">
            <div className="bg-[#0F5D2F] text-white p-5 flex items-center justify-between border-b-4 border-amber-500">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center text-2xl">
                  💰
                </div>
                <div>
                  <h3 className="font-bold text-lg font-urdu">{t.collectFeeTitle}</h3>
                  <p className="text-xs text-emerald-200 font-urdu">مدرسہ قاسمیہ شعبہ فیس و رسیدات</p>
                </div>
              </div>
              <button
                onClick={handleCloseModal}
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4 font-urdu max-h-[80vh] overflow-y-auto">
              {/* Student Select */}
              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">
                  طالب علم کا انتخاب کریں:
                </label>
                <select
                  value={formData.studentId}
                  onChange={(e) => handleStudentChange(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-300 font-bold text-sm bg-white"
                >
                  {students.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.nameUr} ({s.rollNo} - {s.class} - مقررہ فیس: {s.monthlyFee})
                    </option>
                  ))}
                </select>
              </div>

              {/* Receipt No & Month */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">رسید نمبر:</label>
                  <input
                    type="text"
                    required
                    value={formData.receiptNo}
                    onChange={(e) => setFormData({ ...formData, receiptNo: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono font-bold text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">{t.month}:</label>
                  <input
                    type="text"
                    value={formData.month}
                    onChange={(e) => setFormData({ ...formData, month: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm font-bold"
                  />
                </div>
              </div>

              {/* Fee Breakdown Inputs */}
              <div className="grid grid-cols-2 gap-3 bg-slate-50 p-3.5 rounded-2xl border border-slate-200">
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">تعلیمی فیس:</label>
                  <input
                    type="number"
                    min={0}
                    value={formData.tuitionFee}
                    onChange={(e) =>
                      setFormData({ ...formData, tuitionFee: parseInt(e.target.value) || 0 })
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">ہاسٹل و طعام:</label>
                  <input
                    type="number"
                    min={0}
                    value={formData.hostelFee}
                    onChange={(e) =>
                      setFormData({ ...formData, hostelFee: parseInt(e.target.value) || 0 })
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">کتب و اسٹیشنری:</label>
                  <input
                    type="number"
                    min={0}
                    value={formData.booksFee}
                    onChange={(e) =>
                      setFormData({ ...formData, booksFee: parseInt(e.target.value) || 0 })
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">ٹرانسپورٹ:</label>
                  <input
                    type="number"
                    min={0}
                    value={formData.transportFee}
                    onChange={(e) =>
                      setFormData({ ...formData, transportFee: parseInt(e.target.value) || 0 })
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-sm"
                  />
                </div>
              </div>

              {/* Discount Waiver */}
              <div>
                <label className="block text-xs font-bold text-emerald-800 mb-1">
                  وظیفہ / رعایت (Discount):
                </label>
                <input
                  type="number"
                  min={0}
                  value={formData.discount}
                  onChange={(e) =>
                    setFormData({ ...formData, discount: parseInt(e.target.value) || 0 })
                  }
                  className="w-full px-3 py-2 rounded-xl border border-emerald-300 font-mono text-sm bg-emerald-50/50"
                />
              </div>

              {/* Payment Method */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">طریقہ ادائیگی:</label>
                  <select
                    value={formData.paymentMethod}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        paymentMethod: e.target.value as any,
                      })
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm bg-white"
                  >
                    <option value="Cash">نقد (Cash)</option>
                    <option value="Easypaisa">ایزی پیسہ (Easypaisa)</option>
                    <option value="JazzCash">جاز کیش (JazzCash)</option>
                    <option value="Bank">بینک ٹرانسفر (Bank)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">تاریخ:</label>
                  <input
                    type="date"
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-sm"
                  />
                </div>
              </div>

              {/* Total Payable Summary Box */}
              <div className="p-4 rounded-2xl bg-emerald-100/70 border border-emerald-300 flex items-center justify-between">
                <span className="font-bold text-emerald-950 text-base">کل وصول شدہ رقم:</span>
                <span className="font-mono font-black text-2xl text-emerald-950">
                  {calculatedTotal.toLocaleString()} روپے
                </span>
              </div>

              <div className="flex items-center gap-3 pt-3 border-t border-slate-200">
                <button
                  type="submit"
                  className="flex-1 bg-[#0F5D2F] hover:bg-emerald-800 text-white font-bold py-3 px-6 rounded-2xl shadow-md transition-all cursor-pointer"
                >
                  رسید محفوظ کریں اور جاری کریں
                </button>
                <button
                  type="button"
                  onClick={handleCloseModal}
                  className="px-5 py-3 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-sm cursor-pointer"
                >
                  {t.cancel}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
