import React, { useState, useRef } from 'react';
import {
  Student,
  HifzDiaryEntry,
  HifzGrade,
  UserRole,
  DiniyatTopic,
  TeacherProfile,
} from '../types';
import { initialTeachers } from '../data/initialData';
import { translations, Language } from '../i18n/translations';
import { createWhatsAppLink } from '../utils/storage';
import {
  BookOpen,
  PlusCircle,
  Award,
  Send,
  Calendar,
  CheckCircle,
  X,
  Sparkles,
  TrendingUp,
  Mic,
  MicOff,
  Volume2,
  AlertCircle,
  RotateCcw,
  Check,
  ChevronRight,
  ListFilter,
} from 'lucide-react';
import {
  nooraniQaidaTakhtis,
  qaidaRemarksChips,
  nazraHifzRemarksChips,
  diniyatSyllabus,
} from '../data/initialData';
import { asaanNamazDiniyatLessons, DiniyatLesson } from '../data/diniyatLessonsData';

const diniyatRemarksChips = [
  'کلمہ و ترجمہ ازبر ہے',
  'مسنون دعا پکی ہے',
  'وضو کے فرائض یاد ہیں',
  'نماز کے ارکان صحیح ہیں',
  'تکبیر و ثناء درست',
  'سنت کے مطابق طریقہ',
  'دہرائی کی ضرورت ہے',
  'ماشاءاللہ عمدہ یاد کیا',
  'طہارت کے مسائل واضح',
  'والدین گھر پر مشق کرائیں',
];

interface HifzDiaryViewProps {
  students: Student[];
  hifzDiary: HifzDiaryEntry[];
  onAddDiaryEntry: (entry: Omit<HifzDiaryEntry, 'id'>) => void;
  onUpdateParas: (studentId: string, paras: number) => void;
  lang: Language;
  currentRole: UserRole;
  activeTeacherName?: string;
  teachers?: TeacherProfile[];
  isQuickLogOpen?: boolean;
  onCloseQuickLog?: () => void;
  parentStudentMobile?: string;
}

export const HifzDiaryView: React.FC<HifzDiaryViewProps> = ({
  students,
  hifzDiary,
  onAddDiaryEntry,
  onUpdateParas,
  lang,
  currentRole,
  activeTeacherName = 'قاری عبد الوحید',
  teachers = initialTeachers,
  isQuickLogOpen = false,
  onCloseQuickLog,
  parentStudentMobile,
}) => {
  const t = translations[lang];

  // Role-based student isolation:
  // - Parent: Only see their child matching mobile
  // - Ustaad: Only see their assigned students!
  // - Admin: Can see all
  const visibleStudents =
    currentRole === 'parent' && parentStudentMobile
      ? students.filter((s) => {
          const cleanDigits = parentStudentMobile.replace(/[^0-9]/g, '');
          const sDigits = s.parentMobile.replace(/[^0-9]/g, '');
          return sDigits.includes(cleanDigits) || cleanDigits.includes(sDigits);
        })
      : currentRole === 'ustad'
      ? students.filter((s) => s.ustadName === activeTeacherName)
      : students;

  const [selectedStudentId, setSelectedStudentId] = useState<string>(
    visibleStudents[0]?.id || ''
  );
  const [activeTab, setActiveTab] = useState<
    'all' | 'Qaida' | 'Nazra' | 'Hifz' | 'Diniyat'
  >('all');
  const [isModalOpen, setIsModalOpen] = useState(isQuickLogOpen);

  // Audio Recording State
  const [isRecording, setIsRecording] = useState(false);
  const [recordedAudioUrl, setRecordedAudioUrl] = useState<string | undefined>(undefined);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  // Diniyat Student Status Local Map
  const [diniyatStatusMap, setDiniyatStatusMap] = useState<
    Record<string, Record<number, 'مناسب' | 'بہتر' | 'بہترین'>>
  >({
    [visibleStudents[0]?.id || '']: {
      1: 'بہترین',
      2: 'بہتر',
      3: 'مناسب',
    },
  });

  React.useEffect(() => {
    if (isQuickLogOpen) {
      setIsModalOpen(true);
    }
  }, [isQuickLogOpen]);

  const selectedStudent = students.find((s) => s.id === selectedStudentId);

  // Form State with new fields
  const [formData, setFormData] = useState({
    studentId: visibleStudents[0]?.id || '',
    date: new Date().toISOString().split('T')[0],
    hifzType: 'حفظ' as 'قاعدہ' | 'ناظرہ' | 'حفظ' | 'دینیات',
    takhti: 'تختی 1: مفردات',
    surah: 'البقرۃ',
    ayatFrom: 1,
    ayatTo: 10,
    sabaqPara: 1,
    sabaqLinesOrPages: 'صفحہ 1',
    sabqi: 'پارہ 1 کا نصف',
    manzil: 'پارہ 30',
    diniyatLessonId: asaanNamazDiniyatLessons[0]?.id || '',
    diniyatBookPage: asaanNamazDiniyatLessons[0]?.bookPageNumber || 8,
    diniyatTopic: asaanNamazDiniyatLessons[0]?.titleUr || '',
    quality: 'بہترین' as 'مناسب' | 'بہتر' | 'بہترین',
    grade: 'A+' as HifzGrade,
    hadaf: {
      quantity: 1,
      unit: 'صفحہ' as 'الفاظ' | 'لائنیں' | 'صفحہ' | 'رکوع' | 'آیت',
    },
    mistakes: {
      atakna: 0,
      bhoolna: 0,
      tajweed: 0,
    },
    teacherRemarks: 'ماشاءاللہ بہت عمدہ سنایا۔',
    ustadName: 'قاری عبد الوحید',
    audioUrl: '' as string | undefined,
  });

  // Filter diary entries for current student and active tab
  const studentDiaryEntries = hifzDiary
    .filter((d) => d.studentId === selectedStudentId)
    .filter((d) => {
      if (activeTab === 'all' || activeTab === 'Diniyat') return true;
      if (activeTab === 'Qaida') return d.hifzType === 'قاعدہ' || d.type === 'قاعدہ';
      if (activeTab === 'Nazra') return d.hifzType === 'ناظرہ' || d.type === 'ناظرہ';
      if (activeTab === 'Hifz') return d.hifzType === 'حفظ' || d.type === 'حفظ' || !d.hifzType;
      return true;
    })
    .sort((a, b) => b.date.localeCompare(a.date));

  const handleOpenAdd = () => {
    const studentDefaultType =
      selectedStudent?.class === 'Qaida'
        ? 'قاعدہ'
        : selectedStudent?.class === 'Nazra'
        ? 'ناظرہ'
        : 'حفظ';

    setFormData({
      studentId: selectedStudentId || visibleStudents[0]?.id || '',
      date: new Date().toISOString().split('T')[0],
      hifzType: studentDefaultType,
      takhti: 'تختی 1: مفردات',
      surah: 'البقرۃ',
      ayatFrom: 1,
      ayatTo: 10,
      sabaqPara: selectedStudent?.completedParas ? selectedStudent.completedParas + 1 : 1,
      sabaqLinesOrPages: 'صفحہ 1',
      sabqi: 'پارہ آخری نصف',
      manzil: 'پارہ 1',
      diniyatLessonId: asaanNamazDiniyatLessons[0]?.id || '',
      diniyatBookPage: asaanNamazDiniyatLessons[0]?.bookPageNumber || 8,
      diniyatTopic: asaanNamazDiniyatLessons[0]?.titleUr || '',
      quality: 'بہترین',
      grade: 'A+',
      hadaf: {
        quantity: 1,
        unit: 'صفحہ',
      },
      mistakes: {
        atakna: 0,
        bhoolna: 0,
        tajweed: 0,
      },
      teacherRemarks: 'ماشاءاللہ بہت اچھا یاد کیا۔',
      ustadName: 'قاری عبد الوحید',
      audioUrl: undefined,
    });
    setRecordedAudioUrl(undefined);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
    if (onCloseQuickLog) onCloseQuickLog();
  };

  // Audio Recording Handlers
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioChunksRef.current = [];
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const url = URL.createObjectURL(audioBlob);
        setRecordedAudioUrl(url);
        setFormData((prev) => ({ ...prev, audioUrl: url }));
        stream.getTracks().forEach((track) => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (err) {
      console.warn('Microphone permission not granted or unavailable in preview frame:', err);
      // Generate a mock demonstration audio note
      const simulatedUrl = 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3';
      setRecordedAudioUrl(simulatedUrl);
      setFormData((prev) => ({ ...prev, audioUrl: simulatedUrl }));
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  // Toggle Remarks Chip
  const handleToggleRemarkChip = (chip: string) => {
    setFormData((prev) => {
      const current = prev.teacherRemarks || '';
      if (current.includes(chip)) {
        return {
          ...prev,
          teacherRemarks: current.replace(chip, '').trim(),
        };
      } else {
        return {
          ...prev,
          teacherRemarks: current ? `${current} • ${chip}` : chip,
        };
      }
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.studentId) return;

    onAddDiaryEntry({
      ...formData,
      audioUrl: recordedAudioUrl || formData.audioUrl,
    });
    handleCloseModal();
  };

  // WhatsApp Share for Daily Sabaq with new mistake and target breakdown
  const handleSendWhatsAppSabaq = (entry: HifzDiaryEntry) => {
    const student = students.find((s) => s.id === entry.studentId);
    if (!student) return;

    const gradeText =
      entry.grade === 'A+'
        ? 'ممتاز (A+)'
        : entry.grade === 'A'
        ? 'جید جداً (A)'
        : entry.grade === 'B'
        ? 'جید (B)'
        : 'مقبول (C)';

    const mistakesText = entry.mistakes
      ? `\nغلطیاں: اٹکنا ${entry.mistakes.atakna} | بھولنا ${entry.mistakes.bhoolna} | تجوید ${entry.mistakes.tajweed}`
      : '';

    const hadafText = entry.hadaf
      ? `\nہدف: ${entry.hadaf.quantity} ${entry.hadaf.unit}`
      : '';

    const message =
      entry.hifzType === 'دینیات'
        ? lang === 'ur'
          ? `محترم سرپرست! السلام علیکم، آپ کے فرزند "${student.nameUr}" نے آج بتاریخ ${entry.date} کو دینیات کا سبق: "${entry.diniyatTopic || entry.sabaqLinesOrPages}" (کتاب آسان نماز صفحہ ${entry.diniyatBookPage || ''}) سنایا ہے۔\nمعیار: ${entry.quality || gradeText}۔\nاستاد کا تبصرہ: "${entry.teacherRemarks}"۔ دعاؤں کا طالب: مدرسہ قاسمیہ`
          : `Respected Guardian! Assalamu Alaikum, your child ${student.nameEn || student.nameUr} completed today's Diniyat lesson on ${entry.date}: "${entry.diniyatTopic || entry.sabaqLinesOrPages}" (Asaan Namaz Page ${entry.diniyatBookPage || ''}). Grade: ${gradeText}. Remarks: "${entry.teacherRemarks}". Best wishes - Madarsa Qasmia`
        : lang === 'ur'
        ? `محترم سرپرست! السلام علیکم، آپ کے فرزند "${student.nameUr}" نے آج بتاریخ ${entry.date} کو سبق: پارہ ${entry.sabaqPara} (${entry.sabaqLinesOrPages})، سبقی: ${entry.sabqi} اور منزل: ${entry.manzil} سنائی ہے۔\nمعیار: ${entry.quality || gradeText}۔${hadafText}${mistakesText}\nاستاد کا تبصرہ: "${entry.teacherRemarks}"۔ دعاؤں کا طالب: مدرسہ قاسمیہ`
        : `Respected Guardian! Assalamu Alaikum, your child ${student.nameEn || student.nameUr} completed today's lesson on ${entry.date}: Sabaq (Para ${entry.sabaqPara}, ${entry.sabaqLinesOrPages}), Sabqi (${entry.sabqi}), Manzil (${entry.manzil}). Grade: ${gradeText}. Remarks: "${entry.teacherRemarks}". Best wishes - Madarsa Qasmia`;

    const url = createWhatsAppLink(student.parentMobile, message);
    window.open(url, '_blank');
  };

  // Mark Diniyat week status for student
  const handleSetDiniyatStatus = (weekNum: number, status: 'مناسب' | 'بہتر' | 'بہترین') => {
    if (currentRole === 'parent') return;
    setDiniyatStatusMap((prev) => ({
      ...prev,
      [selectedStudentId]: {
        ...(prev[selectedStudentId] || {}),
        [weekNum]: status,
      },
    }));
  };

  const canEdit = currentRole === 'admin' || currentRole === 'ustad';

  return (
    <div className="space-y-6 animate-in fade-in duration-300 font-urdu">
      {/* Top Banner */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-13 h-13 rounded-2xl bg-amber-100 text-amber-900 flex items-center justify-center text-3xl shadow-inner border border-amber-200">
            📖
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl sm:text-2xl font-black text-emerald-950 font-urdu">
                تعلیمی ڈائری (قاعدہ، ناظرہ، حفظ و دینیات)
              </h2>
              <span className="bg-emerald-100 text-emerald-900 text-xs font-black px-2.5 py-0.5 rounded-full">
                جدید ٹریکر مع وائس و غلطیاں
              </span>
            </div>
            <p className="text-xs text-slate-500 font-urdu mt-0.5">
              سبق، سبقی، منزل، دینیات نصاب، ہدف، صوتی ریکارڈنگ اور اٹکنا/بھولنا/تجوید کی تفصیلی گنتی
            </p>
          </div>
        </div>

        {canEdit && (
          <button
            onClick={handleOpenAdd}
            id="log-sabaq-btn"
            className="flex items-center gap-2 bg-[#0F5D2F] hover:bg-emerald-800 text-white font-black px-5 py-3 rounded-2xl shadow-md transition-all active:scale-95 cursor-pointer text-sm"
          >
            <PlusCircle className="w-5 h-5 text-amber-400" />
            <span>{t.logTodaySabaq}</span>
          </button>
        )}
      </div>

      {/* Category Tabs: تمام / قاعدہ / ناظرہ / حفظ / دینیات */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        {[
          { id: 'all', label: 'تمام اسباق', icon: '📚' },
          { id: 'Qaida', label: 'نورانی قاعدہ', icon: '🔤' },
          { id: 'Nazra', label: 'ناظرہ قرآن', icon: '📖' },
          { id: 'Hifz', label: 'حفظِ قرآن', icon: '🌟' },
          { id: 'Diniyat', label: 'دینیات (۱۲ ہفتوں کا نصاب)', icon: '🕌' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition-all cursor-pointer shrink-0 border-2 ${
              activeTab === tab.id
                ? 'bg-emerald-950 text-amber-300 border-amber-400 shadow-sm'
                : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
            }`}
          >
            <span>{tab.icon}</span>
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Student Selector Carousel / Tabs */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs">
        <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
          {lang === 'ur' ? 'طالب علم منتخب کریں:' : 'Select Student:'}
        </label>
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          {visibleStudents.map((s) => {
            const isSelected = selectedStudentId === s.id;
            return (
              <button
                key={s.id}
                onClick={() => setSelectedStudentId(s.id)}
                className={`flex items-center gap-2.5 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition-all cursor-pointer shrink-0 border-2 ${
                  isSelected
                    ? 'bg-[#0F5D2F] text-white border-emerald-800 shadow-md ring-2 ring-emerald-600/30'
                    : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                }`}
              >
                <span className="text-base">🎓</span>
                <div className="text-right">
                  <span className="block font-bold">{s.nameUr}</span>
                  <span
                    className={`block text-[10px] font-mono ${
                      isSelected ? 'text-emerald-200' : 'text-slate-400'
                    }`}
                  >
                    {s.class} • رول {s.rollNo}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* If Diniyat Tab Active: Display 12-Week Curriculum Matrix */}
      {activeTab === 'Diniyat' ? (
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-2xl">🕌</span>
                <h3 className="text-xl font-black text-emerald-950">
                  دینیات و اسلامی اخلاقیات - ۱۲ ہفتوں کا مکمل نصاب
                </h3>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                طالب علم: <strong className="text-emerald-900">{selectedStudent?.nameUr}</strong> |
                کلمے، مسنون دعائیں، نماز و روزمرہ کی اسلامی سنتیں
              </p>
            </div>
            <span className="bg-amber-100 text-amber-900 text-xs font-bold px-3 py-1 rounded-full border border-amber-300">
              ۱۲ ہفتہ وار ماڈیولز
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {diniyatSyllabus.map((item) => {
              const currentStatus =
                (diniyatStatusMap[selectedStudentId] || {})[item.weekNumber] || 'باقی';

              return (
                <div
                  key={item.weekNumber}
                  className="p-4 rounded-2xl bg-[#FCFBF7] border-2 border-amber-200/80 shadow-xs hover:border-amber-400 transition-all flex flex-col justify-between space-y-3"
                >
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="bg-emerald-950 text-amber-300 text-xs font-mono font-bold px-2 py-0.5 rounded-lg">
                        ہفتہ نمبر {item.weekNumber}
                      </span>
                      <span
                        className={`text-xs px-2.5 py-0.5 rounded-full font-bold ${
                          currentStatus === 'بہترین'
                            ? 'bg-emerald-600 text-white'
                            : currentStatus === 'بہتر'
                            ? 'bg-blue-600 text-white'
                            : currentStatus === 'مناسب'
                            ? 'bg-amber-500 text-white'
                            : 'bg-slate-200 text-slate-600'
                        }`}
                      >
                        {currentStatus === 'باقی' ? 'التواء' : currentStatus}
                      </span>
                    </div>

                    <h4 className="font-black text-base text-emerald-950 mt-2">
                      {item.titleUr}
                    </h4>
                    <p className="text-xs text-slate-600 mt-1">{item.descriptionUr}</p>

                    {item.arabicText && (
                      <div className="mt-2.5 p-2 rounded-xl bg-amber-50 border border-amber-200 text-center font-arabic text-sm text-emerald-950 leading-relaxed font-bold">
                        {item.arabicText}
                      </div>
                    )}
                  </div>

                  {/* 3 Quality Rating Buttons */}
                  {canEdit && (
                    <div className="pt-2 border-t border-amber-200 flex items-center justify-between gap-1.5">
                      <span className="text-[11px] text-slate-500 font-bold">معیار:</span>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleSetDiniyatStatus(item.weekNumber, 'مناسب')}
                          className={`px-2 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                            currentStatus === 'مناسب'
                              ? 'bg-amber-500 text-white shadow-xs'
                              : 'bg-amber-100 text-amber-800 hover:bg-amber-200'
                          }`}
                        >
                          مناسب
                        </button>
                        <button
                          onClick={() => handleSetDiniyatStatus(item.weekNumber, 'بہتر')}
                          className={`px-2 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                            currentStatus === 'بہتر'
                              ? 'bg-blue-600 text-white shadow-xs'
                              : 'bg-blue-100 text-blue-800 hover:bg-blue-200'
                          }`}
                        >
                          بہتر
                        </button>
                        <button
                          onClick={() => handleSetDiniyatStatus(item.weekNumber, 'بہترین')}
                          className={`px-2 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                            currentStatus === 'بہترین'
                              ? 'bg-emerald-600 text-white shadow-xs'
                              : 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                          }`}
                        >
                          بہترین
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        <>
          {/* Selected Student Progress Overview Card */}
          {selectedStudent && (
            <div className="bg-linear-to-r from-emerald-900 to-[#0F5D2F] text-white rounded-3xl p-6 shadow-md border-b-4 border-amber-400">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-2xl bg-white/15 flex items-center justify-center text-4xl shadow-inner border border-white/20">
                    📖
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-xl sm:text-2xl font-black">{selectedStudent.nameUr}</h3>
                      <span className="bg-amber-400 text-emerald-950 text-xs font-bold font-mono px-2 py-0.5 rounded">
                        {selectedStudent.rollNo}
                      </span>
                    </div>
                    <p className="text-xs text-emerald-100 mt-1">
                      ولدیت: {selectedStudent.fatherNameUr} | کلاس: {selectedStudent.class} | استاد: {selectedStudent.ustadName || 'قاری عبد الوحید'}
                    </p>
                  </div>
                </div>

                {/* Paras Control */}
                {canEdit && (
                  <div className="flex items-center gap-3 bg-emerald-950/70 p-2 rounded-2xl border border-emerald-700/50">
                    <span className="text-xs text-emerald-200 font-bold px-2">مکمل پارے:</span>
                    <button
                      onClick={() =>
                        onUpdateParas(
                          selectedStudent.id,
                          Math.max(0, (selectedStudent.completedParas || 0) - 1)
                        )
                      }
                      className="w-8 h-8 rounded-xl bg-emerald-800 hover:bg-emerald-700 flex items-center justify-center font-bold text-base cursor-pointer active:scale-95"
                    >
                      -
                    </button>
                    <span className="font-mono text-xl font-black text-amber-300 px-1">
                      {selectedStudent.completedParas || 0}
                    </span>
                    <button
                      onClick={() =>
                        onUpdateParas(
                          selectedStudent.id,
                          Math.min(30, (selectedStudent.completedParas || 0) + 1)
                        )
                      }
                      className="w-8 h-8 rounded-xl bg-emerald-800 hover:bg-emerald-700 flex items-center justify-center font-bold text-base cursor-pointer active:scale-95"
                    >
                      +
                    </button>
                  </div>
                )}
              </div>

              {/* 30 Paras Visual Progress Grid */}
              <div className="mt-5 pt-4 border-t border-emerald-800/80">
                <div className="flex items-center justify-between text-xs mb-2">
                  <span className="font-bold text-emerald-200">
                    قرآن کریم کی کل تکمیل: {selectedStudent.completedParas || 0} / 30 پارے (
                    {Math.round(((selectedStudent.completedParas || 0) / 30) * 100)}%)
                  </span>
                  <span className="text-amber-300 font-mono text-[11px]">
                    باقی پارے: {30 - (selectedStudent.completedParas || 0)}
                  </span>
                </div>

                <div className="w-full bg-emerald-950/80 h-3.5 rounded-full overflow-hidden p-0.5 border border-emerald-700">
                  <div
                    className="bg-linear-to-r from-amber-400 to-amber-300 h-full rounded-full transition-all duration-500 shadow-sm"
                    style={{
                      width: `${((selectedStudent.completedParas || 0) / 30) * 100}%`,
                    }}
                  />
                </div>
              </div>
            </div>
          )}

          {/* Diary Entries History Table / Cards */}
          <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-4">
            <h3 className="text-base font-bold text-emerald-950 font-urdu flex items-center gap-2">
              <span>📜</span>
              <span>
                {lang === 'ur' ? 'حالیہ اسباق، اہداف و اغلاط کا تفصیلی ریکارڈ' : 'Recent Lesson Records'}
              </span>
            </h3>

            {studentDiaryEntries.length === 0 ? (
              <div className="text-center py-10 text-slate-400 text-xs">
                اس طالب علم کے لیے ابھی کوئی سبق ریکارڈ نہیں کیا گیا۔ نیا سبق درج کرنے کے لیے اوپر بٹن دبائیں۔
              </div>
            ) : (
              <div className="space-y-3">
                {studentDiaryEntries.map((entry) => (
                  <div
                    key={entry.id}
                    className="p-4 rounded-2xl bg-slate-50 border border-slate-200/90 hover:border-emerald-300 transition-all flex flex-wrap items-center justify-between gap-3"
                  >
                    {/* Lesson Info */}
                    <div className="space-y-2 flex-1 min-w-[260px]">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="bg-emerald-950 text-amber-300 font-bold px-2.5 py-0.5 rounded-lg text-xs">
                          {entry.hifzType || entry.type || 'حفظ'}
                        </span>
                        {entry.hifzType === 'دینیات' ? (
                          <>
                            {entry.diniyatBookPage && (
                              <span className="bg-emerald-100 text-emerald-950 font-bold px-2.5 py-0.5 rounded-lg text-xs font-mono border border-emerald-300">
                                آسان نماز صفحہ {entry.diniyatBookPage}
                              </span>
                            )}
                            <span className="font-bold text-slate-900 text-sm">
                              سبق: {entry.diniyatTopic || entry.sabaqLinesOrPages}
                            </span>
                          </>
                        ) : (
                          <>
                            {entry.takhti && (
                              <span className="bg-blue-100 text-blue-900 font-bold px-2 py-0.5 rounded-lg text-xs">
                                {entry.takhti}
                              </span>
                            )}
                            <span className="bg-amber-100 text-amber-900 font-bold px-2.5 py-0.5 rounded-lg text-xs font-mono">
                              پارہ {entry.sabaqPara}
                            </span>
                            <span className="font-bold text-slate-900 text-sm">
                              سبق: {entry.sabaqLinesOrPages}
                            </span>
                          </>
                        )}
                        {entry.hadaf && (
                          <span className="bg-purple-100 text-purple-900 text-[11px] font-bold px-2 py-0.5 rounded-md">
                            🎯 ہدف: {entry.hadaf.quantity} {entry.hadaf.unit}
                          </span>
                        )}
                      </div>

                      {entry.hifzType !== 'دینیات' && (
                        <div className="text-xs text-slate-600 flex flex-wrap gap-x-4 gap-y-1">
                          <span>
                            <strong>سبقی:</strong> {entry.sabqi}
                          </span>
                          <span>
                            <strong>منزل:</strong> {entry.manzil}
                          </span>
                          <span>
                            <strong>استاد:</strong> {entry.ustadName}
                          </span>
                        </div>
                      )}
                      {entry.hifzType === 'دینیات' && (
                        <div className="text-xs text-slate-600 flex flex-wrap gap-x-4 gap-y-1">
                          <span>
                            <strong>کتاب:</strong> آسان نماز و دینیات
                          </span>
                          <span>
                            <strong>استاد:</strong> {entry.ustadName}
                          </span>
                        </div>
                      )}

                      {/* Mistakes Count Strip */}
                      {entry.mistakes && (
                        <div className="flex items-center gap-2 text-xs flex-wrap">
                          <span className="font-bold text-slate-600">اغلاط تفریح:</span>
                          <span className="bg-amber-100 text-amber-900 px-2 py-0.5 rounded font-mono font-bold">
                            اٹکنا: {entry.mistakes.atakna}
                          </span>
                          <span className="bg-rose-100 text-rose-900 px-2 py-0.5 rounded font-mono font-bold">
                            بھولنا: {entry.mistakes.bhoolna}
                          </span>
                          <span className="bg-blue-100 text-blue-900 px-2 py-0.5 rounded font-mono font-bold">
                            تجوید: {entry.mistakes.tajweed}
                          </span>
                        </div>
                      )}

                      {/* Audio Note Player if Available */}
                      {entry.audioUrl && (
                        <div className="flex items-center gap-2 bg-amber-50 p-2 rounded-xl border border-amber-200">
                          <Volume2 className="w-4 h-4 text-amber-700" />
                          <span className="text-xs font-bold text-amber-900">صوتی تلاوت:</span>
                          <audio src={entry.audioUrl} controls className="h-7 max-w-xs" />
                        </div>
                      )}

                      {entry.teacherRemarks && (
                        <div className="text-xs text-emerald-800 bg-emerald-50/80 p-2 rounded-xl border border-emerald-100 italic">
                          "{entry.teacherRemarks}"
                        </div>
                      )}
                    </div>

                    {/* Quality, Grade Badge & WhatsApp Action */}
                    <div className="flex items-center gap-3 shrink-0">
                      <div className="text-center">
                        <span
                          className={`inline-block px-3 py-1 rounded-full text-xs font-bold ${
                            entry.quality === 'بہترین' || entry.grade === 'A+'
                              ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                              : entry.quality === 'بہتر' || entry.grade === 'A'
                              ? 'bg-blue-100 text-blue-900 border border-blue-300'
                              : 'bg-amber-100 text-amber-900 border border-amber-300'
                          }`}
                        >
                          {entry.quality || (entry.grade === 'A+' ? 'بہترین' : 'مناسب')}
                        </span>
                        <span className="block text-[11px] text-slate-400 font-mono mt-1">
                          {entry.date}
                        </span>
                      </div>

                      {/* WhatsApp Button */}
                      <button
                        onClick={() => handleSendWhatsAppSabaq(entry)}
                        title="والد کو واٹس ایپ پر کارکردگی بھیجیں"
                        className="p-2.5 bg-[#25D366] hover:bg-[#20ba5a] text-white rounded-2xl shadow-sm transition-all cursor-pointer active:scale-95 flex items-center gap-1 text-xs font-bold"
                      >
                        <Send className="w-4 h-4" />
                        <span className="hidden sm:inline">واٹس ایپ 💬</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </>
      )}

      {/* Advanced Sabaq Logging Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-xl overflow-hidden animate-in fade-in duration-200 my-8">
            <div className="bg-[#0F5D2F] text-white p-5 flex items-center justify-between border-b-4 border-amber-500">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center text-2xl">
                  📖
                </div>
                <div>
                  <h3 className="font-bold text-lg font-urdu">{t.logTodaySabaq}</h3>
                  <p className="text-xs text-emerald-200 font-urdu">مدرسہ قاسمیہ جامع تعلیمی رجسٹر</p>
                </div>
              </div>
              <button
                onClick={handleCloseModal}
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4 font-urdu max-h-[80vh] overflow-y-auto">
              {/* Category Radio Selector */}
              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1.5">
                  سبق کی کیٹیگری منتخب کریں:
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {[
                    { id: 'قاعدہ', label: 'نورانی قاعدہ' },
                    { id: 'ناظرہ', label: 'ناظرہ قرآن' },
                    { id: 'حفظ', label: 'حفظِ قرآن' },
                    { id: 'دینیات', label: 'دینیات' },
                  ].map((cat) => (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() =>
                        setFormData({
                          ...formData,
                          hifzType: cat.id as any,
                        })
                      }
                      className={`py-2 px-1 rounded-xl text-xs font-bold border-2 transition-all cursor-pointer ${
                        formData.hifzType === cat.id
                          ? 'bg-emerald-900 text-amber-300 border-amber-400 shadow-sm'
                          : 'bg-slate-50 text-slate-700 border-slate-200'
                      }`}
                    >
                      {cat.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Student Select */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">
                    طالب علم کا انتخاب کریں:
                  </label>
                  <select
                    value={formData.studentId}
                    onChange={(e) => setFormData({ ...formData, studentId: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-sm bg-white"
                  >
                    {visibleStudents.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.nameUr} ({s.rollNo} - {s.class})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">{t.date}:</label>
                  <input
                    type="date"
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-sm"
                  />
                </div>
              </div>

              {/* Conditional: Noorani Qaida 28 Takhtis */}
              {formData.hifzType === 'قاعدہ' && (
                <div className="p-3 bg-blue-50 rounded-2xl border border-blue-200 space-y-2">
                  <label className="block text-xs font-bold text-blue-950">
                    نورانی قاعدہ - تختی کا انتخاب (۲۸ تختیاں):
                  </label>
                  <select
                    value={formData.takhti}
                    onChange={(e) => setFormData({ ...formData, takhti: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-blue-300 bg-white font-bold text-sm"
                  >
                    {nooraniQaidaTakhtis.map((tkh) => (
                      <option key={tkh} value={tkh}>
                        {tkh}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {/* Conditional: Nazra / Hifz Surah & Ayats */}
              {(formData.hifzType === 'ناظرہ' || formData.hifzType === 'حفظ') && (
                <div className="grid grid-cols-3 gap-2 p-3 bg-amber-50 rounded-2xl border border-amber-200">
                  <div>
                    <label className="block text-[11px] font-bold text-amber-950 mb-1">
                      سورت کا نام:
                    </label>
                    <input
                      type="text"
                      value={formData.surah}
                      onChange={(e) => setFormData({ ...formData, surah: e.target.value })}
                      className="w-full px-2.5 py-1.5 rounded-lg border border-amber-300 bg-white text-xs font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-amber-950 mb-1">
                      آیت نمبر سے:
                    </label>
                    <input
                      type="number"
                      value={formData.ayatFrom}
                      onChange={(e) =>
                        setFormData({ ...formData, ayatFrom: parseInt(e.target.value) || 1 })
                      }
                      className="w-full px-2.5 py-1.5 rounded-lg border border-amber-300 bg-white text-xs font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-amber-950 mb-1">
                      آیت نمبر تک:
                    </label>
                    <input
                      type="number"
                      value={formData.ayatTo}
                      onChange={(e) =>
                        setFormData({ ...formData, ayatTo: parseInt(e.target.value) || 1 })
                      }
                      className="w-full px-2.5 py-1.5 rounded-lg border border-amber-300 bg-white text-xs font-mono"
                    />
                  </div>
                </div>
              )}

              {/* Conditional: Diniyat Syllabus & Book Selection */}
              {formData.hifzType === 'دینیات' ? (
                <div className="p-4 bg-emerald-50/80 rounded-2xl border-2 border-emerald-300 space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="block text-xs font-black text-emerald-950 flex items-center gap-1.5">
                      <BookOpen className="w-4 h-4 text-emerald-700" />
                      <span>دینیات نصاب کا انتخاب (کتاب: آسان نماز و مسنون دعائیں):</span>
                    </label>
                    <span className="bg-emerald-200 text-emerald-900 text-[11px] font-bold px-2 py-0.5 rounded-md">
                      مستند نصاب
                    </span>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      سبق / موضوع کا انتخاب کریں:
                    </label>
                    <select
                      value={formData.diniyatLessonId || asaanNamazDiniyatLessons[0].id}
                      onChange={(e) => {
                        const selectedLesson = asaanNamazDiniyatLessons.find(
                          (l) => l.id === e.target.value
                        );
                        if (selectedLesson) {
                          setFormData({
                            ...formData,
                            diniyatLessonId: selectedLesson.id,
                            diniyatBookPage: selectedLesson.bookPageNumber,
                            diniyatTopic: selectedLesson.titleUr,
                            sabaqLinesOrPages: selectedLesson.titleUr,
                            teacherRemarks: selectedLesson.keyPoints
                              ? `اہم نکات: ${selectedLesson.keyPoints.join('، ')}۔ ماشاءاللہ عمدہ سنایا۔`
                              : formData.teacherRemarks,
                          });
                        }
                      }}
                      className="w-full px-3 py-2 rounded-xl border border-emerald-400 bg-white font-bold text-xs text-slate-900 shadow-xs"
                    >
                      {/* Group by category */}
                      {Array.from(new Set(asaanNamazDiniyatLessons.map((l) => l.category))).map(
                        (category) => (
                          <optgroup key={category} label={`🔹 ${category}`}>
                            {asaanNamazDiniyatLessons
                              .filter((l) => l.category === category)
                              .map((lesson) => (
                                <option key={lesson.id} value={lesson.id}>
                                  صفحہ {lesson.bookPageNumber}: {lesson.titleUr}
                                </option>
                              ))}
                          </optgroup>
                        )
                      )}
                    </select>
                  </div>

                  {/* Selected Lesson Preview Card */}
                  {(() => {
                    const currentLesson =
                      asaanNamazDiniyatLessons.find(
                        (l) => l.id === (formData.diniyatLessonId || asaanNamazDiniyatLessons[0].id)
                      ) || asaanNamazDiniyatLessons[0];
                    return (
                      <div className="bg-white p-3 rounded-xl border border-emerald-200 text-xs space-y-2">
                        <div className="flex items-center justify-between flex-wrap gap-1">
                          <span className="bg-emerald-100 text-emerald-900 font-bold px-2 py-0.5 rounded text-[11px]">
                            باب: {currentLesson.category}
                          </span>
                          <span className="font-bold text-amber-900 font-mono text-xs bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                            کتاب آسان نماز: صفحہ {currentLesson.bookPageNumber}
                          </span>
                        </div>
                        {currentLesson.subtitleUr && (
                          <div className="font-semibold text-slate-700">
                            {currentLesson.subtitleUr}
                          </div>
                        )}
                        {currentLesson.arabicText && (
                          <div className="font-arabic text-sm text-emerald-950 bg-slate-50 p-2 rounded-lg border border-slate-100 leading-relaxed text-center">
                            {currentLesson.arabicText}
                          </div>
                        )}
                        <div className="text-slate-600 text-[11px] leading-relaxed">
                          <strong>مفہوم / تفصیل:</strong> {currentLesson.translationUr}
                        </div>
                        {currentLesson.keyPoints && currentLesson.keyPoints.length > 0 && (
                          <div className="flex items-center gap-1.5 flex-wrap pt-1 border-t border-slate-100">
                            <span className="text-[10px] font-bold text-slate-500">اہم نکات:</span>
                            {currentLesson.keyPoints.map((pt) => (
                              <span
                                key={pt}
                                className="bg-slate-100 text-slate-700 text-[10px] px-1.5 py-0.5 rounded"
                              >
                                {pt}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    );
                  })()}
                </div>
              ) : (
                /* Sabaq, Sabqi, Manzil (For Qaida, Nazra, Hifz only) */
                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="block text-xs font-bold text-slate-600 mb-1">
                      سبق پارہ:
                    </label>
                    <input
                      type="number"
                      min={1}
                      max={30}
                      value={formData.sabaqPara}
                      onChange={(e) =>
                        setFormData({ ...formData, sabaqPara: parseInt(e.target.value) || 1 })
                      }
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-600 mb-1">سبقی:</label>
                    <input
                      type="text"
                      value={formData.sabqi}
                      onChange={(e) => setFormData({ ...formData, sabqi: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-600 mb-1">منزل:</label>
                    <input
                      type="text"
                      value={formData.manzil}
                      onChange={(e) => setFormData({ ...formData, manzil: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
                    />
                  </div>
                </div>
              )}

              {/* Daily Target & Mistakes Counter (Only for Qaida, Nazra, Hifz - not for Diniyat) */}
              {formData.hifzType !== 'دینیات' && (
                <>
                  {/* Daily Target (مقدار و یونٹ) */}
                  <div className="p-3 bg-purple-50 rounded-2xl border border-purple-200 space-y-2">
                    <label className="block text-xs font-bold text-purple-950">
                      🎯 روزانہ ہدف (Daily Target):
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <span className="text-[11px] text-purple-800 block mb-1">مقدار (Amount):</span>
                        <input
                          type="number"
                          min={1}
                          value={formData.hadaf.quantity}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              hadaf: {
                                ...formData.hadaf,
                                quantity: parseInt(e.target.value) || 1,
                              },
                            })
                          }
                          className="w-full px-3 py-1.5 rounded-lg border border-purple-300 bg-white font-mono text-xs"
                        />
                      </div>
                      <div>
                        <span className="text-[11px] text-purple-800 block mb-1">یونٹ (Unit):</span>
                        <select
                          value={formData.hadaf.unit}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              hadaf: {
                                ...formData.hadaf,
                                unit: e.target.value as any,
                              },
                            })
                          }
                          className="w-full px-3 py-1.5 rounded-lg border border-purple-300 bg-white text-xs font-bold"
                        >
                          <option value="صفحہ">صفحہ</option>
                          <option value="الفاظ">الفاظ</option>
                          <option value="لائنیں">لائنیں</option>
                          <option value="رکوع">رکوع</option>
                          <option value="آیت">آیت</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  {/* Mistakes Counters: اٹکنا / بھولنا / تجوید */}
                  <div className="p-3.5 bg-rose-50/70 rounded-2xl border border-rose-200 space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-bold text-rose-950 flex items-center gap-1.5">
                        <AlertCircle className="w-4 h-4 text-rose-600" />
                        <span>اغلاط کی گنتی (Mistakes Counter):</span>
                      </label>
                      <span className="text-xs font-mono font-bold text-rose-800">
                        کل: {formData.mistakes.atakna + formData.mistakes.bhoolna + formData.mistakes.tajweed}
                      </span>
                    </div>

                    <div className="grid grid-cols-3 gap-2">
                      {/* Atakna */}
                      <div className="bg-white p-2.5 rounded-xl border border-rose-200 text-center">
                        <span className="text-xs font-bold text-slate-700 block">اٹکنا</span>
                        <div className="flex items-center justify-center gap-2 mt-1">
                          <button
                            type="button"
                            onClick={() =>
                              setFormData({
                                ...formData,
                                mistakes: {
                                  ...formData.mistakes,
                                  atakna: Math.max(0, formData.mistakes.atakna - 1),
                                },
                              })
                            }
                            className="w-6 h-6 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs"
                          >
                            -
                          </button>
                          <span className="font-mono font-bold text-sm text-rose-700">
                            {formData.mistakes.atakna}
                          </span>
                          <button
                            type="button"
                            onClick={() =>
                              setFormData({
                                ...formData,
                                mistakes: {
                                  ...formData.mistakes,
                                  atakna: formData.mistakes.atakna + 1,
                                },
                              })
                            }
                            className="w-6 h-6 rounded bg-rose-100 hover:bg-rose-200 text-rose-800 font-bold text-xs"
                          >
                            +
                          </button>
                        </div>
                      </div>

                      {/* Bhoolna */}
                      <div className="bg-white p-2.5 rounded-xl border border-rose-200 text-center">
                        <span className="text-xs font-bold text-slate-700 block">بھولنا</span>
                        <div className="flex items-center justify-center gap-2 mt-1">
                          <button
                            type="button"
                            onClick={() =>
                              setFormData({
                                ...formData,
                                mistakes: {
                                  ...formData.mistakes,
                                  bhoolna: Math.max(0, formData.mistakes.bhoolna - 1),
                                },
                              })
                            }
                            className="w-6 h-6 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs"
                          >
                            -
                          </button>
                          <span className="font-mono font-bold text-sm text-rose-700">
                            {formData.mistakes.bhoolna}
                          </span>
                          <button
                            type="button"
                            onClick={() =>
                              setFormData({
                                ...formData,
                                mistakes: {
                                  ...formData.mistakes,
                                  bhoolna: formData.mistakes.bhoolna + 1,
                                },
                              })
                            }
                            className="w-6 h-6 rounded bg-rose-100 hover:bg-rose-200 text-rose-800 font-bold text-xs"
                          >
                            +
                          </button>
                        </div>
                      </div>

                      {/* Tajweed */}
                      <div className="bg-white p-2.5 rounded-xl border border-rose-200 text-center">
                        <span className="text-xs font-bold text-slate-700 block">تجوید</span>
                        <div className="flex items-center justify-center gap-2 mt-1">
                          <button
                            type="button"
                            onClick={() =>
                              setFormData({
                                ...formData,
                                mistakes: {
                                  ...formData.mistakes,
                                  tajweed: Math.max(0, formData.mistakes.tajweed - 1),
                                },
                              })
                            }
                            className="w-6 h-6 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs"
                          >
                            -
                          </button>
                          <span className="font-mono font-bold text-sm text-rose-700">
                            {formData.mistakes.tajweed}
                          </span>
                          <button
                            type="button"
                            onClick={() =>
                              setFormData({
                                ...formData,
                                mistakes: {
                                  ...formData.mistakes,
                                  tajweed: formData.mistakes.tajweed + 1,
                                },
                              })
                            }
                            className="w-6 h-6 rounded bg-rose-100 hover:bg-rose-200 text-rose-800 font-bold text-xs"
                          >
                            +
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </>
              )}

              {/* Quality Rating (3 Big Buttons) */}
              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1.5">
                  معیار تلاوت (Recitation Quality):
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'مناسب', label: 'مناسب (Fair)', bg: 'hover:bg-amber-100', active: 'bg-amber-500 text-white' },
                    { id: 'بہتر', label: 'بہتر (Good)', bg: 'hover:bg-blue-100', active: 'bg-blue-600 text-white' },
                    { id: 'بہترین', label: 'بہترین (Excellent)', bg: 'hover:bg-emerald-100', active: 'bg-emerald-600 text-white' },
                  ].map((q) => (
                    <button
                      key={q.id}
                      type="button"
                      onClick={() =>
                        setFormData({
                          ...formData,
                          quality: q.id as any,
                          grade: q.id === 'بہترین' ? 'A+' : q.id === 'بہتر' ? 'A' : 'B',
                        })
                      }
                      className={`py-2.5 px-2 rounded-xl text-xs font-bold border-2 transition-all cursor-pointer ${
                        formData.quality === q.id
                          ? `${q.active} border-transparent shadow-sm`
                          : `bg-slate-50 text-slate-700 border-slate-200 ${q.bg}`
                      }`}
                    >
                      {q.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Remarks Chips based on Category */}
              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">
                  فوری ریمارکس چپس (کلک کر کے شامل کریں):
                </label>
                <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto p-2 bg-slate-50 rounded-xl border border-slate-200">
                  {(formData.hifzType === 'قاعدہ'
                    ? qaidaRemarksChips
                    : formData.hifzType === 'دینیات'
                    ? diniyatRemarksChips
                    : nazraHifzRemarksChips
                  ).map((chip) => {
                      const isSelected = formData.teacherRemarks.includes(chip);
                      return (
                        <button
                          key={chip}
                          type="button"
                          onClick={() => handleToggleRemarkChip(chip)}
                          className={`text-xs px-2.5 py-1 rounded-lg transition cursor-pointer font-bold ${
                            isSelected
                              ? 'bg-emerald-700 text-white'
                              : 'bg-white text-slate-700 border border-slate-200 hover:bg-emerald-50'
                          }`}
                        >
                          {chip}
                        </button>
                      );
                    }
                  )}
                </div>
              </div>

              {/* Teacher Remarks Input */}
              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">
                  استاد کے تاثرات و نصیحت:
                </label>
                <input
                  type="text"
                  placeholder="مثال: ماشاءاللہ تجوید و لحن بہترین تھا۔"
                  value={formData.teacherRemarks}
                  onChange={(e) => setFormData({ ...formData, teacherRemarks: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
                />
              </div>

              {/* Voice Recitation Recorder */}
              <div className="p-3 bg-amber-50/80 rounded-2xl border border-amber-300 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-amber-950 flex items-center gap-1.5">
                    <Mic className="w-4 h-4 text-amber-700" />
                    <span>صوتی تلاوت ریکارڈ کریں (Voice Recitation):</span>
                  </span>
                  {isRecording && (
                    <span className="text-[11px] text-rose-600 font-bold animate-pulse">
                      ● ریکارڈنگ جاری ہے...
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-3">
                  {!isRecording ? (
                    <button
                      type="button"
                      onClick={startRecording}
                      className="flex items-center gap-1.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold px-3 py-1.5 rounded-xl cursor-pointer transition shadow-xs"
                    >
                      <Mic className="w-3.5 h-3.5" />
                      <span>ریکارڈنگ شروع کریں</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={stopRecording}
                      className="flex items-center gap-1.5 bg-slate-800 hover:bg-black text-white text-xs font-bold px-3 py-1.5 rounded-xl cursor-pointer transition"
                    >
                      <MicOff className="w-3.5 h-3.5 text-rose-400" />
                      <span>ریکارڈنگ بند کریں</span>
                    </button>
                  )}

                  {recordedAudioUrl && (
                    <audio src={recordedAudioUrl} controls className="h-8 max-w-xs" />
                  )}
                </div>
              </div>

              <div className="flex items-center gap-3 pt-3 border-t border-slate-200">
                <button
                  type="submit"
                  className="flex-1 bg-[#0F5D2F] hover:bg-emerald-800 text-white font-bold py-3 px-6 rounded-2xl shadow-md transition-all cursor-pointer"
                >
                  {t.save}
                </button>
                <button
                  type="button"
                  onClick={handleCloseModal}
                  className="px-5 py-3 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-sm cursor-pointer"
                >
                  {t.cancel}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
