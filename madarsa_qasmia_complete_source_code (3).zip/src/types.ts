export type UserRole = 'admin' | 'ustad' | 'accountant' | 'parent';

export type StudentClass = 'Hifz' | 'Nazra' | 'Qaida' | 'Alim' | 'Deeniat';

export type AttendanceStatus = 'present' | 'absent' | 'leave';

export type HifzGrade = 'A+' | 'A' | 'B' | 'C';

export type DonationCategory = 'Lillah' | 'Zakat' | 'Building' | 'Sadqah';

export type ExpenseCategory = 'Salaries' | 'Kitchen' | 'Utilities' | 'Maintenance' | 'Books' | 'Other';

export interface TeacherProfile {
  id: string;
  nameUr: string;
  nameEn: string;
  phone: string;
  assignedClass: StudentClass;
  halqaNameUr: string;
  pin: string;
  qualifications?: string;
  avatarIcon?: string;
}

export interface Student {
  id: string;
  rollNo: string;
  nameUr: string;
  nameEn: string;
  fatherNameUr: string;
  fatherNameEn: string;
  class: StudentClass;
  age: number;
  parentMobile: string;
  isHostel: boolean;
  monthlyFee: number;
  admissionDate: string;
  address?: string;
  completedParas?: number;
  activeStatus: 'active' | 'graduated' | 'left';
  createdAt?: string;
  takhti?: string;
  hadaf?: {
    unit: string;
    miqdar: string;
  };
  ustadName?: string;
  halqa?: string;
}

export interface AttendanceRecord {
  id: string;
  studentId: string;
  date: string; // YYYY-MM-DD
  status: AttendanceStatus;
  remarks?: string;
}

export interface HifzDiaryEntry {
  id: string;
  studentId: string;
  date: string; // YYYY-MM-DD
  sabaqPara: number;
  sabaqLinesOrPages: string;
  sabqi: string;
  manzil: string;
  grade: HifzGrade;
  teacherRemarks: string;
  ustadName: string;
  type?: 'قاعدہ' | 'ناظرہ' | 'حفظ' | 'دینیات';
  quality?: 'مناسب' | 'بہتر' | 'بہترین';
  hifzType?: 'سبق' | 'سبقی' | 'منزل' | 'قاعدہ' | 'ناظرہ' | 'حفظ' | 'دینیات';
  status?: 'یاد' | 'کمزور' | 'پکا';
  surah?: string;
  ayatFrom?: string | number;
  ayatTo?: string | number;
  takhti?: string;
  hadaf?: {
    quantity: number;
    unit: 'الفاظ' | 'لائنیں' | 'صفحہ' | 'رکوع' | 'آیت';
  };
  mistakes?: {
    atakna: number;
    bhoolna: number;
    tajweed: number;
  };
  remarksChips?: string[];
  audioUrl?: string;
  diniyatWeek?: number;
  diniyatLessonId?: string;
  diniyatBookPage?: number;
  diniyatTopic?: string;
}

export type MushafData = Record<string, Record<number, number[]>>;

export interface Donor {
  id: string;
  name: string;
  fatherName?: string;
  phone: string;
  category: 'ماہانہ' | 'سالانہ' | 'زکوٰۃ' | 'صدقہ' | 'لِلّٰہ' | 'تعمیر';
  frequency: 'ماہانہ' | 'سالانہ' | 'یکمشتی';
  promisedAmount: number;
  totalContributed?: number;
  lastDonationDate?: string;
  address?: string;
  notes?: string;
  naam?: string;
  walid?: string;
  mobile?: string;
}

export interface DiniyatTopic {
  weekNumber: number;
  titleUr: string;
  descriptionUr: string;
  arabicText?: string;
  week?: number;
  title?: string;
  arabic?: string;
}

export interface FeePayment {
  id: string;
  studentId: string;
  receiptNo: string;
  date: string;
  month: string; // e.g. "March 2026"
  tuitionFee: number;
  booksFee: number;
  hostelFee: number;
  transportFee: number;
  discount: number;
  totalPaid: number;
  paymentMethod: 'Cash' | 'Easypaisa' | 'JazzCash' | 'Bank';
  collectedBy: string;
  notes?: string;
}

export interface DonationRecord {
  id: string;
  voucherNo: string;
  date: string;
  donorName: string;
  donorPhone: string;
  category: DonationCategory;
  amount: number;
  paymentMode: 'Cash' | 'Online' | 'Cheque';
  purpose: string;
  collectorName: string;
}

export interface ExpenseRecord {
  id: string;
  voucherNo: string;
  date: string;
  title: string;
  category: ExpenseCategory;
  amount: number;
  paidTo: string;
  approvedBy: string;
  notes?: string;
}

export interface TimetableSchedule {
  id: string;
  class: StudentClass;
  periodNameUr: string;
  periodNameEn: string;
  timeRange: string;
  subjectUr: string;
  subjectEn: string;
  teacherUr: string;
  teacherEn: string;
  room: string;
}

export interface SystemSettings {
  madrasaNameUr: string;
  madrasaNameEn: string;
  taglineUr: string;
  taglineEn: string;
  addressUr: string;
  addressEn: string;
  phone: string;
  email: string;
  adminPin: string;
  ustadPin: string;
  accountantPin: string;
  currency: string;
}

export interface ExamRecord {
  id: string;
  studentId: string;
  examTerm: 'ShishMahi' | 'Salana' | 'Monthly';
  examNameUr: string;
  examNameEn: string;
  date: string;
  hifzMarks: number;
  tajweedMarks: number;
  nazraMarks: number;
  deeniyatMarks: number;
  akhlaqMarks: number;
  totalObtained: number;
  totalMax: number;
  percentage: number;
  grade: 'A+' | 'A' | 'B' | 'C' | 'D';
  gradeUr: string;
  examinerUr: string;
  remarksUr: string;
  createdAt?: string;
}

export interface NoticeAnnouncement {
  id: string;
  titleUr: string;
  titleEn: string;
  contentUr: string;
  contentEn: string;
  date: string;
  category: 'holiday' | 'event' | 'admission' | 'general';
  priority: 'high' | 'normal';
  author: string;
  createdAt?: string;
}

export interface KitchenItem {
  id: string;
  itemNameUr: string;
  quantity: string;
  unit: string;
  date: string;
  type: 'purchase' | 'donation' | 'consumed';
  cost?: number;
  sourceOrDonor?: string;
  notes?: string;
  createdAt?: string;
}

