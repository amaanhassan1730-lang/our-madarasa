// Authentic Quran 30 Paras metadata: Ruku count, Starting Surah/Ayat, and Surahs in Para 30
export interface ParaMeta {
  paraNumber: number;
  nameUr: string;
  nameEn: string;
  rukuCount: number;
  startSurah: string;
  startAyat: number;
  surahsInPara?: {
    nameUr: string;
    nameEn: string;
    totalAyat: number;
    rukuCount: number;
  }[];
}

// 30 Paras details with exact standard Ruku counts
export const quran30ParasMeta: ParaMeta[] = [
  { paraNumber: 1, nameUr: 'الم', nameEn: 'Alif Lam Meem', rukuCount: 16, startSurah: 'الفاتحۃ', startAyat: 1 },
  { paraNumber: 2, nameUr: 'سَيَقُولُ', nameEn: 'Sayaqool', rukuCount: 16, startSurah: 'البقرۃ', startAyat: 142 },
  { paraNumber: 3, nameUr: 'تِلْكَ الرُّسُلُ', nameEn: 'Tilkal Rusul', rukuCount: 20, startSurah: 'البقرۃ', startAyat: 253 },
  { paraNumber: 4, nameUr: 'لَنْ تَنَالُوا', nameEn: 'Lan Tana Loo', rukuCount: 20, startSurah: 'آل عمران', startAyat: 92 },
  { paraNumber: 5, nameUr: 'وَالْمُحْصَنَاتُ', nameEn: 'Wal Mohsanat', rukuCount: 24, startSurah: 'النساء', startAyat: 24 },
  { paraNumber: 6, nameUr: 'لَا يُحِبُّ اللهُ', nameEn: 'La Yuhibbullah', rukuCount: 21, startSurah: 'النساء', startAyat: 148 },
  { paraNumber: 7, nameUr: 'وَإِذَا سَمِعُوا', nameEn: 'Wa Iza Samiu', rukuCount: 24, startSurah: 'المائدۃ', startAyat: 82 },
  { paraNumber: 8, nameUr: 'وَلَوْ أَنَّنَا', nameEn: 'Wa Lau Annana', rukuCount: 20, startSurah: 'الأنعام', startAyat: 111 },
  { paraNumber: 9, nameUr: 'قَالَ الْمَلَأُ', nameEn: 'Qalal Malao', rukuCount: 24, startSurah: 'الأعراف', startAyat: 88 },
  { paraNumber: 10, nameUr: 'وَاعْلَمُوا', nameEn: 'Wa A\'lamu', rukuCount: 20, startSurah: 'الأنفال', startAyat: 41 },
  { paraNumber: 11, nameUr: 'يَعْتَذِرُونَ', nameEn: 'Yatazeroon', rukuCount: 21, startSurah: 'التوبۃ', startAyat: 93 },
  { paraNumber: 12, nameUr: 'وَمَا مِنْ دَابَّةٍ', nameEn: 'Wa Mamin Da\'abat', rukuCount: 22, startSurah: 'ہود', startAyat: 6 },
  { paraNumber: 13, nameUr: 'وَمَا أُبَرِّئُ', nameEn: 'Wa Ma Ubarri\'u', rukuCount: 21, startSurah: 'یوسف', startAyat: 53 },
  { paraNumber: 14, nameUr: 'رُبَمَا', nameEn: 'Rubama', rukuCount: 22, startSurah: 'الحجر', startAyat: 1 },
  { paraNumber: 15, nameUr: 'سُبْحَانَ الَّذِي', nameEn: 'Subhanallazi', rukuCount: 20, startSurah: 'بنی اسرائیل', startAyat: 1 },
  { paraNumber: 16, nameUr: 'قَالَ أَلَمْ', nameEn: 'Qal Alam', rukuCount: 20, startSurah: 'الکہف', startAyat: 75 },
  { paraNumber: 17, nameUr: 'اقْتَرَبَ لِلنَّاسِ', nameEn: 'Iqtaraba Linnas', rukuCount: 19, startSurah: 'الأنبیاء', startAyat: 1 },
  { paraNumber: 18, nameUr: 'قَدْ أَفْلَحَ', nameEn: 'Qadd Aflaha', rukuCount: 20, startSurah: 'المؤمنون', startAyat: 1 },
  { paraNumber: 19, nameUr: 'وَقَالَ الَّذِينَ', nameEn: 'Wa Qalal Lazina', rukuCount: 20, startSurah: 'الفرقان', startAyat: 21 },
  { paraNumber: 20, nameUr: 'أَمَّنْ خَلَقَ', nameEn: 'Amman Khalaqa', rukuCount: 22, startSurah: 'النمل', startAyat: 56 },
  { paraNumber: 21, nameUr: 'اتْلُ مَا أُوحِيَ', nameEn: 'Utlu Ma Oohia', rukuCount: 20, startSurah: 'العنکبوت', startAyat: 46 },
  { paraNumber: 22, nameUr: 'وَمَنْ يَّقْنُتْ', nameEn: 'Wa Manyaqnut', rukuCount: 21, startSurah: 'الأحزاب', startAyat: 31 },
  { paraNumber: 23, nameUr: 'وَمَا لِيَ', nameEn: 'Wa Mali', rukuCount: 22, startSurah: 'یس', startAyat: 28 },
  { paraNumber: 24, nameUr: 'فَمَنْ أَظْلَمُ', nameEn: 'Faman Azlamu', rukuCount: 22, startSurah: 'الزمر', startAyat: 32 },
  { paraNumber: 25, nameUr: 'إِلَيْهِ يُرَدُّ', nameEn: 'Elahe Yuruddo', rukuCount: 22, startSurah: 'حم السجدۃ', startAyat: 47 },
  { paraNumber: 26, nameUr: 'حم', nameEn: 'Ha\'a Meem', rukuCount: 22, startSurah: 'الأحقاف', startAyat: 1 },
  { paraNumber: 27, nameUr: 'قَالَ فَمَا خَطْبُكُمْ', nameEn: 'Qala Fama Khatbukum', rukuCount: 22, startSurah: 'الذاریات', startAyat: 31 },
  { paraNumber: 28, nameUr: 'قَدْ سَمِعَ اللهُ', nameEn: 'Qadd Sami Allah', rukuCount: 22, startSurah: 'المجادلۃ', startAyat: 1 },
  { paraNumber: 29, nameUr: 'تَبَارَكَ الَّذِي', nameEn: 'Tabarakallazi', rukuCount: 22, startSurah: 'الملک', startAyat: 1 },
  {
    paraNumber: 30,
    nameUr: 'عَمَّ يَتَسَاءَلُونَ',
    nameEn: 'Amma Yatasa\'aloon',
    rukuCount: 39, // Total 39 Rukus across 37 Surahs
    startSurah: 'النبأ',
    startAyat: 1,
    surahsInPara: [
      { nameUr: 'النبأ', nameEn: 'An-Naba', totalAyat: 40, rukuCount: 2 },
      { nameUr: 'النازعات', nameEn: 'An-Nazi\'at', totalAyat: 46, rukuCount: 2 },
      { nameUr: 'عبس', nameEn: 'Abasa', totalAyat: 42, rukuCount: 1 },
      { nameUr: 'التکویر', nameEn: 'At-Takwir', totalAyat: 29, rukuCount: 1 },
      { nameUr: 'الانفطار', nameEn: 'Al-Infitar', totalAyat: 19, rukuCount: 1 },
      { nameUr: 'المطففین', nameEn: 'Al-Mutaffifin', totalAyat: 36, rukuCount: 1 },
      { nameUr: 'الانشقاق', nameEn: 'Al-Inshiqaq', totalAyat: 25, rukuCount: 1 },
      { nameUr: 'البروج', nameEn: 'Al-Burooj', totalAyat: 22, rukuCount: 1 },
      { nameUr: 'الطارق', nameEn: 'At-Tariq', totalAyat: 17, rukuCount: 1 },
      { nameUr: 'الاعلیٰ', nameEn: 'Al-A\'la', totalAyat: 19, rukuCount: 1 },
      { nameUr: 'الغاشیۃ', nameEn: 'Al-Ghashiyah', totalAyat: 26, rukuCount: 1 },
      { nameUr: 'الفجر', nameEn: 'Al-Fajr', totalAyat: 30, rukuCount: 1 },
      { nameUr: 'البلد', nameEn: 'Al-Balad', totalAyat: 20, rukuCount: 1 },
      { nameUr: 'الشمس', nameEn: 'Ash-Shams', totalAyat: 15, rukuCount: 1 },
      { nameUr: 'اللیل', nameEn: 'Al-Layl', totalAyat: 21, rukuCount: 1 },
      { nameUr: 'الضحیٰ', nameEn: 'Ad-Duha', totalAyat: 11, rukuCount: 1 },
      { nameUr: 'الانشراح', nameEn: 'Ash-Sharh', totalAyat: 8, rukuCount: 1 },
      { nameUr: 'التین', nameEn: 'At-Tin', totalAyat: 8, rukuCount: 1 },
      { nameUr: 'العلق', nameEn: 'Al-Alaq', totalAyat: 19, rukuCount: 1 },
      { nameUr: 'القدر', nameEn: 'Al-Qadr', totalAyat: 5, rukuCount: 1 },
      { nameUr: 'البینۃ', nameEn: 'Al-Bayyinah', totalAyat: 8, rukuCount: 1 },
      { nameUr: 'الزلزال', nameEn: 'Az-Zalzalah', totalAyat: 8, rukuCount: 1 },
      { nameUr: 'العادیات', nameEn: 'Al-Adiyat', totalAyat: 11, rukuCount: 1 },
      { nameUr: 'القارعۃ', nameEn: 'Al-Qari\'ah', totalAyat: 11, rukuCount: 1 },
      { nameUr: 'التکاثر', nameEn: 'At-Takathur', totalAyat: 8, rukuCount: 1 },
      { nameUr: 'العصر', nameEn: 'Al-Asr', totalAyat: 3, rukuCount: 1 },
      { nameUr: 'الہمزۃ', nameEn: 'Al-Humazah', totalAyat: 9, rukuCount: 1 },
      { nameUr: 'الفیل', nameEn: 'Al-Fil', totalAyat: 5, rukuCount: 1 },
      { nameUr: 'قریش', nameEn: 'Quraysh', totalAyat: 4, rukuCount: 1 },
      { nameUr: 'الماعون', nameEn: 'Al-Ma\'un', totalAyat: 7, rukuCount: 1 },
      { nameUr: 'الکوثر', nameEn: 'Al-Kawthar', totalAyat: 3, rukuCount: 1 },
      { nameUr: 'الکافرون', nameEn: 'Al-Kafirun', totalAyat: 6, rukuCount: 1 },
      { nameUr: 'النصر', nameEn: 'An-Nasr', totalAyat: 3, rukuCount: 1 },
      { nameUr: 'اللہب', nameEn: 'Al-Masad', totalAyat: 5, rukuCount: 1 },
      { nameUr: 'الاخلاص', nameEn: 'Al-Ikhlas', totalAyat: 4, rukuCount: 1 },
      { nameUr: 'الفلق', nameEn: 'Al-Falaq', totalAyat: 5, rukuCount: 1 },
      { nameUr: 'الناس', nameEn: 'An-Nas', totalAyat: 6, rukuCount: 1 },
    ],
  },
];
