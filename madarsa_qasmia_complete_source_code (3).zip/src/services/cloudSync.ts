import {
  doc,
  setDoc,
  onSnapshot,
  getDoc,
  serverTimestamp,
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import {
  Student,
  AttendanceRecord,
  HifzDiaryEntry,
  FeePayment,
  DonationRecord,
  ExpenseRecord,
  TimetableSchedule,
  SystemSettings,
  ExamRecord,
  NoticeAnnouncement,
  MushafData,
  Donor,
  TeacherProfile,
} from '../types';

export interface AppDataState {
  settings: SystemSettings;
  teachers?: TeacherProfile[];
  students: Student[];
  attendance: AttendanceRecord[];
  hifzDiary: HifzDiaryEntry[];
  feePayments: FeePayment[];
  donations: DonationRecord[];
  expenses: ExpenseRecord[];
  timetable: TimetableSchedule[];
  exams: ExamRecord[];
  notices: NoticeAnnouncement[];
  mushafProgress: MushafData;
  donors: Donor[];
}

const COLLECTION_NAME = 'madarsa_data';
const MAIN_DOC_ID = 'central_store';

// Flag to track whether Firestore free-tier daily quota limit was hit
let isQuotaExceeded = false;
let quotaListeners: Array<(exceeded: boolean) => void> = [];

export const onQuotaStateChange = (callback: (exceeded: boolean) => void) => {
  quotaListeners.push(callback);
  callback(isQuotaExceeded);
  return () => {
    quotaListeners = quotaListeners.filter((cb) => cb !== callback);
  };
};

const notifyQuotaExceeded = () => {
  if (!isQuotaExceeded) {
    isQuotaExceeded = true;
    quotaListeners.forEach((cb) => cb(true));
  }
};

export const isFirestoreQuotaExceeded = () => isQuotaExceeded;

// Listen to real-time updates from Firebase Cloud Firestore
export const subscribeToCloudData = (
  onData: (cloudData: Partial<AppDataState>) => void,
  onError?: (err: any) => void
) => {
  try {
    const docRef = doc(db, COLLECTION_NAME, MAIN_DOC_ID);

    return onSnapshot(
      docRef,
      (snapshot) => {
        if (snapshot.exists()) {
          const data = snapshot.data();
          onData({
            settings: data.settings,
            students: data.students,
            attendance: data.attendance,
            hifzDiary: data.hifzDiary,
            feePayments: data.feePayments,
            donations: data.donations,
            expenses: data.expenses,
            timetable: data.timetable,
            exams: data.exams,
            notices: data.notices,
            mushafProgress: data.mushafProgress,
            donors: data.donors,
          });
        }
      },
      (error: any) => {
        if (
          error?.code === 'resource-exhausted' ||
          String(error?.message || '').toLowerCase().includes('quota')
        ) {
          notifyQuotaExceeded();
          console.warn('⚠️ Firestore Free daily quota reached. Switched cleanly to local offline persistence.');
        } else {
          console.warn('Firestore subscription status:', error?.message || error);
        }
        if (onError) onError(error);
      }
    );
  } catch (err: any) {
    if (
      err?.code === 'resource-exhausted' ||
      String(err?.message || '').toLowerCase().includes('quota')
    ) {
      notifyQuotaExceeded();
    }
    if (onError) onError(err);
    return () => {};
  }
};

// Sync app data to Cloud Firestore (with debounce & loop protection)
let syncTimeout: any = null;
let lastSyncedDataHash = '';

export const syncDataToCloud = (data: AppDataState) => {
  // If Firestore free daily quota is exceeded, do NOT attempt writes to avoid infinite backend backoff errors
  if (isQuotaExceeded) {
    return;
  }

  // Quick shallow hash check to avoid unnecessary writes
  const currentDataHash = JSON.stringify({
    studentsCount: data.students?.length,
    attendanceCount: data.attendance?.length,
    hifzCount: data.hifzDiary?.length,
    feesCount: data.feePayments?.length,
    donationsCount: data.donations?.length,
    expensesCount: data.expenses?.length,
    noticesCount: data.notices?.length,
    examsCount: data.exams?.length,
    settingsName: data.settings?.madrasaNameUr,
  });

  if (currentDataHash === lastSyncedDataHash) {
    return;
  }

  if (syncTimeout) {
    clearTimeout(syncTimeout);
  }

  // Debounce writes by 2000ms
  syncTimeout = setTimeout(async () => {
    if (isQuotaExceeded) return;

    try {
      lastSyncedDataHash = currentDataHash;
      const docRef = doc(db, COLLECTION_NAME, MAIN_DOC_ID);
      await setDoc(
        docRef,
        {
          ...data,
          lastUpdatedAt: serverTimestamp(),
          updatedByClientTime: new Date().toISOString(),
        },
        { merge: true }
      );
      console.log('✅ Cloud Firestore synchronized successfully');
    } catch (error: any) {
      if (
        error?.code === 'resource-exhausted' ||
        String(error?.message || '').toLowerCase().includes('quota')
      ) {
        notifyQuotaExceeded();
        console.warn('⚠️ Firestore write quota exceeded. Pausing future cloud writes. Operating locally.');
      } else {
        console.error('Error syncing to Firestore:', error);
      }
    }
  }, 2000);
};

// Seed initial cloud state if empty
export const seedCloudDataIfEmpty = async (initialData: AppDataState) => {
  if (isQuotaExceeded) return;

  try {
    const docRef = doc(db, COLLECTION_NAME, MAIN_DOC_ID);
    const snap = await getDoc(docRef);
    if (!snap.exists()) {
      await setDoc(docRef, {
        ...initialData,
        lastUpdatedAt: serverTimestamp(),
        createdAt: new Date().toISOString(),
      });
      console.log('🌱 Cloud database seeded with initial Madrasa data');
    }
  } catch (err: any) {
    if (
      err?.code === 'resource-exhausted' ||
      String(err?.message || '').toLowerCase().includes('quota')
    ) {
      notifyQuotaExceeded();
    }
    console.warn('Cloud database check skipped:', err?.message || err);
  }
};
